DROP TABLE IF EXISTS `#__phocamenu_config`;
DROP TABLE IF EXISTS `#__phocamenu_day`;
DROP TABLE IF EXISTS `#__phocamenu_list`;
DROP TABLE IF EXISTS `#__phocamenu_email`;
DROP TABLE IF EXISTS `#__phocamenu_group`;
DROP TABLE IF EXISTS `#__phocamenu_item`;
