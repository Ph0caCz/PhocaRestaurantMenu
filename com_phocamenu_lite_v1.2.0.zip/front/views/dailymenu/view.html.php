<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
jimport('joomla.application.component.view');
class PhocaMenuViewDailyMenu extends JView
{
	function display($tpl = null) {
		
		global $mainframe;		
		
		$document			= & JFactory::getDocument();
		$params				= &$mainframe->getParams();
		$tmpl				= array();
		$tmpl['printview'] 	= JRequest::getVar('print', 0, 'get', 'int');
		$model 				= &$this->getModel('Menu');
		$data				= &$model->getData(1);
		
		// Meta tag info
		if (isset($data['config']->meta_keywords)){
			$mainframe->addMetaTag('keywords', $data['config']->meta_keywords);
		}		
		if (isset($data['config']->meta_title)) {
			$mainframe->addMetaTag('title', $data['config']->meta_title);
		}
		
		// Params
		$tmpl['dateclass']			= $params->get( 'date_class', 0 );
		$tmpl['customclockcode']	= $params->get( 'custom_clock_code', '' );
		$tmpl['daydateformat']		= $params->get( 'day_date_format', '%A, %d. %B %Y' );
		$tmpl['priceprefix']		= $params->get( 'price_prefix', '...' );
		
		
		// Phoca Gallery Test
		// Check if Phoca Gallery is installed and enabled
		// If it is installed and enabled, check if it is allready used on the site (some of row contains imageid value)
		
		if (!JComponentHelper::isEnabled('com_phocagallery', true)) {
			$tmpl['phocagallery']	= 0;
		} else if (isset($data['imagesum']->sum) && (int)$data['imagesum']->sum > 0) {
			$tmpl['phocagallery']	= 1;
		} else {
			$tmpl['phocagallery']	= 0;
		}
		
		
		if ((int)$tmpl['printview'] == 1 ) {
			
			$tmpl['phocagallery']		= 0;
			JHTML::stylesheet( 'phocamenu.css', 'components/com_phocamenu/assets/' );
			JHTML::stylesheet( 'phocamenu-print.css', 'components/com_phocamenu/assets/' );
			$tmpl['customclockcode'] 	= '';
			$paramsG					= array();
			$button						= '';
		
		} else if ($tmpl['phocagallery'] == 0) {
			
			JHTML::stylesheet( 'phocamenu.css', 'components/com_phocamenu/assets/' );
			//$tmpl['customclockcode'] 	= '';
			$paramsG					= array();
			$button						= '';
		
		} else {
			
			$tmpl['phocagallery']		= 1;
			JHTML::stylesheet( 'phocamenu.css', 'components/com_phocamenu/assets/' );
			PhocaMenuHelper::includePhocaGallery();
			
			$paramsG['imagedetailwindow']			= $params->get( 'image_detail_window', 2 );
			$paramsG['detailwindowbackgroundcolor']	= $params->get( 'detail_window_background_color', '#ffffff' );
			$paramsG['modalboxoverlaycolor']		= $params->get( 'modal_box_overlay_color', '#000000' );
			$paramsG['modalboxoverlayopacity']		= $params->get( 'modal_box_overlay_opacity', 0.3 );
			$paramsG['modalboxbordercolor']			= $params->get( 'modal_box_border_color', '#6b6b6b' );
			$paramsG['modalboxborderwidth']			= $params->get( 'modal_box_border_width', 2 );
			$paramsG['frontmodalboxwidth']			= $params->get( 'front_modal_box_width', 680 );
			$paramsG['frontmodalboxheight']			= $params->get( 'front_modal_box_height', 560 );
			
			$tmpl['imagesize']						= $params->get( 'image_size', 'small' );
			
			$button = PhocaMenuGallery::getPhocaGalleryBehaviour($paramsG);
		}
	
		
		$this->assign('button', $button);
		$this->assign('paramsg', $paramsG);
		$this->assign('data', $data);
		$this->assign('params', $params);
		$this->assign('tmpl', $tmpl);
		
		parent::display($tpl);
	}
}
?>