<?php // no direct access
defined('_JEXEC') or die('Restricted access');

if ($this->params->get('show_page_title', 1) && $this->params->get('page_title') != '') {
	echo '<div class="contentpagetitle'
	.$this->params->get( 'pageclass_sfx' ).'">' 
	. $this->params->get( 'page_title' ) . '</div>';
}

echo PhocaMenuFrontRender::renderFrontIcons($this->params->get('pdf'), $this->params->get('print'), $this->params->get('email'), $this->tmpl['printview'],  $this->params->get('icons'));

echo PhocaMenuRenderViews::renderDailyMenu($this->data, $this->tmpl, $this->params,$this->paramsg);
?>