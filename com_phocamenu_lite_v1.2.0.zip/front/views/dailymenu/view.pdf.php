<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
jimport('joomla.application.component.view');
class PhocaMenuViewDailyMenu extends JView
{
	function display($tpl = null) {
		
		global $mainframe;		
		$document			= & JFactory::getDocument();
		$params				= &$mainframe->getParams();
		$model 				= &$this->getModel('Menu');
		$data				= &$model->getData(1);
		
		
		// Params
		$tmpl['dateclass']			= $params->get( 'date_class', 0 );
		$tmpl['customclockcode']	= $params->get( 'custom_clock_code', '' );
		$tmpl['daydateformat']		= $params->get( 'day_date_format', '%A, %d. %B %Y' );
		$tmpl['priceprefix']		= $params->get( 'price_prefix', '...' );
		
		// Phoca Gallery
		$tmpl['phocagallery']		= 0;
		$tmpl['customclockcode'] 	= '';
		$paramsG					= array();
		$button						= '';
		

		
		$output =  PhocaMenuRenderViews::renderDailyMenu($data, $tmpl, $params,$paramsG, 2);
		echo $output;
	}
}