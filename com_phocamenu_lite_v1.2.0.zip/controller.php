<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
jimport('joomla.application.component.controller');

// Submenu view
$view	= JRequest::getVar( 'view', '', '', 'string', JREQUEST_ALLOWRAW );
$type	= JRequest::getVar( 'type', '', '', 'string', JREQUEST_ALLOWRAW );


$items 		= array();
$items[0]	= array('Control Panel', 'index.php?option=com_phocamenu');
$items[1]	= array('Daily Menu', 'index.php?option=com_phocamenu&view=phocamenugroups&type=1');
$items[9]	= array('Info', 'index.php?option=com_phocamenu&view=phocamenuinfo');

foreach ($items as $key => $value) {
	if ($view == '' || $view == 'phocamenucp') {
		if ($key == 0) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 1) && ($view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 1) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 2) && ($view == 'phocamenudays'  || $view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 2) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 3) && ($view == 'phocamenulists' || $view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 3) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 4) && ($view == 'phocamenulists'  || $view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 4) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 5) && ($view == 'phocamenulists' || $view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 5) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 6) && ($view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 6) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 7) && ($view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 7) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if (($type == 8) && ($view == 'phocamenugroups' || $view == 'phocamenuitems')) {
		if ($key == 8) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
	
	if ($view == 'phocamenuinfo') {
		if ($key == 9) {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1], true);
		} else {
			JSubMenuHelper::addEntry(JText::_($value[0]), $value[1]);
		}
	}
}

class PhocaMenuCpController extends JController
{
	function __construct($config = array()) {
		parent::__construct($config);
	}
	
	function display() {
		parent::display();
	}
	
}
?>
