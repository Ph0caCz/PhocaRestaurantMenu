<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */ 

class PhocaMenuFrontRender
{
	function renderFrontIcons($pdf = false, $print = false, $email = false, $printView = false, $paramsIcons) {
		
		$output = '';
		if ($pdf || $print || $email) {
			
			$output = '<div id="phocamenuicons"><div class="pm-buttons">';
			
			if (!$printView) {
				
				if ($pdf) {
					$output .= PhocaMenuFrontRender::getIconPDF($paramsIcons) . '&nbsp;';
				}
				
				if ($print) {
					$output .= PhocaMenuFrontRender::getIconPrint($paramsIcons) . '&nbsp;';
				}
				
				if ($email) {
					$output .= PhocaMenuFrontRender::getIconEmail($paramsIcons) . '&nbsp;';
				}
			} else {
				$output .= PhocaMenuFrontRender::getIconPrintScreen($paramsIcons) . '&nbsp;'
						. ' <a href="javascript: void window.close()">'
						. JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-close.png', JText::_( 'Close Window' ))
						. '</a>';
			}
			
			$output .= '</div></div>';
		}
		return $output;
	}
	
	function getIconPDF($paramsIcons) {
		
		//Phoca PDF Restaurant Menu Plugin:
		$plugin =& JPluginHelper::getPlugin('phocapdf', 'restaurantmenu');
		
		// Plugin is installed, Plugin is enabled
		if(!empty($plugin)) {
			
			$pluginP 		= new JParameter( $plugin->params );
			$pdfDestination	= $pluginP->get('pdf_destination', 'S');
			
			$view	= JRequest::getCmd( 'view' );
			$url	= 'index.php?option=com_phocamenu&view='.$view.'&tmpl=component&format=phocapdf';
			$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';
			
			if ($paramsIcons) {
				$text = JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-pdf.png', JText::_('PDF'));
			} else {
				$text = JText::_('PDF');
			}
			$attribs['title']	= JText::_( 'PDF' );
			
			$browser = PhocaMenuHelper::PhocaMenuBrowserDetection('browser');
			if ($browser == 'msie7' || $browser == 'msie8') {
				$attribs['target'] 	= "_blank";
			} else {
				if ($pdfDestination == 'I' || $pdfDestination == 'D') {
					// Remome OnClick
				} else {
					$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
				}
			}	
			
			$output	= JHTML::_('link', JRoute::_($url), $text, $attribs);
		
		} else {
			
			$output = '<a href="#" title="'.JText::_('Phoca PDF Restaurant Menu Plugin is not installed or it is disabled').'">'.JHTML::_('image', '/components/com_phocamenu/assets/images/icon-16-pdf-dis.png', JText::_('PDF')) . '</a>';
		}
		
		
		return $output;
	}
	
	function getIconPrint($paramsIcons) {
		
		$view	= JRequest::getCmd( 'view' );
		$url	= 'index.php?option=com_phocamenu&view='.$view.'&tmpl=component&print=1';
		$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';
		
		if ($paramsIcons) {
			$text = JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-print.png', JText::_('Print'));
		} else {
			$text = JText::_('Print');
		}
		$attribs['title']	= JText::_( 'Print' );
		$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
		$output				= JHTML::_('link', JRoute::_($url), $text, $attribs);	
		return $output;
	}
	
	function getIconEmail($paramsIcons) {
	
		$uri	= &JFactory::getURI();
		
		
		$url	= 'index.php?option=com_mailto&tmpl=component&link='.base64_encode( $uri->toString() );
		
		$status = 'width=400,height=300,menubar=yes,resizable=yes';
		
		if ($paramsIcons) {
			$text = JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-email.png', JText::_('Email'));
		} else {
			$text = JText::_('Email');
		}
		$attribs['title']	= JText::_( 'Email' );
		$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
		$output				= JHTML::_('link', JRoute::_($url), $text, $attribs);
		return $output;		
	}
	
	function getIconPrintScreen($paramsIcons) {

		if ($paramsIcons) {
			$text = JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-print.png', JText::_('Print'));
		} else {
			$text = JText::_('Print');
		}
		$output = '<a href="javascript: void()" onclick="window.print();return false;">'.$text.'</a>';
		return $output;
		
	}
}
?>