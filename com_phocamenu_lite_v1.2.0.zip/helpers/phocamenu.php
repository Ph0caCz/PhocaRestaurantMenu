<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */ 

class PhocaMenuHelper
{
	function getTypeTable($type) {
		switch($type) {
			case 2:
				$table = '#__phocamenu_day';
			break;
			case 3:
			case 4:
			case 5:
				$table = '#__phocamenu_list';
			break;
			default:
				$table = '';
			break;
		}
		return $table;
	}
	
	
	function getTypeInfo($view, $type) {
		$typeInfo			= array();
		$typeInfo['type']	= $type;
		$typeInfo['view']	= $view;
		
		switch ($type) {
			case 1:
				switch($view) {
					case 'group':
						$typeInfo['backlink']		= '';
						$typeInfo['backlinktxt']	= 'Control Panel';
						$typeInfo['text']			= JText::_('Daily Menu Group');
					break;
					
					case 'item':
						$typeInfo['backlink']		= '&view=phocamenugroups&type=1';
						$typeInfo['backlinktxt']	= 'Groups';
						$typeInfo['text']			= JText::_('Daily Menu Item');
					break;
					
					case 'config':
						$typeInfo['backlink']		= '';
						$typeInfo['backlinktxt']	= '';
						$typeInfo['text']			= JText::_('Daily Menu Settings');
					break;
				}
				$typeInfo['catid']			= 'gid';
				$typeInfo['pref']			= 'dm';
				$typeInfo['frontview']		= 'dailymenu';
				$typeInfo['render']			= 'renderDailyMenu';
				$typeInfo['title']			= JText::_('Daily Menu');
			break;
		}
		return $typeInfo;
	}
	
	function displayToolbarTools($displayToolbars, $type) {
	
		switch ($displayToolbars) {
			case 1:
				return true;
			break;
			case 2:
				if ((int)$type < 2 || (int)$type > 5) {
					return true;
				} else {
					return false;
				}
			break;
			case 0:
			default:
				return false;
			break;
		
		}
		return false;
	}
	
	
	function getBreadcrumbs($current, $backLink = '', $backLinkText = '', $backLinkUp = '', $backLinkTextUp = '') {
		
		$arrowImg	= JHTML::_('image.site',  'icon-arrow.png', '/components/com_phocamenu/assets/images/', NULL, NULL, '' );
		$back 		= '';
		$backUp		= '';
		
		if ($backLinkUp != '') {
			$backUp	= '<span class="arrow"> '.$arrowImg.' </span>'
					 .'<a href="index.php?option=com_phocamenu'.$backLinkUp.'">'. $backLinkTextUp.'</a>';
		}
		
		if ($backLink != '') {
			$back	= '<span class="arrow"> '.$arrowImg.' </span>'
					 .'<a href="index.php?option=com_phocamenu'.$backLink.'">'. $backLinkText.'</a>';
		}
		
		$breadcrumbs = '<div id="phocamenubreadcrumb">'
					  .'<a href="index.php?option=com_phocamenu">'. JText::_('Control Panel').'</a>'
					  . $backUp . $back
					  .'<span class="arrow"> '.$arrowImg.' </span>'
					  . $current
					  .'</div>';
		return $breadcrumbs;
	}
	
	function getPriceFormat($price, $params = array()) {
		
		// Administration (no frontend)
		if (empty($params)) {
			$params = JComponentHelper::getParams('com_phocamenu');
		}
		$priceFormat		= $params->get( 'price_format', 0 );
		$priceCurSymbol		= $params->get( 'price_currency_symbol', '€' );
		$priceDecSymbol		= $params->get( 'price_dec_symbol', ',' );
		$priceThousandsSep	= $params->get( 'price_thousands_sep', '.' );
		$priceDecimals		= $params->get( 'price_decimals', 2 );
		$priceSuffix		= $params->get( 'price_suffix', '' );
		
		// Not possible to save space in parameters, not possible to use &nbsp; in number_format, not possible to use ''
		switch ($priceThousandsSep) {
			case '-':
				$priceThousandsSep = ' ';
			break;
			
			case '_':
				$priceThousandsSep = '';
			break;
		}
		
		$price = number_format($price, $priceDecimals, $priceDecSymbol, $priceThousandsSep) . $priceSuffix;
		switch($priceFormat) {
			case 1:
				$price = $price . $priceCurSymbol;
			break;
			
			case 2:
				$price = $priceCurSymbol . $price;
			break;
			
			case 3:
				$price = $priceCurSymbol . ' ' . $price;
			break;
			
			case 0:
			default:
				$price = $price . ' ' . $priceCurSymbol;
			break;
		}
		
		return $price;
	
	}
	
	// Category = Group, List, Day
	function getActualCategory ($categoryType, $filterCatid) {
		$postCategory	= JRequest::getVar( $categoryType, 0, 'POST', 'int' );
		$getCategory	= JRequest::getVar( $categoryType, 0, 'GET', 'int' );
		
		if ($postCategory > 0) {
			//$categoryId['catid']		= $postCategory;
			$categoryId['filter_catid']	= $filterCatid;
		} else {
			//$categoryId['catid']		= $getCategory;
			$categoryId['filter_catid']	= $getCategory;
		}

		return $categoryId;
	}
	
	function getDate($date, $dateFormat, $dateClass = 0) {	

		if ((int)$dateClass == 1) {
			// We call this function from frontend and backend, so no JPATH_SITE can be used
			require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenuczechdate.php' );
			$date = PhocaMenuCzechDate::display(JHTML::Date($date, JText::_($dateFormat)));
		} else {
			$date = JHTML::Date($date,JText::_( $dateFormat));
		}
		return $date;
	}
	
	function includePhocaGallery() {
		
		if (!class_exists('PhocaGalleryLoader')) {
			require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocagallery'.DS.'libraries'.DS.'loader.php');
		}
		require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenugallery.php' );
		phocagalleryimport('phocagallery.path.path');
		phocagalleryimport('phocagallery.file.file');
		phocagalleryimport('phocagallery.image.imagefront');
		phocagalleryimport('phocagallery.render.renderfront');
		phocagalleryimport('phocagallery.file.filethumbnail'); 
		phocagalleryimport('phocagallery.library.library'); 
	}
	

	function getPhocaVersion() {
		$component = 'com_phocamenu';
		$folder = JPATH_ADMINISTRATOR .DS. 'components'.DS.$component;
		
		if (JFolder::exists($folder)) {
			$xmlFilesInDir = JFolder::files($folder, '.xml$');
		} else {
			$folder = JPATH_SITE .DS. 'components'.DS.$component;
			if (JFolder::exists($folder)) {
				$xmlFilesInDir = JFolder::files($folder, '.xml$');
			} else {
				$xmlFilesInDir = null;
			}
		}

		$xml_items = '';
		if (count($xmlFilesInDir))
		{
			foreach ($xmlFilesInDir as $xmlfile)
			{
				if ($data = JApplicationHelper::parseXMLInstallFile($folder.DS.$xmlfile)) {
					foreach($data as $key => $value) {
						$xml_items[$key] = $value;
					}
				}
			}
		}
		
		if (isset($xml_items['version']) && $xml_items['version'] != '' ) {
			return $xml_items['version'];
		} else {
			return '';
		}
	}
	
	function renderCode($id, $method){
		$v	= PhocaMenuHelper::getPhocaVersion();
		$i	= str_replace('.', '',substr($v, 0, 3));
		$n	= '<p>&nbsp;</p>';
		$l	= 'h'.'t'.'t'.'p'.':'.'/'.'/'.'w'.'w'.'w'.'.'.'p'.'h'.'o'.'c'.'a'.'.'.'c'.'z'.'/'.'p'.'h'.'o'.'c'.'a'.'m'.'e'.'n'.'u';
		$t	= 'P'.'o'.'w'.'e'.'r'.'e'.'d'.' '.'b'.'y';
		$p	= 'P'.'h'.'o'.'c'.'a'.' '.'R'.'e'.'s'.'t'.'a'.'u'.'r'.'a'.'n'.'t'.' '.'M'.'e'.'n'.'u';
		$s	= 's'.'t'.'y'.'l'.'e'.'='.'"'.'t'.'e'.'x'.'t'.'-'.'d'.'e'.'c'.'o'.'r'.'a'.'t'.'i'.'o'.'n'.':'.'n'.'o'.'n'.'e'.'"';
		$s2	= 's'.'t'.'y'.'l'.'e'.'='.'"'.'t'.'e'.'x'.'t'.'-'.'a'.'l'.'i'.'g'.'n'.':'.'c'.'e'.'n'.'t'.'e'.'r'.';'.'c'.'o'.'l'.'o'.'r'.':'.'#'.'d'.'3'.'d'.'3'.'d'.'3'.'"';
		$b	= 't'.'a'.'r'.'g'.'e'.'t'.'='.'"'.'_'.'b'.'l'.'a'.'n'.'k'.'"';
		$i	= (int)$i + $i;
		
		$output	= '';
		if ($id != $i) {
			$output		.= $n;
			$output		.= '<div '.$s2.'>';
		}
		
		if ($id == $i) {
			$output	.= '<!-- <a href="'.$l.'">site: www.phoca.cz | version: '.$v.'</a> -->';
		} else {
			$output	.= $t . ' <a href="'.$l.'" '.$s.' '.$b.' title="'.$p.'">'. $p. '</a>';
		}
		if ($id != $i) {
			$output		.= '</div>' . $n;
		}
		if ($method == 2 || $method == 1) {
			$output = '';
		}
		return $output;
	}
	
	/*
	Script Name: Simple 'if' PHP Browser detection
	Author: Harald Hope, Website: http://TechPatterns.com/
	Script Source URI: http://TechPatterns.com/downloads/php_browser_detection.php
	Version 2.0.2
	Copyright (C) 29 June 2007
	 
	Modified 22 April 2008 by Jon Czerwinski
	Added IE 7 version detection
	 
	This program is free software; you can redistribute it and/or modify it under 
	the terms of the GNU General Public License as published by the Free Software
	Foundation; either version 3 of the License, or (at your option) any later version.
	 
	This program is distributed in the hope that it will be useful, but WITHOUT 
	ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
	FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
	 
	Get the full text of the GPL here: http://www.gnu.org/licenses/gpl.txt
	 
	Coding conventions:
	http://cvs.sourceforge.net/viewcvs.py/phpbb/phpBB2/docs/codingstandards.htm?rev=1.3
	*/
	function PhocaMenuBrowserDetection( $which_test ) {
	 
		// initialize the variables
		$browser 		= '';
		$dom_browser	= '';
 
		// set to lower case to avoid errors, check to see if http_user_agent is set
		$navigator_user_agent = ( isset( $_SERVER['HTTP_USER_AGENT'] ) ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';
 
		// run through the main browser possibilities, assign them to the main $browser variable
		if (stristr($navigator_user_agent, "opera"))  {
			$browser 		= 'opera';
			$dom_browser 	= true;
		}
 
		/*
		Test for IE 7 added
		April 22, 2008
		Jon Czerwinski
		*/
		elseif (stristr($navigator_user_agent, "msie 7")) {
			$browser = 'msie7'; 
			$dom_browser = false;
		}
		
		elseif (stristr($navigator_user_agent, "msie 8")) {
			$browser = 'msie8'; 
			$dom_browser = false;
		}
 
		elseif (stristr($navigator_user_agent, "msie 4"))  {
			$browser = 'msie4'; 
			$dom_browser = false;
		}
 
		elseif (stristr($navigator_user_agent, "msie")) {
			$browser = 'msie'; 
			$dom_browser = true;
		}
 
		elseif ((stristr($navigator_user_agent, "konqueror")) || (stristr($navigator_user_agent, "safari"))) {
			$browser = 'safari'; 
			$dom_browser = true;
		}
 
		elseif (stristr($navigator_user_agent, "gecko")) {
			$browser = 'mozilla';
			$dom_browser = true;
		}
 
		elseif (stristr($navigator_user_agent, "mozilla/4")) {
			$browser = 'ns4';
			$dom_browser = false;
		}
 
		else {
			$dom_browser = false;
			$browser = false;
		}
 
		// return the test result you want
		if ( $which_test == 'browser' ) {
				return $browser;
		} elseif ( $which_test == 'dom' ) {
			return $dom_browser;
			//  note: $dom_browser is a boolean value, true/false, so you can just test if
			// it's true or not.
		}
	}
	
	/*
	 * @based based on Seb's BB-Code-Parser script by seb
	 * @url http://www.traum-projekt.com/forum/54-traum-scripts/25292-sebs-bb-code-parser.html 
	 */
	function bbCodeReplace($string, $currentString = '') {
	 
	    while($currentString != $string) {
			$currentString 	= $string;
			$string 		= preg_replace_callback('{\[(\w+)((=)(.+)|())\]((.|\n)*)\[/\1\]}U', array('PhocaMenuHelper', 'bbCodeCallback'), $string);
	    }
	    return $string;
	}

	/*
	 * @based based on Seb's BB-Code-Parser script by seb
	 * @url http://www.traum-projekt.com/forum/54-traum-scripts/25292-sebs-bb-code-parser.html 
	 */
	function bbCodeCallback($matches) {
		$tag 			= trim($matches[1]);
		$bodyString 	= $matches[6];
		$argument 		= $matches[4];
	    
	    switch($tag) {
			case 'b':
			case 'i':
			case 'u':
				$replacement = '<'.$tag.'>'.$bodyString.'</'.$tag.'>';
	            break;

	        default:    // unknown tag => reconstruct and return original expression
	            $replacement = '[' . $tag . ']' . $bodyString . '[/' . $tag .']';
	            break;
	    }
		return $replacement;
	}
	
	function replaceTag($string, $method) {
		
		switch($method) {
			case 2:
				$string = str_replace ( '[np]', '<tcpdf method="AddPage" />', $string );
			break;
			default:
				$string = str_replace ( '[np]', '', $string );
			break;
		}
		return $string;
	}
}
?>