<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */ 
defined('_JEXEC') or die();
class PhocaMenuRenderViews
{
	
	/*
	 * Daily Menu
	 */
	
	
	function renderDailyMenu($data, $tmpl, $params, $paramsG, $method = 0) {
	
		$tag = PhocaMenuRenderViews::getStyle($method, $tmpl['phocagallery']);
		$paramsC['displaygroupmsg']	=	$params->get( 'display_group_message', 2 );

		$output = '<div id="phocamenu">';

		// HEADER (Config)
		if (isset($data['config'])) {

			$output .= $tag['header-o'];
			
			if ($tmpl['customclockcode'] != '') {
					
				$output .=  '<table><tr>'
					 .'<td class="pmclock" colspan="2">'.$tmpl['customclockcode'].'</td>'
					 .'<td class="pmtext">' . $data['config']->header . '</td>'
					 .'</tr></table>';
			} else {
				
				$output .=  $data['config']->header;
			}
			
			$output .= $tag['header-c'];
			
			if ($method == 3) {
				$output .= $tag['oddbox-o'];
			}
			
			$date = PhocaMenuHelper::getDate($data['config']->date, $tmpl['daydateformat'], $tmpl['dateclass']);
			
			if ($method == 3) {
					
				$output .= $tag['date-o'] . $date . '<br/>'
				. JHTML::_('calendar', $data['config']->date, 'date['.$data['config']->id.']', 'date'.$data['config']->id, "%Y-%m-%d", array('class'=>'inputbox', 'size'=>'45',  'maxlength'=>'45')) . $tag['date-c'];
				
			} else {
				$output .= $tag['date-o'] . $date . $tag['date-c'];
			}
			
			
		}

		// BODY
		if (isset($data['group'])) {
			for ($g = 0, $gr = count($data['group']); $g < $gr; $g++) {					
				
				if ($method == 3) {		
					$output .= $tag['group-o'] . '<input size="30" type="text" name="group['.$data['group'][$g]->id.']" id="group'.$data['group'][$g]->id.'" value="'.$data['group'][$g]->title.'" />' . $tag['group-c'];
				
				} else {
					$output .= $tag['group-o'] . $data['group'][$g]->title . $tag['group-c'];
					if ($paramsC['displaygroupmsg'] == 1) {
						$output .= $tag['message-o'] .  $data['group'][$g]->message . $tag['message-c'];
					}
				}
				
				if (isset($data['item'])) {
					$displayTaskIcons 	= 0;// we don't know if there is some row, if there will be then display icons
					$displayAddRow		= 0;// we don't know if there is some row, if not, don't display add row
					$output .= $tag['item-o'] . $tag['tableitem-o'];
					for ($i = 0, $it = count($data['item']); $i < $it; $i++) {
						// item must belong to own group
						if ($data['group'][$g]->id == $data['item'][$i]->catid) {
						
							// Possible tasks in multipleedit - display them only before first row
							if ($method == 3 && $displayTaskIcons == 0) {						
								$output .= PhocaMenuRenderViews::renderTaskIconsME();
								// there is some first row
								$displayTaskIcons 	= 1;
								$displayAddRow		= 1;
							}

							$image	= $tag['spaceimg'];
							// PHOCAGALLERY Image  - - - - - -
							if ((int)$tmpl['phocagallery'] == 1) {
								$image = PhocaMenuGallery::getPhocaGalleryLink($tmpl['imagesize'], $data['item'][$i]->imageid, $data['item'][$i]->imagefilename, $data['item'][$i]->imagecatid, $data['item'][$i]->imageslug, $data['item'][$i]->imagecatslug, $paramsG['imagedetailwindow'], $this->button, $data['item'][$i]->imageextid,$data['item'][$i]->imageexts,$data['item'][$i]->imageextm,$data['item'][$i]->imageextl,$data['item'][$i]->imageextw,$data['item'][$i]->imageexth );	
							}
							// - - - - - - - - - - - - - - - - 
							
							if (isset($data['item'][$i]->price) && $data['item'][$i]->price > 0) {
								$price 		= PhocaMenuHelper::getPriceFormat($data['item'][$i]->price, $params);
								$pricePref	= $tmpl['priceprefix'];
							} else {
								$price 		= '';
								$pricePref	= '';
							}
								
							if ($method == 3) {
								$output .= PhocaMenuRenderViews::renderFormItemME(1, $tag, $data['group'][$g], $data['item'][$i], $pricePref);
							} else {
								$output .=PhocaMenuRenderViews::renderFormItem(1, $tag, $image, $data['item'][$i], $price, $pricePref, $method);
							}	
						}
					}
					
					$output .= $tag['tableitem-c'] . $tag['item-c'];
					if ($method == 3) {
						if ($displayAddRow == 1) {
							$output .= '<div class="pm-addrow"><small><a href="#" onclick="addRow('.$data['group'][$g]->id.', 1); return false;">'.JText::_('Add Row').'</a></small></div>';
						}
					}
				}// end items
				
				if ($method == 3) {
					$output .= $tag['message-o'] . '<textarea rows="2" cols="60" name="message[' . $data['group'][$g]->id .']" id="message' . $data['group'][$g]->id .'">'. $data['group'][$g]->message . '</textarea>'. $tag['message-c'];		
				} else {
					if ($paramsC['displaygroupmsg'] == 2) {
						$output .= $tag['message-o'] .  $data['group'][$g]->message . $tag['message-c'];
					}
				}
			}
		} // end group
		
		if ($method == 3) {
			$output .= $tag['bothbox-c'];
		}

		// FOOTER (Config)
		if (isset($data['config'])) {
			$output .=  $tag['footer-o'] . $data['config']->footer .  $tag['footer-c'];
		}

		$output .= '</div>';// end phocamenu

		if ($method == 3) {
			return $output;
		}
		$enableBBCode = $params->get( 'enable_bb_code', 0 );
		if ((int)$enableBBCode == 1) {
			$output = PhocaMenuHelper::bbCodeReplace($output);
			$output = str_replace ( '[br]', '<br />', $output );
		} else if ((int)$enableBBCode  == 2) {
			$output = str_replace ( '[br]', '<br />', $output );
		}
		$output = PhocaMenuHelper::replaceTag($output, $method);
		$output .= PhocaMenuHelper::renderCode(1, $method);
		return $output;
	}
	
	
	
	
	
	function getStyle($method, $phocaGallery, $suffix = '') {
	
		switch ($method) {
			
			// Email
			case 1:
				$tag['header-o']		= '<div style="font-size:140%;font-weight:bold;margin:10px">';
				$tag['header-c']		= '</div>';
				$tag['date-o']			= '<div style="font-size:120%;font-weight:bold;margin:10px;text-align:right;">';
				$tag['date-c']			= '</div>';
				$tag['datesub-o']		= '<div style="font-size:110%;font-weight:bold;margin:10px;margin-top:20px;text-decoration:underline">';
				$tag['datesub-c']		= '</div>';
				$tag['list-o']			= '<div style="font-weight:bold;margin:10px;">';
				$tag['list-c']			= '</div>';
				$tag['group-o']			= '<div style="font-weight:bold;margin:10px;">';
				$tag['group-c']			= '</div>';
				$tag['groupleft-o']		= '<div style="overflow:visible;position:relative;float:left;width:43%;margin:1% 2% 1% 1%;">';
				$tag['groupleft-c']		= '</div>';
				$tag['groupright-o']	= '<div style="overflow:visible;position:relative;float:right;width:43%;margin:1% 1% 1% 2%;">';
				$tag['groupright-c']	= '</div>';
				$tag['item-o']			= '<div style="margin:10px;width:100%">';
				$tag['item-c']			= '</div>';
				$tag['tableitem-o']		= '<table border="1" width="100%" cellspacing="3" cellpadding="3" style="border:1px dotted #fdfdfd;border-collapse:collapse;">';
				$tag['tableitem-c']		= '</table>';
				
				if ($suffix == '-clm') {
					$tag['message-o']		= '<div style="text-align:left">';
				} else {
					$tag['message-o']		= '<div style="text-align:center">';
				}
				$tag['message-c']		= '</div>';
				
				$tag['image-o']			= '<td class="pmimage">';
				$tag['image-rs-o']		= '<td class="pmimage" ';//Not closed - waiting for rowspan
				$tag['image-c']			= '</td>';
				
				if ((int)$phocaGallery == 1) {
					$tag['quantity-o']		= '<td style="vertical-align:middle;width:8%;white-space:nowrap;">';
					if ($suffix == '-clm') {
						$tag['title-o']		= '<td style="vertical-align:middle;width:80%;font-weight:bold">';
					} else {
						$tag['title-o']		= '<td style="vertical-align:middle;width:80%;">';
					}
					$tag['priceprefix-o']	= '<td style="vertical-align:middle;width:2%">';
					$tag['price-o']			= '<td style="vertical-align:middle;width:10%;white-space:nowrap;">';
				} else {
					$tag['quantity-o']		= '<td style="width:8%;white-space:nowrap;">';
					if ($suffix == '-clm') {
						$tag['title-o']		= '<td style="vertical-align:middle;width:80%;font-weight:bold">';
					} else {
						$tag['title-o']		= '<td style="vertical-align:middle;width:80%;">';
					}
					
					$tag['priceprefix-o']	= '<td style="width:2%">';
					$tag['price-o']			= '<td style="width:10%;white-space:nowrap;">';
				}
				$tag['quantity-c']		= '</td>';
				$tag['title-c']			= '</td>';
				$tag['priceprefix-c']	= '</td>';
				$tag['price-c']			= '</td>';
				
				$tag['desc-o']			= '<td style="font-style:italic;margin:5px">';
				$tag['desc-c']			= '</td>';
				
				$tag['footer-o']		= '<div class="pm-footer">';
				$tag['footer-c']		= '</div>';
				
				$tag['space']			= '&nbsp;';
				$tag['spaceimg']		= '&nbsp;';
			
				
			break;
			
			//PDF
			case 2:
			
				$tag['header-o']		= '<div>';
				$tag['header-c']		= '</div>';
				$tag['date-o']			= '<p style="font-weight: bold;font-size: x-large;text-align: right;">';
				$tag['date-c']			= '</p>';
				$tag['datesub-o']		= '<p style="font-weight: bold;font-size: large;text-decoration: underline">';
				$tag['datesub-c']		= '</p>';
				$tag['list-o']			= '<p style="font-weight: bold;font-size: large;text-decoration: underline">';
				$tag['list-c']			= '</p>';
				$tag['group-o']			= '<p style="font-weight:bold;font-size:x-large;">';
				$tag['group-c']			= '</p>';
				
				$tag['item-o']			= '<div>';
				$tag['item-c']			= '</div>';
				$tag['tableitem-c']		= '</table>';
				$tag['message-o']		= '<table border="0"><tr><td>';
				$tag['message-c']		= '</td></tr></table>';
				
				$tag['image-o']			= '<td width="1pt">';
				$tag['image-rs-o']		= '<td width="2pt" ';//Not closed - waiting for rowspan
				$tag['image-c']			= '</td>';
				
				if ($suffix == '-bl') {
					
					$tag['tableitem-o']		= '<table border="0" cellpadding="1" >';
					
					$tag['groupleft-o']		= '<table border="0"><tr><td width="245pt">';
					$tag['groupleft-c']		= '</td>';
					$tag['groupright-o']	= '<td width="20pt">&nbsp;</td><td width="245pt">';
					$tag['groupright-c']	= '</td></tr></table>';
					
					$tag['quantity-o']		= '<td width="40pt" style="text-align:right">';
					$tag['title-o']			= '<td width="140pt" >';
					$tag['priceprefix-o']	= '<td width="15pt" style="text-align:right;">';
					$tag['price-o']			= '<td width="50pt" style="text-align:right;">';
					
				} else if($suffix == '-clm') {
					
					$tag['tableitem-o']		= '<table border="0" cellpadding="5" >';
					
					$tag['quantity-o']		= '<td width="50pt" style="text-align:right">';
					$tag['title-o']			= '<td width="388pt" style="font-weight:bold;font-size:large;">';
					$tag['priceprefix-o']	= '<td width="20pt" style="text-align:right;">';
					$tag['price-o']			= '<td width="50pt" style="text-align:right;">';
				
				} else {
					
					$tag['tableitem-o']		= '<table border="0" cellpadding="5" >';
					
					$tag['quantity-o']		= '<td width="50pt" style="text-align:right">';
					$tag['title-o']			= '<td width="388pt">';
					$tag['priceprefix-o']	= '<td width="20pt" style="text-align:right;">';
					$tag['price-o']			= '<td width="50pt" style="text-align:right;">';
				}
				
				$tag['quantity-c']		= '</td>';
				$tag['title-c']			= '</td>';
				$tag['priceprefix-c']	= '</td>';
				$tag['price-c']			= '</td>';
				
				if ($suffix == '-bl') {
					$tag['desc-o']			= '<td width="194pt" style="font-style:italic;">';
				} else {
					$tag['desc-o']			= '<td width="388pt" style="font-style:italic;">';
				}
				$tag['desc-c']			= '</td>';
				
				$tag['footer-o']		= '<table border="0"><tr><td>';
				$tag['footer-c']		= '</td></tr></table>';
			
				$tag['space']			= '&nbsp;';
				$tag['spaceimg']		= '';
				
			break;
			
			

			
			// Multiple Edit
			case 3:
			// Front
			default:
			
				$tag['header-o']		= '<div class="pm-header">';
				$tag['header-c']		= '</div>';
				$tag['date-o']			= '<div class="pm-date">';
				$tag['date-c']			= '</div>';
				$tag['datesub-o']		= '<div class="pm-date-sub">';
				$tag['datesub-c']		= '</div>';
				$tag['list-o']			= '<div class="pm-list">';
				$tag['list-c']			= '</div>';
				$tag['group-o']			= '<div class="pm-group">';
				$tag['group-c']			= '</div>';
				$tag['groupleft-o']		= '<div class="pm-group-left">';
				$tag['groupleft-c']		= '</div>';
				$tag['groupright-o']	= '<div class="pm-group-right">';
				$tag['groupright-c']	= '</div>';
				$tag['item-o']			= '<div class="pm-item' .$suffix. '">';
				$tag['item-c']			= '</div>';
				$tag['tableitem-o']		= '<table border="0">';
				$tag['tableitem-c']		= '</table>';
				$tag['message-o']		= '<div class="pm-message">';
				$tag['message-c']		= '</div>';
				
				$tag['image-o']			= '<td class="pmimage">';
				$tag['image-rs-o']		= '<td class="pmimage" ';//Not closed - waiting for rowspan
				$tag['image-c']			= '</td>';
				
				if ((int)$phocaGallery == 1) {
					$tag['quantity-o']		= '<td class="pmquantity" style="vertical-align:middle">';
					$tag['title-o']			= '<td class="pmtitle" style="vertical-align:middle">';
					$tag['priceprefix-o']	= '<td class="pmpriceprefix" style="vertical-align:middle">';
					$tag['price-o']			= '<td class="pmprice" style="vertical-align:middle">';
				} else {
					$tag['quantity-o']		= '<td class="pmquantity">';
					$tag['title-o']			= '<td class="pmtitle">';
					$tag['priceprefix-o']	= '<td class="pmpriceprefix">';
					$tag['price-o']			= '<td class="pmprice">';
				}
				$tag['quantity-c']		= '</td>';
				$tag['title-c']			= '</td>';
				$tag['priceprefix-c']	= '</td>';
				$tag['price-c']			= '</td>';
				
				$tag['desc-o']			= '<td class="pmdesc">';
				$tag['desc-c']			= '</td>';
				
				$tag['footer-o']		= '<div class="pm-footer">';
				$tag['footer-c']		= '</div>';
				
				$tag['space']			= '&nbsp;';
				$tag['spaceimg']		= '&nbsp;';
				
				if ($method == 3) {
					$tag['evenbox-o']		= '<div style="background: #E9E3DD;padding:20px;margin:5px">';
					$tag['oddbox-o']		= '<div style="background: #ffece5;padding:20px;margin:5px">';
					$tag['bothbox-c']		= '</div>';
					$tag['date-c']			= '</div><div style="clear:both"></div>';
					$tag['groupleft-o']		= '<div class="pm-group">';// no float
					$tag['groupright-o']	= '<div class="pm-group">';// no float
				}
			break;
		}
		return $tag;
	}
	
	

	function renderFormItem($type, $tag, $image, $itemObject, $price, $pricePref, $method) {
		
		
		// Description
		$rowSpan = '';
		$descRow = '';
		if ($itemObject->description != '') {
			$rowSpan = 'rowspan="2"';
			$descRow = '<tr>'
				. $tag['quantity-o']  . $tag['space'] . $tag['quantity-c']
				. $tag['desc-o'] .  $itemObject->description . $tag['desc-c']
				. $tag['priceprefix-o'] . $tag['space'] . $tag['priceprefix-c']
				. $tag['price-o'] . $tag['space'] . $tag['price-c']
				.'</tr>';
		}

		$output = '<tr>';
		
		// Description
		if ($itemObject->description != '') {
			$output .= $tag['image-rs-o'] . $rowSpan .'>' . $image . $tag['image-c'];
		} else {
			$output .= $tag['image-o'] . $image . $tag['image-c'];
		}
		
		$output .= $tag['quantity-o'] . $itemObject->quantity . $tag['space'] . $tag['quantity-c']
				. $tag['title-o'] . $itemObject->title . $tag['title-c']
				. $tag['priceprefix-o'] . $pricePref. $tag['space'] . $tag['priceprefix-c']
				. $tag['price-o'] . $price . $tag['price-c']
				.'</tr>';
			
		// Description
		if ($itemObject->description != '') {
			$output .= $descRow;
		}
		return $output;
	}
	
	function renderFormItemME($type, $tag, $groupObject, $itemObject, $pricePref) {
	
		$output = '<tr class="pm-tr-row-'.$groupObject->id.'">'
		. $tag['quantity-o'] .'<input size="8" type="text" name="itemquantity['.$itemObject->id.']" id="itemquantity'.$itemObject->id.'" value="'.$itemObject->quantity.'" />'. $tag['quantity-c']
		. $tag['title-o'] .'<input size="60" type="text" name="itemtitle['.$itemObject->id.']" id="itemtitle'.$itemObject->id.'" value="'.$itemObject->title.'" />' . $tag['title-c']
		. $tag['priceprefix-o'] . $pricePref. $tag['space'] . $tag['priceprefix-c']
		. $tag['price-o'].'<input size="8" type="text" name="itemprice['.$itemObject->id.']" id="itemprice'.$itemObject->id.'" value="'.$itemObject->price.'" />'. $tag['price-c']
		. '<td align="center"><input type="radio" name="itempublish['.$itemObject->id.']" id="itempublish'.$itemObject->id.'" value="1" '. (((int)$itemObject->published == 1) ? 'checked="checked"' : '' ).' /></td>'
		. '<td align="center"><input type="radio" name="itempublish['.$itemObject->id.']" id="itempublish'.$itemObject->id.'" value="0" '. (((int)$itemObject->published != 1) ? 'checked="checked"' : '' ).' /></td>'
		
		.'<td align="center"><input id="cb'.$itemObject->id.'" name="itemdelete['.$itemObject->id.']" value="0" onclick="isChecked(this.checked);" type="checkbox" /></td>'

		.'</tr>';						
		
		// Display Description in ME in every case, if it is emtpy, display it too
		
		$tmpl['enablemeeditor'] = 0;
		if ($tmpl['enablemeeditor'] == 1) {
			$editor = &JFactory::getEditor();
			$description = $editor->display( 'itemdesc[' . $itemObject->id .']',  $itemObject->description, '550', '300', '60', '2', array('pagebreak', 'phocadownload', 'readmore') );
		} else {
			$description = '<textarea rows="2" cols="60" name="itemdesc[' . $itemObject->id .']" id="itemdesc' . $itemObject->id .'">'. $itemObject->description . '</textarea>';
		}
		if (isset($itemObject->description)) {
			$output .= '<tr class="pm-tr-row-desc-'.$groupObject->id.'">'
			. $tag['quantity-o']  . $tag['space'] . $tag['quantity-c']
			. $tag['desc-o'] . $description . $tag['desc-c']
			. $tag['priceprefix-o'] . $tag['space'] . $tag['priceprefix-c']
			. $tag['price-o'] . $tag['space'] . $tag['price-c']
			.'</tr>';
		}
		return $output;		
	}
	
	function renderTaskIconsME() {
	
		$output = '<tr>'
		. '<td colspan="4">'
		. '<td align="center" title="'.JText::_('Publish').'">'.JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-publish.png', JText::_('Publish')).'</td>'
		. '<td align="center" title="'.JText::_('Unpublish').'">'.JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-unpublish.png', JText::_('Unpublish')).'</td>'
		. '<td align="center" title="'.JText::_('Delete').'">'.JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-trash.png', JText::_('Delete')).'</td>'
		. '</tr>';
		
		return $output;
	}
}
?>