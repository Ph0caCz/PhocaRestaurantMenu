<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */ 

class PhocaMenuRender
{
	function renderFormInput($id, $title, $value, $size = 50, $maxlength = 250, $style = '') {
		
		$styleOutput = '';
		if ($style != '') {
			$styleOutput = 'style="'.$style.'"';
		}
		
		$output = '<tr>'
				 .'<td width="100" align="right" class="key">'
				 .'<label for="'.$id.'">'.JText::_($title).':</label>'
				 .'</td><td>'
				 .'<input class="text_area" type="text" name="'.$id.'" id="'.$id.'" size="'.$size.'" maxlength="'.$maxlength.'" value="'.$value.'" '.$styleOutput.' />'
				.'</td></tr>';
		return $output;
	}
	
	function renderFormTextArea($id, $title, $value, $cols = 60, $rows = 5, $style = '') {
		
		$styleOutput = '';
		if ($style != '') {
			$styleOutput = 'style="'.$style.'"';
		}
		
		$output = '<tr>'
				 .'<td width="100" align="right" class="key">'
				 .'<label for="'.$id.'">'.JText::_($title).':</label>'
				 .'</td><td>'
				 .'<textarea class="text_area" cols="'.$cols.'" rows="'.$rows.'" name="'.$id.'" id="'.$id.'" '.$styleOutput.'>'.$value.'</textarea>'
				.'</td></tr>';
		return $output;
	}

	
	function renderFormItemSpecial($id, $title, $special) {
		
		$output = '<tr>'
				 .'<td width="100" align="right" class="key">'
				 .'<label for="'.$id.'">'.JText::_($title).':</label>'
				 .'</td><td>'
				 . $special
				 .'</td></tr>';
		return $output;
	}
	
	function renderFormItemImageButton($id, $title, $value, $size = 50, $maxlength = 250, $button) {
		
		$output = '<tr>'
				 .'<td width="100" align="right" class="key">'
				 .'<label for="'.$id.'">'.JText::_($title).':</label>'
				 .'</td><td>'
				 .'<input class="text_area" type="text" name="'.$id.'" id="'.$id.'" value="'.$value.'" size="'.$size.'" maxlength="'.$maxlength.'" />'
				 .'</td>'
				 .'<td align="left" valign="middle">'
				 .'<div class="button2-left" style="display:inline">'
				 .'<div class="'.$button->name.'">'
				 .'<a class="'.$button->modalname.'" title="'.$button->text.'" href="'.$button->link.'" rel="'.$button->options.'">'.$button->text.'</a>'
				 .'</div>'
				 .'</div>'
				 .'</td></tr>';
		return $output;
	}
	
	
	function renderFormStyle() {
	
		$output = '<style type="text/css">'
				.'table.paramlist td.paramlist_key {'
				.'width: 92px;'
				.'text-align: left;'
				.'height: 30px;'
				.'}'
				.'</style>';
		return $output;
	}
	
	function renderSubmitButtonJs($itemArray) {
	
		$output = "\n" .'<script language="javascript" type="text/javascript">' . "\n";
		$output .= 'function submitbutton(pressbutton) {' ."\n"
				.'	var form = document.adminForm;' ."\n"
				.'	if (pressbutton == \'cancel\') {' ."\n"
				.'		submitform( pressbutton );' ."\n"
				.'		return;' ."\n"
				.'	}' . "\n\n";
		
		if (is_array($itemArray)) {
		
			foreach ($itemArray as $key => $value) {
			
				if ($value[3] == 0) {
					$equal = '0';
				} else {
					$equal = '""';
				}
				
				if ($key == 0) {
					$output .= 'if (form.'.$value[0].'.value == '.$equal.'){' . "\n"
							.'    alert( "'.JText::_($value[1], $value[2] ).'" )' . "\n"
							.' }';
				
				}
				if ($key > 0) {
					$output .= ' else if (form.'.$value[0].'.value == '.$equal.'){' . "\n"
							.'    alert( "'.JText::_($value[1], $value[2] ).'" )' . "\n"
							.' }';
				
				}
			}
		}
		
		$output .= ' else {' . "\n"
				.'    submitform( pressbutton );'."\n"
				.' }'. "\n"
				.'}'. "\n";
		$output .= '</script>';
		
		return $output;
	}
	
	function getIconPDFAdministrator($view, $link = 0) {
		
		//Phoca PDF Restaurant Menu Plugin:
		$pluginPDF	 	=&JPluginHelper::getPlugin('phocapdf', 'restaurantmenu');
		$componentPDF	=&JComponentHelper::isEnabled('com_phocapdf', true);

		// Plugin is installed, Plugin is enabled
		if(!empty($pluginPDF) && !empty($componentPDF)) {
			
			$pluginP 		= new JParameter( $pluginPDF->params );
			$pdfDestination	= $pluginP->get('pdf_destination', 'S');
			
			$url		= JURI::root().'index.php?option=com_phocamenu&view='.$view.'&tmpl=component&format=phocapdf&admin=1';
			$urlTools	= JURI::root().'index.php?option=com_phocamenu&view='.$view.'&tmpl=component&format=phocapdf&admintool=1';
			$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';
			
			$text = '<span class="icon-32-pdf" title="'.JText::_('Print PDF').'" type="Custom"></span>'.JText::_('Print PDF');
			
			$attribs['title']	= JText::_( 'PDF' );
			
			$browser = PhocaMenuHelper::PhocaMenuBrowserDetection('browser');
			if ($browser == 'msie7') {
				$attribs['target'] 	= "_blank";
				$attribute			= 'target="_blank"';
			} else {
				$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
				$attribute			= 'onclick="'.$attribs['onclick'].'"';
			}	
			
			$output					= JHTML::_('link', JRoute::_($url), $text, $attribs);
			// Administration Print PDF - Row Tools (used by lists and days)
			$outputTools['url']		= $urlTools;
			$outputTools['attribs']	= $attribute;
		
		} else {
			
			$url	= '#';
			$attribs= array();
			$text 	= '<span class="icon-32-pdf-dis" title="'.JText::_('Phoca PDF Restaurant Menu Plugin is not installed or it is disabled').'" type="Custom"></span>'.JText::_('Print PDF');
			$output	= JHTML::_('link', JRoute::_($url), $text, $attribs);
			// Administration Print PDF - Row Tools (used by lists and days)
			$outputTools['url']		= '';
			$outputTools['attribs']	= '';
		
		}
		
		// Toolbar
		if ($link ==0) {
			return $output;
		} else {
			return $outputTools;
		}
	}
	
	function quickIconButton( $component, $link, $image, $text ) {
		
		$lang	= &JFactory::getLanguage();
		$button = '';
		if ($lang->isRTL()) {
			$button .= '<div style="float:right;">';
		} else {
			$button .= '<div style="float:left;">';
		}
		$button .=	'<div class="icon">'
				   .'<a href="'.$link.'">'
				   .JHTML::_('image.site',  $image, '/components/'.$component.'/assets/images/', NULL, NULL, $text )
				   .'<span>'.$text.'</span></a>'
				   .'</div>';
		$button .= '</div>';

		return $button;
	}
}
?>