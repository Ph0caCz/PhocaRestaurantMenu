<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();

class PhocaMenuCpControllerPhocaMenuGroup extends PhocaMenuCpController
{
	function __construct() {
		parent::__construct();

		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'apply'  , 'save' );
	}
	
	function edit() {
		
		JRequest::setVar( 'view', 'phocamenugroup' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar( 'hidemainmenu', 1 );

		parent::display();

		$model = $this->getModel( 'phocamenugroup' );
		$model->checkout();
	}
	
	function cancel() {
		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		
		$model	= $this->getModel( 'phocamenugroup' );
		$model->checkin();
		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid );
	}
	
	function publish() {
		
		global $mainframe;
		
		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		$cid 		= JRequest::getVar( 'cid', array(), 'post', 'array' );

		JArrayHelper::toInteger($cid);
		
		if (count($cid ) < 1) {
			JError::raiseError(500, JText::_( 'Select an item to publish' ) );
		}

		$model = $this->getModel('phocamenugroup');
		if(!$model->publish($cid, 1)) {
			echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
		}

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid );
	}

	function unpublish() {
		global $mainframe;

		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		$cid 		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		
		JArrayHelper::toInteger($cid);

		if (count( $cid ) < 1) {
			JError::raiseError(500, JText::_( 'Select an item to unpublish' ) );
		}

		$model = $this->getModel('phocamenugroup');
		if(!$model->publish($cid, 0)) {
			echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
		}

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenugroups&type='.$type .'&'.$typeCatid.'='. (int) $catid);
	}
	
	function orderup() {
		
		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		$cid 		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		
		$model 	= $this->getModel( 'phocamenugroup' );
		$model->move(-1);

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid );
	}

	function orderdown() {
		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		$cid 		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		
		$model 	= $this->getModel( 'phocamenugroup' );
		$model->move(1);

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid );
	}

	function saveorder() {
		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		$cid 		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$order 		= JRequest::getVar( 'order', array(), 'post', 'array' );
		
		JArrayHelper::toInteger($cid);
		JArrayHelper::toInteger($order);

		$model = $this->getModel( 'phocamenugroup' );
		$model->saveorder($cid, $order);

		$msg = JText::_( 'New ordering saved' );
		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid, $msg );
	}
	
	function save() {
	
		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		//$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		//$catid 		= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		$cid 		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		
		$post				= JRequest::get('post');
		$post['id'] 		= (int) $cid[0];
		$post['message']	= JRequest::getVar( 'message', '', 'post', 'string', JREQUEST_ALLOWRAW );
		
		$model = $this->getModel( 'phocamenugroup' );
		$return	= $model->store($post);
		if (isset($return['catid']) && $return['catid'] > 0) {
			$catid	= $return['catid'];
		} else {
			$catid	= JRequest::getVar( $typeCatid, 0, 'post', 'int' );
		}

		switch ( JRequest::getCmd('task') ) {
			case 'apply':
				if (isset($return['id']) && $return['id'] > 0) {
					$id		= $return['id'];// Try to get it from database (it is actualized)
					$msg	= JText::_( 'Changes to Phoca Menu Group Saved' );
				} else {
					$id		= $post['id'];// Not from database, try to get it from request
					$msg 	= JText::_( 'Error Saving Phoca Menu Group' );
				}
				
				$link = 'index.php?option=com_phocamenu&controller=phocamenugroup&task=edit&type='.(int)$type.'&cid[]='.$id.'&'.$typeCatid.'='. (int) $catid;
			break;
			
			case 'save':
			default:
				if (isset($return['id']) && $return['id'] > 0) {
					$msg = JText::_( 'Phoca Menu Group Saved' );
				} else {
					$msg = JText::_( 'Error Saving Phoca Menu Group' );
				}
				$link = 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid;
			break;
		}

		$model->checkin();
		$this->setRedirect($link, $msg);
	}
	
	function remove() {
		global $mainframe;

		$type		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo	= PhocaMenuHelper::getTypeInfo('group', $type);
		$typeCatid	= $typeInfo['catid'];	
		$catid 		= JRequest::getVar( $typeCatid, 0, '', 'int' );//POST or GET (Menu in top or in rows)
		$cid 		= JRequest::getVar( 'cid', array(), '', 'array' );//POST or GET (Menu in top or in rows)
	
		JArrayHelper::toInteger($cid);
	
		if (count($cid ) < 1) {
			JError::raiseError(500, JText::_( 'Select an item to delete' ) );
		}
		
		$model = $this->getModel( 'phocamenugroup' );
		if(!$model->delete($cid, $catid, $typeCatid)) {
			$msg = JText::_( 'Error Deleting Phoca Menu Group' );
		} else {
			$msg = JText::_( 'Phoca Menu Group Deleted' );
		}

		$link = 'index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$type.'&'.$typeCatid.'='. (int) $catid;
		$this->setRedirect( $link, $msg );
	}
}
?>
