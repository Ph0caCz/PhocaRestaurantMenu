<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();

class PhocaMenuCpControllerPhocaMenuEmail extends PhocaMenuCpController
{
	function __construct() {
		parent::__construct();

		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'apply'  , 'save' );
		$this->registerTask( 'sendandsave', 'save' );
		$this->registerTask( 'send', 'send' );
		
	}
	
	function edit() {
		JRequest::setVar( 'view', 'phocamenuemail' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	function cancel() {
		
		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM );
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid );
	}
	
	
	function save() {
	
		$post				= JRequest::get('post');
		$cid				= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] 		= (int) $cid[0];//only one item in the database for every view
		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM );
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$post['type']		= (int)$type;
		$post['messagemail']= JRequest::getVar( 'message', null, '', 'STRING', JREQUEST_ALLOWHTML );
		$post['message']	= '';// it is automatically generated, cannot be saved here (into the database)
		$post['published']	= 1;
		
		//Admin Tools
		$adminTool		 	= JRequest::getVar('admintool', 0, 'post', 'int');
		$atid	 			= JRequest::getVar( 'atid', 0, 'post', 'int' );
		
		JRequest::checkToken() or die( 'Invalid Token' );	
		$model 	= $this->getModel( 'phocamenuemail' );		

		switch (JRequest::getCmd('task')) {
			case 'apply';
				$id	= $model->store($post);//you get id and you store the table data
				if ($id && $id > 0) {
					$msg = JText::_( 'PhocaMenu Email Saved' );
				} else {
					$msg = JText::_( 'PhocaMenu Error Saving Email' );
				}
			
				$link = 'index.php?option=com_phocamenu&controller=phocamenuemail&task=edit&type='.(int)$type.'&typeback='.$typeBack.'&cid[]='.$id.'&'.$typeInfoBack['catid'].'='.$catid.'&admintool='.(int)$adminTool.'&atid='.(int)$atid;
			break;
			
			case 'save';
				$id	= $model->store($post);//you get id and you store the table data
				if ($id && $id > 0) {
					$msg = JText::_( 'PhocaMenu Email Saved' );
				} else {
					$msg = JText::_( 'PhocaMenu Error Saving Email' );
				}
				$link = 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid;
			break;
			
			case 'sendandsave';
				$id	= $model->store($post);//you get id and you store the table data
				
				if ($id && $id > 0) {
					$msg = JText::_( 'PhocaMenu Email Saved' );
				} else {
					$msg = JText::_( 'PhocaMenu Error Saving Email' );
				}
				
				// Doesn't return true or false, failure message instead of false
				$errorMsg = '';
				PhocaMenuCpControllerPhocaMenuEmail::sendEmail($post, $errorMsg);
				/*if( PhocaMenuCpControllerPhocaMenuEmail::sendEmail($post, $errorMsg)) {
					$msg .= ". ".JText::_( 'Email sent' );
				} else {
					$msg .= ". ".JText::_( 'Email not sent' );
				}*/
				if ($errorMsg != '') {
					$msg .= '. ' .$errorMsg . '<br />' . JText::_('Email not sent');
				} else {
					$msg .= '. ' .JText::_( 'If no error message above, email sent' ) . '.';
				}
				
				
				$link = 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid;
			break;
			
			default:
				$msg = JText::_( 'PhocaMenu Email Saved' ) . '. ' .JText::_('No task function found') . '.';
				$link 	= 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid;
			break;
		}
		
		$this->setRedirect( $link, $msg );		
	}
	
	function send() {
		
		$post				= JRequest::get('post');
		$cid				= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] 		= (int) $cid[0];//only one item in the database for every view
		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM );
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$post['type']		= (int)$type;
		$post['messagemail']= JRequest::getVar( 'message', null, '', 'STRING', JREQUEST_ALLOWHTML );
		$post['message']	= '';// it is automatically generated, cannot be saved here (into the database)
		$post['published']	= 1;
		
		JRequest::checkToken() or die( 'Invalid Token' );	
		$model 	= $this->getModel( 'phocamenuemail' );		
	
		// Doesn't return true or false, failure message instead of false
		$errorMsg = '';
		PhocaMenuCpControllerPhocaMenuEmail::sendEmail($post, $errorMsg);
		/*if ( PhocaMenuCpControllerPhocaMenuEmail::sendEmail($post)) {
			$msg .= ". ".JText::_( 'Email sent' );
		} else {
			$msg .= ". ".JText::_( 'Email not sent' );
		}
		if ( PhocaMenuCpControllerPhocaMenuEmail::sendEmail($post)) {
			$msg .= ". ".JText::_( 'Email sent' );
		} else {
			$msg .= ". ".JText::_( 'Email not sent' );
		}
		*/
		if ($errorMsg != '') {
			$msg .= $errorMsg . '<br />' . JText::_('Email not sent');
		} else {
			$msg .= JText::_( 'If no error message above, email sent' ) . '.';
		}
		
		$link = 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid;
		$this->setRedirect( $link, $msg );
	}

	function sendEmail($post, &$errorMsg) {
		
		global $mainframe;
		$db 		= JFactory::getDBO();
		$siteName 	= $mainframe->getCfg( 'sitename' );
		$document	= &JFactory::getDocument();
		
		jimport('joomla.mail.helper');
		// FROM
		if (isset($post['from']) && $post['from'] != '' && JMailHelper::isEmailAddress($post['from'])) {
			$from = $post['from'];
		} else {
			$query = 'SELECT name, email, sendEmail' .
					' FROM #__users' .
					' WHERE LOWER( usertype ) = "super administrator"';
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			$from = $rows[0]->email;
		}
		
		// FROM NAME
		if (isset($post['fromname']) && $post['fromname'] != '') {
			$fromName = $post['fromname'];
		} else {
			$fromName = $mainframe->getCfg( 'sitename' );
		}
		
		// TO
		if (isset($post['to']) && $post['to'] != '') {
			$to	= trim( $post['to'] );
			$to = explode( ',', $to);
		} else {
			$to = array();
		}
		
		// CC
		if (isset($post['cc']) && $post['cc'] != '') {
			$cc	= trim( $post['cc'] );
			$cc = explode( ',', $cc);
		} else {
			$cc = array();
		}
		
		// BCC
		if (isset($post['bcc']) && $post['bcc'] != '') {
			$bcc	= trim( $post['bcc'] );
			$bcc 	= explode( ',', $bcc);
		} else {
			$bcc = array();
		}
		
		if (isset($post['subject']) && $post['subject'] != '') {
			$subject	= $post['subject'];
		} else {
			$subject	= JText::_('Menu');
		}
		
		if (isset($post['messagemail']) && $post['messagemail'] != '') {
			$message	= $post['messagemail'];
		} else {
			$message	= '';
		}
	
		$htmlMessage ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">'
		.'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="'.$document->language.'" lang="'.$document->language.'" dir="'.$document->direction.'" >'
		.'<head>'
		.'<meta http-equiv="content-type" content="text/html; charset=utf-8" />'
		.'<title>'.$subject.'</title></head>'
		.'<body>'
		.$message
		.'</body></html>';


		// Check the email addresses
		$wrongTo 	= array();
		$wrongCc 	= array();
		$wrongBcc 	= array();
		
		foreach ($to as $kt => $vt) {
			if ( $vt =='' || $vt == ' ' || ctype_space($vt)) {
				unset ($to[$kt]);
			}
			$vt 		= trim($vt);
			if (!JMailHelper::isEmailAddress($vt)) {
				$wrongTo[] = $vt;
			} else {
				$to[$kt] = $vt;
			}
		}
		
		if (!empty($wrongTo)) {
			$errorMsg = JText::_('Incorrect Email Address(es) in To' ) . ': ';
			foreach ($wrongTo as $key => $value) {
				$errorMsg .= $value . '<br />';
			}
			return false;
		}
		
		foreach ($cc as $kt => $vt) {
			if ($vt =='' || $vt == ' ' || ctype_space($vt)) {
				unset ($cc[$kt]);
			}
			$vt 		= trim($vt);
			if (!JMailHelper::isEmailAddress($vt)) {
				$wrongCc[] = $vt;
			} else {
				$cc[$kt] = $vt;
			}
		}
		
		if (!empty($wrongCc)) {
			$errorMsg = JText::_('Incorrect Email Address(es) in Cc' ) . ': ';
			foreach ($wrongCc as $key => $value) {
				$errorMsg .= $value . '<br />';
			}
			return false;
		}
		
		foreach ($bcc as $kt => $vt) {
			if ($vt =='' || $vt == ' ' || ctype_space($vt)) {
				unset ($bcc[$kt]);
			}
			$vt 		= trim($vt);
			if (!JMailHelper::isEmailAddress($vt)) {
				$wrongBcc[] = $vt;
			} else {
				$bcc[$kt] = $vt;
			}
		}
		
	
		if (!empty($wrongBcc)) {
			$errorMsg = JText::_('Incorrect Email Address(es) in Bcc' ) . ': ';
			foreach ($wrongBcc as $key => $value) {
				$errorMsg .= $value . '<br />';
			}
			return false;
		}
		
		$replyto 		= $from;
		$replytoname	= $fromName;		
		
		if (JUtility::sendMail($from, $fromName, $to, $subject, $htmlMessage, true, $cc, $bcc, '', $replyto, $replytoname)) {
			return true;
		} else {
			return false;
		}
	}
}
?>
