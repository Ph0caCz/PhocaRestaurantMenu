<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();

class PhocaMenuCpControllerPhocaMenuMultipleEdit extends PhocaMenuCpController
{
	function __construct() {
		
		parent::__construct();

		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'apply'  , 'save' );
	}
	
	function edit() {
		JRequest::setVar( 'view', 'phocamenumultipleedit' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	function cancel() {
		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM );
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid );
		
	}
	
	
	function save() {
		$post				= JRequest::get('post');

		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM );
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$errorMsg			= '';
		
		//Admin Tools
		$adminTool		 	= JRequest::getVar('admintool', 0, 'post', 'int');
		$atid	 			= JRequest::getVar( 'atid', 0, 'post', 'int' );

		
		$model 	= $this->getModel( 'phocamenumultipleedit' );		
		$return	= $model->store($post, $errorMsg, $type);
		
		
		switch ( JRequest::getCmd('task') ) {
			case 'apply':
				if ($return) {
					$msg = JText::_( 'Changes in Multiple Edit Saved' );
				} else {
					$msg = JText::_( 'Error Saving in Multiple Edit' );
				}
				$link = 'index.php?option=com_phocamenu&controller=phocamenumultipleedit&task=edit&type='.(int)$type.'&typeback='.$typeBack.'&'.$typeInfoBack['catid'].'='.$catid.'&admintool='.(int)$adminTool.'&atid='.(int)$atid;
			break;
			
			case 'save':
			default:
				if ($return) {
					$msg 	= JText::_( 'Changes in Multiple Edit Saved' );
				} else {
					$msg 	= JText::_( 'Error Saving in Multiple Edit' );
				}
				$link = 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid;
			break;
		}
		
		if ($errorMsg != '') {
			$msg .= '. '.$errorMsg. '.'; 
		}
		
		$this->setRedirect($link, $msg);
	}
}
?>
