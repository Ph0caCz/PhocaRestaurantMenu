<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();

class PhocaMenuCpControllerPhocaMenuItem extends PhocaMenuCpController
{
	function __construct() {
		parent::__construct();

		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'apply'  , 'save' );
	}
	
	function edit() {
		JRequest::setVar( 'view', 'phocamenuitem' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar( 'hidemainmenu', 1 );

		parent::display();

		$model = $this->getModel( 'phocamenuitem' );
		$model->checkout();
	}
	
	function cancel() {
		$catid 	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		$model	= $this->getModel( 'phocamenuitem' );
		$model->checkin();
		$type	= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type.'&gid='. (int) $catid );
	}
	
	function publish() {
		global $mainframe;

		$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$catid 	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		$type	= JRequest::getVar( 'type', null, '', 'STRING', JREQUEST_NOTRIM);
		JArrayHelper::toInteger($cid);
		
		if (count($cid ) < 1) {
			JError::raiseError(500, JText::_( 'Select an item to publish' ) );
		}

		$model = $this->getModel('phocamenuitem');
		if(!$model->publish($cid, 1)) {
			echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
		}

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type.'&gid='.$catid );
	}

	function unpublish()
	{
		global $mainframe;

		$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$catid 	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		$type	= JRequest::getVar( 'type', null, '', 'STRING', JREQUEST_NOTRIM);
		JArrayHelper::toInteger($cid);

		if (count( $cid ) < 1) {
			JError::raiseError(500, JText::_( 'Select an item to unpublish' ) );
		}

		$model = $this->getModel('phocamenuitem');
		if(!$model->publish($cid, 0)) {
			echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
		}

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type.'&gid='.$catid );
	}
	
	function orderup() {
		$type	= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
		$catid	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		$model 	= $this->getModel( 'phocamenuitem' );
		$model->move(-1, $gid);

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type.'&gid='.$catid );
	}

	function orderdown() {
		$type	= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
		$catid 	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		$model 	= $this->getModel( 'phocamenuitem' );
		$model->move(1, $gid);

		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type.'&gid='.$catid );
	}

	function saveorder() {
		$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$catid 	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		$order 	= JRequest::getVar( 'order', array(), 'post', 'array' );
		$type	= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
		
		JArrayHelper::toInteger($cid);
		JArrayHelper::toInteger($order);

		$model = $this->getModel( 'phocamenuitem' );
		$model->saveorder($cid, $order);

		$msg = JText::_( 'New ordering saved' );
		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type.'&gid='.$catid, $msg );
	}
	
	function save() {
		$post					= JRequest::get('post');
		$cid					= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] 			= (int) $cid[0];
		$post['description']	= JRequest::getVar( 'description', '', 'post', 'string', JREQUEST_ALLOWRAW );
		$type					= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
		
		// Store, get ID and CATID
		$model 	= $this->getModel( 'phocamenuitem' );
		$return	= $model->store($post);
		if (isset($return['catid']) && $return['catid'] > 0) {
			$catid	= $return['catid'];
		} else {
			$catid	= JRequest::getVar( 'gid', 0, 'post', 'int' );
		}
		
		switch ( JRequest::getCmd('task') ) {
			case 'apply':
				if (isset($return['id']) && $return['id'] > 0) {
					$id		= $return['id'];// Try to get it from database (it is actualized)
					$msg 	= JText::_( 'Changes to Phoca Menu Item Saved' );
				} else {
					$id		= $post['id'];// Not from database, try to get it from request
					$msg = JText::_( 'Error Saving Phoca Menu Item' );
				}
				
				$link = 'index.php?option=com_phocamenu&controller=phocamenuitem&task=edit&type='.$type.'&cid[]='.(int)$id.'&gid='.(int)$catid;
			break;
			
			case 'save':
			default:
				if (isset($return['id']) && $return['id'] > 0) {
					$msg 	= JText::_( 'Phoca Menu Item Saved' );
				} else {
					$msg 	= JText::_( 'Error Saving Phoca Menu Item' );
				}
				$link = 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type . '&gid='.(int)$catid;
			break;
		}

		$model->checkin();
		$this->setRedirect($link, $msg);
	}
	
	function remove() {
		global $mainframe;

		$cid 	= JRequest::getVar( 'cid', array(), '', 'array' );// POST (Icon), GET (Small Icon)
		$catid	= JRequest::getVar( 'gid', 0, '', 'int' );
		$type	= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
		
		JArrayHelper::toInteger($cid);
	
		if (count($cid ) < 1) {
			JError::raiseError(500, JText::_( 'Select an item to delete' ) );
		}
		
		$model = $this->getModel( 'phocamenuitem' );
		if(!$model->delete($cid)) {
			echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
			$msg = JText::_( 'Error Deleting Phoca Menu Item' );
		}
		else {
			$msg = JText::_( 'Phoca Menu Item Deleted' );
		}

		$link = 'index.php?option=com_phocamenu&view=phocamenuitems&type='.$type . '&gid='.(int)$catid;
		$this->setRedirect( $link, $msg );
	}
}
?>
