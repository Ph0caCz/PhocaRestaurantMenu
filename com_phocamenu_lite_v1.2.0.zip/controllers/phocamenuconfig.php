<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();

class PhocaMenuCpControllerPhocaMenuConfig extends PhocaMenuCpController
{
	function __construct() {
		parent::__construct();

		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'apply'  , 'save' );
	}
	
	function edit() {
		JRequest::setVar( 'view', 'phocamenuconfig' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar( 'hidemainmenu', 1 );

		parent::display();

		$model = $this->getModel( 'phocamenuconfig' );
		$model->checkout();
	}
	
	function cancel() {
		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM );
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		
		$model	= $this->getModel( 'phocamenuconfig' );
		$model->checkin();
		$this->setRedirect( 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid );
	}

	
	function save() {
		
		$post				= JRequest::get('post');
		$cid				= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] 		= (int) $cid[0];
		$post['footer']		= JRequest::getVar( 'footer', '', 'post', 'string', JREQUEST_ALLOWRAW );
		$post['header']		= JRequest::getVar( 'header', '', 'post', 'string', JREQUEST_ALLOWRAW );
		$type				= JRequest::getVar( 'type', 0, '', 'int' );
		$typeBack			= JRequest::getVar( 'typeback', null, '', 'STRING', JREQUEST_NOTRIM);
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($typeBack, $type);
		$catid				= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		
		$typeInfo			= PhocaMenuHelper::getTypeInfo('config',$type);
		$post['title']		= $typeInfo['title'];
		
		$model = $this->getModel( 'phocamenuconfig' );

		switch ( JRequest::getCmd('task') ) {
			case 'apply':
				$id	= $model->store($post);//you get id and you store the table data
				if ($id && $id > 0) {
					$msg = JText::_( 'Changes to Phoca Menu Config Saved' );
				} else {
					$msg = JText::_( 'Error Saving Phoca Menu Config' );
				}
				$link = 'index.php?option=com_phocamenu&controller=phocamenuconfig&task=edit&type='.(int)$type.'&typeback='.$typeBack.'&cid[]='.$id.'&'.$typeInfoBack['catid'].'='.$catid;
			break;
			
			case 'save':
			default:
				$id	= $model->store($post);//you get id and you store the table data
				if ($id && $id > 0) {
					$msg = JText::_( 'Phoca Menu Config Saved' );
				} else {
					$msg = JText::_( 'Error Saving Phoca Menu Config' );
				}
				$link = 'index.php?option=com_phocamenu&view=phocamenu'.$typeInfoBack['view'].'s&type='.(int)$type.'&'.$typeInfoBack['catid'].'='.$catid;
			break;
		}

		$model->checkin();
		$this->setRedirect($link, $msg);
	}
	
}
?>
