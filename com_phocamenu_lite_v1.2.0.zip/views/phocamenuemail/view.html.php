<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );
require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenurenderviews.php' );
class PhocaMenuCpViewPhocaMenuEmail extends JView
{
	function display($tpl = null) {
		
		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}
		parent::display($tpl);
	}

	function _displayForm($tpl) {
		global $mainframe;
		$uri 			= &JFactory::getURI();
		$user 			= &JFactory::getUser();
		$model			= &$this->getModel();
		$component 		= 'phocamenu';
		$lists 			= array();
		$editor 		= &JFactory::getEditor();
		$params 		= &JComponentHelper::getParams( 'com_phocamenu' );

		$tmpl['type']			= JRequest::getVar('type', 0, '', 'int');
		$tmpl['typeback']		= JRequest::getVar('typeback', null, '', 'STRING', JREQUEST_NOTRIM);
		$typeInfo				= PhocaMenuHelper::getTypeInfo('config', $tmpl['type']);
		$typeInfoBack			= PhocaMenuHelper::getTypeInfo($tmpl['typeback'],$tmpl['type']);
		$tmpl['typecatid']		= $typeInfoBack['catid'];
		$tmpl['catid']			= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$tmpl['render']			= $typeInfo['render'];
		
		//Admin Tools
		$tmpl['admintool'] 	= JRequest::getVar('admintool', 0, '', 'int');
		$tmpl['atid']		= JRequest::getVar( 'atid', 0, '', 'int' );
	
		// Date
		$tmpl['dateclass']		= $params->get( 'date_class', 0 );
		$tmpl['daydateformat']	= $params->get( 'day_date_format', '%A, %d. %B %Y' );
		$tmpl['weekdateformat']	= $params->get( 'week_date_format', '%A, %d. %B %Y' );
		$tmpl['priceprefix']	= $params->get( 'price_prefix', '...' );
		$tmpl['enableeditoremail']	= $params->get( 'enable_editor_email', 1 );

		//Data from model
		$data	= &$this->get('Data');
		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'DESCBEINGEDITTED', JText::_( 'Phoca Restaurant Menu' ), $item->title );
			$mainframe->redirect( 'index.php?option=com_phocamenu', $msg );
		}
		
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );
		JToolBarHelper::title(JText::_('Send Email') .' - ' . $typeInfo['title'], $typeInfoBack['pref'] );
		
		JToolBarHelper::customX('sendandsave', 'emailsave', '', 'Send and Save', false);
		JToolBarHelper::customX('send', 'email', '', 'Send', false);
		JToolBarHelper::save();
		JToolBarHelper::apply();
		
		JToolBarHelper::cancel('cancel', 'Close');
		JToolBarHelper::help( 'screen.'.$component, true );
		
		jimport('joomla.filter.output');
		JHTML::_('behavior.calendar');
		
		$paramsG = NULL;
		$tmpl['phocagallery'] 		= 0;
		$tmpl['customclockcode'] 	= '';
		
		$this->assignRef('editor', $editor);
		$this->assignRef('data', $data);
		$this->assignRef('tmpl', $tmpl);
		$this->assignRef('params', $params);
		$this->assignRef('paramsg', $paramsG);//No Phoca Gallery Images in mail
		$this->assignRef('request_url',	$uri->toString());
		
		parent::display($tpl);
	}
}
?>
