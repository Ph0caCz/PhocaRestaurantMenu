<?php
defined('_JEXEC') or die('Restricted access');

$from		= '';
$fromName	= '';
$to			= '';
$cc			= '';
$bcc		= '';
//$message	= '';
$subject	= '';

if (isset($this->data['email'])) {
	$from		= $this->data['email']->from;
	$fromName	= $this->data['email']->fromname;
	$to			= $this->data['email']->to;
	$cc			= $this->data['email']->cc;
	$bcc		= $this->data['email']->bcc;
	$subject	= $this->data['email']->subject;
	//$message	= $this->data['email']->message;// not saved it is automatically generated
}
?>

<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm" id="adminForm">
<div class="col50">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Email Details (Can be saved)' ); ?></legend>
		<table class="admintable"><?php
			
			echo PhocaMenuRender::renderFormInput('fromname', 'From Name', $fromName);
			echo PhocaMenuRender::renderFormInput('from', 'From', $from);
			echo PhocaMenuRender::renderFormTextarea('to', 'To', $to, 60, 2, 'width:700px');
			echo PhocaMenuRender::renderFormTextarea('cc', 'Cc', $cc, 60, 2, 'width:700px');
			echo PhocaMenuRender::renderFormTextarea('bcc', 'Bcc', $bcc, 60, 2, 'width:700px');
			echo PhocaMenuRender::renderFormInput('subject', 'Subject', $subject,50,250, 'width:700px');
			
		?>
		</table>
	</fieldset>
		
		<?php
		$method = $this->tmpl['render'];
		$messageOutput = PhocaMenuRenderViews::$method($this->data, $this->tmpl, $this->params,$this->paramsg, 1);
		?>

	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Email Body (Cannot be saved, it is automatically generated)' ); ?></legend>
		<table class="admintable">
			<?php		
			if ($this->tmpl['enableeditoremail'] == 1) {
				echo PhocaMenuRender::renderFormItemSpecial('message', 'Body', $this->editor->display( 'message', $messageOutput, '692', '600', '80', '60', array('pagebreak', 'phocadownload', 'readmore', 'image') ) );
			} else {
				echo PhocaMenuRender::renderFormTextArea('message', 'Body', $messageOutput, 80, 60, '');
			}
			?>
		</table>
	</fieldset>
</div>

<input type="hidden" name="controller" value="phocamenuemail" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="admintool" value="<?php echo (int)$this->tmpl['admintool'];?>" />
<input type="hidden" name="atid" value="<?php echo (int)$this->tmpl['atid'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="cid[]" value="<?php echo (int)$this->data['email']->id; ?>" />
<input type="hidden" name="<?php echo $this->tmpl['typecatid'];?>" value="<?php echo (int)$this->tmpl['catid'];?>" />
<input type="hidden" name="typeback" value="<?php echo $this->tmpl['typeback'];?>" />
<input type="hidden" name="option" value="com_phocamenu" />
<?php echo JHTML::_( 'form.token' ); ?>	
</form>
