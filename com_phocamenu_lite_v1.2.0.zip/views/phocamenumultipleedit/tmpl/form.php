<?php
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
?>
<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm" id="adminForm">
<div class="col50">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Details' ); ?></legend>

		<table class="admintable">
		<tr>
			<td>
<?php

$method = $this->tmpl['render'];
$output = PhocaMenuRenderViews::$method($this->data, $this->tmpl, $this->params, NULL, 3);

if (isset($output)) {
	echo $output;
}

?>
			</td>
		</tr>
		</table>
	</fieldset>
</div>
<div class="clr"></div>

<input type="hidden" name="controller" value="phocamenumultipleedit" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="admintool" value="<?php echo (int)$this->tmpl['admintool'];?>" />
<input type="hidden" name="atid" value="<?php echo (int)$this->tmpl['atid'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="<?php echo $this->tmpl['typecatid'];?>" value="<?php echo (int)$this->tmpl['catid'];?>" />
<input type="hidden" name="typeback" value="<?php echo $this->tmpl['typeback'];?>" />
<input type="hidden" name="option" value="com_phocamenu" />
<?php echo JHTML::_( 'form.token' ); ?>	
</form>

