<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );
require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenurenderviews.php' );

class PhocaMenuCpViewPhocaMenuMultipleEdit extends JView
{
	function display($tpl = null) {
		
		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}
		parent::display($tpl);
	}

	function _displayForm($tpl) {
		
		global $mainframe;
		$uri 			= &JFactory::getURI();
		$component 		= 'phocamenu';
		$lists 			= array();
		$params 		= &JComponentHelper::getParams( 'com_phocamenu' );
		$document		= &JFactory::getDocument();
		$document->addScript(JURI::base(true).'/components/com_phocamenu/assets/js/addrow.js');
		JHTML::stylesheet( 'phocamenu.css', 'components/com_phocamenu/assets/' );
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );		

		$tmpl['type']		= JRequest::getVar('type', 0, '', 'int');
		$tmpl['typeback']	= JRequest::getVar('typeback', null, '', 'STRING', JREQUEST_NOTRIM);
		$typeInfo			= PhocaMenuHelper::getTypeInfo('config', $tmpl['type']);
		$typeInfoBack		= PhocaMenuHelper::getTypeInfo($tmpl['typeback'],$tmpl['type']);
		$tmpl['typecatid']	= $typeInfoBack['catid'];
		$tmpl['catid']		= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$tmpl['render']		= $typeInfo['render'];
		
		//Admin Tools
		$tmpl['admintool'] 	= JRequest::getVar('admintool', 0, '', 'int');
		$tmpl['atid']		= JRequest::getVar( 'atid', 0, '', 'int' );
		
		// Date
		$tmpl['dateclass']		= $params->get( 'date_class', 0 );
		$tmpl['daydateformat']	= $params->get( 'day_date_format', '%A, %d. %B %Y' );
		$tmpl['weekdateformat']	= $params->get( 'week_date_format', '%A, %d. %B %Y' );
		$tmpl['priceprefix']	= $params->get( 'price_prefix', '...' );

		//Data from model
		$data	= &$this->get('Data');
		
		$bar = & JToolBar::getInstance('toolbar');
		
		JToolBarHelper::title(JText::_('Multiple Edit') .' - ' . $typeInfo['title'], $typeInfoBack['pref'] );
		//JToolBarHelper::save();
		//JToolBarHelper::apply();
		$bar->appendButton( 'Custom', '<a href="#" onclick="javascript:if(document.adminForm.boxchecked.value==0) {submitbutton(\'save\');} else {if(confirm(\'Are you sure you want to delete selected item(s)?\')) {submitbutton(\'save\');}}" class="toolbar"><span class="icon-32-save" title="'.JText::_('Save').'"></span>'.JText::_('Save').'</a>');
		
		$bar->appendButton( 'Custom', '<a href="#" onclick="javascript:if(document.adminForm.boxchecked.value==0) {submitbutton(\'apply\');} else {if(confirm(\'Are you sure you want to delete selected item(s)?\')) {submitbutton(\'apply\');}}" class="toolbar"><span class="icon-32-apply" title="'.JText::_('Apply').'"></span>'.JText::_('Apply').'</a>');	
		

		
		//JToolBarHelper::deleteList(JText::_('Warning Delete selected items'));
		JToolBarHelper::cancel('cancel', 'Close');
		JToolBarHelper::help( 'screen.'.$component, true );
		
		jimport('joomla.filter.output');
		JHTML::_('behavior.calendar');
		
		$paramsG = NULL;
		$tmpl['phocagallery'] 		= 0;
		$tmpl['customclockcode'] 	= '';

		$this->assignRef('data', $data);
		$this->assignRef('tmpl', $tmpl);
		$this->assignRef('params', $params);
		$this->assignRef('request_url',	$uri->toString());

		
		parent::display($tpl);
	}
}
?>
