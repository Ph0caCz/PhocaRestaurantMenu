<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuItem extends JView
{
	function display($tpl = null) {
		global $mainframe;
		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}
		parent::display($tpl);
	}

	function _displayForm($tpl) {
		global $mainframe, $option;
		$db		= &JFactory::getDBO();
		$uri 	= &JFactory::getURI();
		$user 	= &JFactory::getUser();
		$model	= &$this->getModel();
		$editor = &JFactory::getEditor();
		$params = &JComponentHelper::getParams( 'com_phocamenu' );
		$tmpl	= array();
		
		$tmpl['type']		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo			= PhocaMenuHelper::getTypeInfo('item', $tmpl['type']);
		$tmpl['catid'] 		= JRequest::getVar( 'gid', 0, 'post', 'int' );// Only for New (New can be added only by POST)
		$tmpl['typepref']	= $typeInfo['pref'];
		$tmpl['typecatid']	= $typeInfo['catid'];
		
		
		$tmpl['enableeditor']	= $params->get( 'enable_editor', 1 );
		
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );
		
		// Data from model
		$item	=& $this->get('Data');
		
		$lists 	= array();		
		$isNew	= ($item->id < 1);

		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'DESCBEINGEDITTED', JText::_( 'Phoca Restaurant Menu' ), $item->title );
			$mainframe->redirect( 'index.php?option=com_phocamenu', $msg );
		}

		// Toolbar
		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title( $typeInfo['text'] .': <small><small>[ ' . $text.' ]</small></small>', 'dm' );
		JToolBarHelper::save();
		JToolBarHelper::apply();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}
		JToolBarHelper::help( 'screen.phocamenu', true );

		// Edit or Create?
		if (!$isNew) {
			$model->checkout( $user->get('id') );
		} else {
			// Initialise new record
			$item->published 	= 1;
			$item->order 		= 0;
		}

		// Edit or Create
		if ($item->catid > 0) {
			$tmpl['catid'] = (int)$item->catid;// Edit
		} 
		
		// Lists - - - - - - - - - - - - - - -
		// Build the html select list for ordering
		$query = 'SELECT ordering AS value, title AS text'
			    .' FROM #__phocamenu_item'
			    .' WHERE type = '.(int)$tmpl['type']
				.' AND catid = '.(int)$tmpl['catid'] // we use the catid from database, so it will be changed on site
			    .' ORDER BY ordering';
		$lists['ordering'] 	= JHTML::_('list.specificordering',  $item, $item->id, $query, false );
		
		// Build the html select list
		$lists['published'] = JHTML::_('select.booleanlist',  'published', 'class="inputbox"', $item->published );
		
		if (isset($item->catid) && $item->catid > 0) {
			// EDIT
			$groupCatid = $item->catid;
		} else {
			// NEW
			$groupCatid = $tmpl['catid'];
		}
		// Build the list of categories
		switch($tmpl['type']) {
			case 2:				
				$leftJoin 	= ' LEFT JOIN #__phocamenu_day AS d ON d.id = a.catid';
				$and		= ' AND d.id = (SELECT catid FROM #__phocamenu_group WHERE id = '.(int)$groupCatid.' LIMIT 1)';
			break;
			case 3:
			case 4:
			case 5:			
				$leftJoin 	= ' LEFT JOIN #__phocamenu_list AS l ON l.id = a.catid';
				$and		= ' AND l.id = (SELECT catid FROM #__phocamenu_group WHERE id = '.(int)$groupCatid.' LIMIT 1)';
			break;
			default;
				$leftJoin 	= '';
				$and		= '';
			break;
			
		}
		
		$query = 'SELECT a.title AS text, a.id AS value, a.catid AS parentid'
		. ' FROM #__phocamenu_group AS a'
		. $leftJoin
		. ' WHERE a.type = '.(int)$tmpl['type']
		. $and
		. ' ORDER BY a.ordering';
		
		$db->setQuery( $query );
		$itemlist = $db->loadObjectList();
		
		array_unshift($itemlist, JHTML::_('select.option', '0', '- '.JText::_('Select Category').' -', 'value', 'text'));
		//list categories
		$lists['catid'] = JHTML::_( 'select.genericlist', $itemlist, 'catid',  '', 'value', 'text', $tmpl['catid']);
		// - - - - - - - - - - - - - - -

		jimport('joomla.filter.output');
		JFilterOutput::objectHTMLSafe( $item, ENT_QUOTES, 'message' );

		//Image button
		$link = 'index.php?option=com_phocamenu&amp;view=phocamenugallery&amp;tmpl=component';
		JHTML::_('behavior.modal', 'a.modal-button');
		$button = new JObject();
		$button->set('modal', true);
		$button->set('link', $link);
		$button->set('text', JText::_( 'Image' ));
		$button->set('name', 'image');
		$button->set('modalname', 'modal-button');
		$button->set('options', "{handler: 'iframe', size: {x: 760, y: 520}}");
		
		$this->assignRef('button', $button);
		$this->assignRef('tmpl', $tmpl);
		$this->assignRef('editor', $editor);
		$this->assignRef('lists', $lists);
		$this->assignRef('item', $item);
		$this->assignRef('request_url',	$uri->toString());

		parent::display($tpl);
	}
}
?>