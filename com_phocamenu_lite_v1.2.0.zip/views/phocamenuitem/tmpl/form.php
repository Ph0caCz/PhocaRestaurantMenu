<?php
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip'); 

echo PhocaMenuRender::renderSubmitButtonJs(array(
		0 => array('title', 'Item name required', 'true', 1),
		1 => array('catid', 'Group must be selected', 'true', 0)
		)
	);
echo PhocaMenuRender::renderFormStyle();
?>

<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm" id="adminForm">
<div class="col50">
<fieldset class="adminform">
	<legend><?php echo JText::_('Item Detail'); ?></legend>
	<table class="admintable">		
		<?php
		echo PhocaMenuRender::renderFormInput('title', 'Title', $this->item->title);
		echo PhocaMenuRender::renderFormInput('quantity', 'Quantity', $this->item->quantity);
		echo PhocaMenuRender::renderFormInput('price', 'Price', $this->item->price);		
		if ($this->tmpl['enableeditor'] == 1) {
			echo PhocaMenuRender::renderFormItemSpecial('description', 'Description', $this->editor->display( 'description',  $this->item->description, '550', '300', '60', '20', array('pagebreak', 'phocadownload', 'readmore') ) );
		} else {
			echo PhocaMenuRender::renderFormTextArea('description', 'Description', $this->item->description, 60, 20, '');
		}
		echo PhocaMenuRender::renderFormItemSpecial('catid', 'Group', $this->lists['catid'] );
		echo PhocaMenuRender::renderFormItemImageButton('imageid', 'Image ID', $this->item->imageid, 11, 11, $this->button );
		echo PhocaMenuRender::renderFormItemSpecial('published', 'Published', $this->lists['published'] );
		echo PhocaMenuRender::renderFormItemSpecial('ordering', 'Ordering', $this->lists['ordering'] );
		?>
	</table>	
</fieldset>
</div>

<div class="clr"></div>

<input type="hidden" name="controller" value="phocamenuitem" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="cid[]" value="<?php echo (int)$this->item->id; ?>" />
<input type="hidden" name="gid" value="<?php echo (int)$this->tmpl['catid']; ?>" />
</form>