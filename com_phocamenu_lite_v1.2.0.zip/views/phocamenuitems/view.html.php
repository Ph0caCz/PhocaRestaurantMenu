<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuItems extends JView
{
	function display($tpl = null) {
		global $mainframe, $option;
		$uri		= &JFactory::getURI();
		$document	= &JFactory::getDocument();
		$db		    = &JFactory::getDBO();
		$user		= &JFactory::getUser();
		$params 	= &JComponentHelper::getParams( 'com_phocamenu' );
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );
		$tmpl		= array();
		
		$tmpl['type']		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo			= PhocaMenuHelper::getTypeInfo('item', $tmpl['type']);
		$tmpl['typepref']	= $typeInfo['pref'];
		$tmpl['typecatid']	= $typeInfo['catid'];
		
		$tmpl['displaytoolbartools']	= $params->get( 'display_toolbar_tools', 1 );
		
		// Get data from the model
		$items		= & $this->get( 'Data');
		$total		= & $this->get( 'Total');
		$pagination = & $this->get( 'Pagination' );

		// - - - - - - - - - - - - - - -  
		// Filter
		$context			= 'com_phocamenu.phocaitem'. $tmpl['type'] .'.list.';
		$filter_state		= $mainframe->getUserStateFromRequest( $context.'filter_state',		'filter_state',		'',				'word' );
		$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		0,				'int' );
		$filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'a.ordering',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',				'word' );
		$search				= $mainframe->getUserStateFromRequest( $context.'search',			'search',			'',				'string' );
		$search				= JString::strtolower( $search );
		
		// state filter
		$lists['state']		= JHTML::_('grid.state',  $filter_state );

		// table ordering
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order'] 	= $filter_order;

		// search filter
		$lists['search']	= $search;
		
		// build list of categories
		$javascript 	= 'class="inputbox" size="1" onchange="submitform( );"';
		
		// Filter Catid ($_POST) or Session or Catid ($_GET)
		$actualCategory		= PhocaMenuHelper::getActualCategory($typeInfo['catid'], $filter_catid);
		$tmpl['catid']		= $actualCategory['filter_catid'];
		$filter_catid		= $actualCategory['filter_catid'];

		$where 		= '';
		$backCatid	= '';
		switch ($tmpl['type']){
			case 2:
			case 3:
			case 4:
			case 5:
				$query = 'SELECT a.catid AS catid, a.type AS type'
				. ' FROM #__phocamenu_group AS a'
				. ' WHERE a.id = '.(int)$tmpl['catid']
				. ' LIMIT 1';
				$db->setQuery( $query );
				$catid = $db->loadObject();
			
			if (isset($catid->catid) && $catid->catid > 0) {
				$where 		= ' AND a.catid = '.(int)$catid->catid;
				$backCatid 	=  '&'.$typeInfo['catidup'].'=' .(int)$catid->catid;
			}
			break;
		}
	
		$query = 'SELECT a.title AS text, a.id AS value, a.catid as parentid'
		. ' FROM #__phocamenu_group AS a'
		. ' WHERE a.type = '.(int)$tmpl['type']
		. $where
	//	. ' WHERE a.published = 1'
		. ' ORDER BY a.ordering';
		$db->setQuery( $query );
		$categories = $db->loadObjectList();		
		
		$lists['catid'] = JHTML::_( 'select.genericlist', $categories, 'filter_catid',  $javascript , 'value', 'text', $filter_catid );
		// - - - - - - - - - - - - - - - 

		// Breadcrumbs - - - - - - - - -
		$typeInfoUp			= PhocaMenuHelper::getTypeInfo('group', $tmpl['type']);
		$tmpl['breadcrumb']	= PhocaMenuHelper::getBreadcrumbs($typeInfo['text'], $typeInfo['backlink'] . $backCatid, JText::_($typeInfo['backlinktxt']), $typeInfoUp['backlink'], JText::_($typeInfoUp['backlinktxt']));	
		// - - - - - - - - - - - - - - - 
		
		$this->assignRef('tmpl',		$tmpl);
		$this->assignRef('user',		$user);
		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);
		$this->assignRef('request_url',	$uri->toString());
		
		parent::display($tpl);
		$this->_setToolbar($tmpl, $typeInfo, $backCatid);
	}
	
	function _setToolbar($tmpl, $typeInfo, $backCatid) {
	
		$backCatidSpec = '';
		if (isset($tmpl['catid']) && (int)$tmpl['catid'] > 0) {
			$backCatidSpec 	=  '&'.$tmpl['typecatid'].'='.$tmpl['catid'];
		}
		
		$bar = & JToolBar::getInstance('toolbar');
		$bar->appendButton( 'Link', 'back', $typeInfo['backlinktxt'], 'index.php?option=com_phocamenu'.$typeInfo['backlink'] . $backCatid);	
		JToolBarHelper::title( $typeInfo['text'] , $typeInfo['pref'] );
		$displayToolbars = PhocaMenuHelper::displayToolbarTools($tmpl['displaytoolbartools'], $tmpl['type']);
		if ($displayToolbars) {
			$bar->appendButton( 'Custom', '<a href="index.php?option=com_phocamenu&controller=phocamenuemail&task=edit&type='.$tmpl['type'].'&typeback=item'. $backCatidSpec.'"><span class="icon-32-email" title="'.JText::_('Email').'" type="Custom"></span>'.JText::_('Email').'</a>');
			JToolBarHelper::preview( JURI::root().'index.php?option=com_phocamenu&view='.$typeInfo['frontview'].'&tmpl=component' );
			$bar->appendButton( 'Custom', PhocaMenuRender::getIconPDFAdministrator($typeInfo['frontview']));
		}
		JToolBarHelper::publishList();
		JToolBarHelper::unpublishList();
		JToolBarHelper::deleteList(JText::_('Warning Delete selected items'));
		JToolBarHelper::editListX();
		if ($displayToolbars) {
			$bar->appendButton( 'Custom', '<a href="index.php?option=com_phocamenu&controller=phocamenumultipleedit&task=edit&type='.$tmpl['type'].'&typeback=item'. $backCatidSpec.'"><span class="icon-32-multiple" title="'.JText::_('Multiple Edit').'" type="Custom"></span>'.JText::_('Multiple Edit').'</a>');
		}
		JToolBarHelper::addNewX();		
		
		$bar->appendButton( 'Custom', '<a href="index.php?option=com_phocamenu&controller=phocamenuconfig&task=edit&type='.$tmpl['type'].'&typeback=item'. $backCatidSpec.'">
		<span class="icon-32-settings" title="'.JText::_('Settings').'" type="Custom"></span>'.JText::_('Settings').'</a>');
		
	}
}
?>