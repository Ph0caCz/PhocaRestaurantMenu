<?php
defined('_JEXEC') or die('Restricted access');
$ordering = ($this->lists['order'] == 'a.ordering');
JHTML::_('behavior.tooltip');
echo $this->tmpl['breadcrumb'];
?>
<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm">
<table>
	<tr>
		<td align="left" width="100%"><?php echo JText::_( 'Filter' ); ?>:
			<input type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
			<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
			<button onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>
		</td>
		<td nowrap="nowrap">
			<?php
			switch ($this->tmpl['type']) {
				case 2:
				case 3:
				case 4:
				case 5:
					echo $this->lists['catid'];
				break;
			}
			echo $this->lists['state'];
			?>
		</td>
	</tr>
</table>
		
<div id="editcell">
<table class="adminlist">
<thead>
	<tr>
		<th width="5"><?php echo JText::_( 'NUM' ); ?></th>
		<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" /></th>
		<th class="title"><?php echo JHTML::_('grid.sort',  'Title', 'a.title', $this->lists['order_Dir'], $this->lists['order'] ); ?></th>	
		<th width="5%" nowrap="nowrap"><?php echo JText::_('Items' ); ?></th>
		<th width="5%" nowrap="nowrap"><?php echo JText::_('Delete'); ?></th>
		<th width="5%" nowrap="nowrap"><?php echo JHTML::_('grid.sort', 'Published', 'a.published', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<th width="100" nowrap="nowrap"><?php echo JHTML::_('grid.sort', 'Order', 'a.ordering', $this->lists['order_Dir'], $this->lists['order']);?> <?php echo JHTML::_('grid.order',  $this->items ); ?></th>
		<th width="5%" nowrap="nowrap"><?php echo JHTML::_('grid.sort', 'ID', 'a.id', $this->lists['order_Dir'], $this->lists['order']); ?></th>
	</tr>
</thead>
<?php
$k = 0;
for ($i=0, $n=count( $this->items ); $i < $n; $i++) {
	$row = &$this->items[$i];
	
	$linkEdit 		= 'index.php?option=com_phocamenu&controller=phocamenugroup&task=edit&type='.(int)$this->tmpl['type'].'&cid[]='.$row->id;
	$linkView 		= 'index.php?option=com_phocamenu&view=phocamenuitems&type='.(int)$this->tmpl['type'].'&gid='.$row->id;
	$linkRemove 	= 'index.php?option=com_phocamenu&controller=phocamenugroup&task=remove&type='.(int)$this->tmpl['type'].'&cid[]='.$row->id.'&'.$this->tmpl['typecatid'].'='.$row->catid;
	$checked 	= JHTML::_('grid.checkedout', $row, $i );
	$published 	= JHTML::_('grid.published', $row, $i );
	?>
		<td><?php echo $this->pagination->getRowOffset( $i ); ?></td>
		<td><?php echo $checked; ?></td>
		<td><?php
			if ( JTable::isCheckedOut($this->user->get ('id'), $row->checked_out ) ) {
				echo $row->title;
			} else {
				echo '<a href="'.$linkEdit.'" title="'. JText::_( 'Edit Phoca Menu Group' ).'">'.$row->title.'</a>';
			}
			?>
		</td>
		<td align="center">
			<a href="<?php echo $linkView; ?>" title="<?php echo JText::_('View Group Items'); ?>"><?php echo JHTML::_('image.site',  'icon-16-item.png', '/components/com_phocamenu/assets/images/', NULL, NULL, JText::_('View Group Items') )?></a>
		</td>
		<td align="center">
			<a href="<?php echo $linkRemove; ?>" onclick="return confirm('<?php echo JText::_('Warning delete group'); ?>');" title="<?php echo JText::_('Delete'); ?>"><?php echo JHTML::_('image.site',  'icon-16-trash.png', '/components/com_phocamenu/assets/images/', NULL, NULL, JText::_('Delete') )?></a>
		</td>
		
		<td align="center"><?php echo $published;?></td>
		<td class="order">
			<span><?php echo $this->pagination->orderUpIcon( $i, ($row->catid == @$this->items[$i-1]->catid),'orderup', 'Move Up', $ordering ); ?></span>
			<span><?php echo $this->pagination->orderDownIcon( $i, $n, ($row->catid == @$this->items[$i+1]->catid), 'orderdown', 'Move Down', $ordering ); ?></span>
		<?php $disabled = $ordering ?  '' : 'disabled="disabled"'; ?>
			<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
		</td>					
		<td align="center"><?php echo $row->id; ?></td>
	</tr>
	<?php
	$k = 1 - $k;
}
?>
<tfoot>
	<tr>
		<td colspan="11"><?php echo $this->pagination->getListFooter(); ?></td>
	</tr>
</tfoot>
</table>
</div>


<input type="hidden" name="controller" value="phocamenugroup" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="<?php echo $this->tmpl['typecatid'];?>" value="<?php echo (int)$this->tmpl['catid'];?>" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>