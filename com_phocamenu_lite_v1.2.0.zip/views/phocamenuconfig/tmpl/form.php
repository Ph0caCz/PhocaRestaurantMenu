<?php
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
echo PhocaMenuRender::renderFormStyle();
?>

<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm" id="adminForm">
<div class="col50">
<fieldset class="adminform">
<legend><?php echo JText::_('Settings'); ?></legend>

<table class="admintable"><?php
switch ($this->tmpl['type']) {
	case 1:
		$date = PhocaMenuHelper::getDate($this->item->date, $this->tmpl['daydateformat'], $this->tmpl['dateclass']);
		echo PhocaMenuRender::renderFormItemSpecial('date', 'Date', $date . '<br />' . JHTML::_('calendar', $this->item->date, 'date', 'date', "%Y-%m-%d", array('class'=>'inputbox', 'size'=>'45',  'maxlength'=>'45') ) );
	
	break;
			
	case 2:
		$date = PhocaMenuHelper::getDate($this->item->date_from, $this->tmpl['weekdateformat'], $this->tmpl['dateclass']);
		echo PhocaMenuRender::renderFormItemSpecial('date_from', 'Date From', $date . '<br />' . JHTML::_('calendar', $this->item->date_from, 'date_from', 'date_from', "%Y-%m-%d", array('class'=>'inputbox', 'size'=>'45',  'maxlength'=>'45') ) );
	
		$date = PhocaMenuHelper::getDate($this->item->date_to, $this->tmpl['weekdateformat'], $this->tmpl['dateclass']);
		echo PhocaMenuRender::renderFormItemSpecial('date_from', 'Date To', $date . '<br />' . JHTML::_('calendar', $this->item->date_to, 'date_to', 'date_to', "%Y-%m-%d", array('class'=>'inputbox', 'size'=>'45',  'maxlength'=>'45') ) );
	break;				
}

if ($this->tmpl['enableeditor'] == 1) {
	echo PhocaMenuRender::renderFormItemSpecial('header', 'Header', $this->editor->display( 'header',  $this->item->header, '550', '300', '60', '20', array('pagebreak', 'phocadownload', 'readmore') ) );
	echo PhocaMenuRender::renderFormItemSpecial('footer', 'Footer', $this->editor->display( 'footer',  $this->item->footer, '550', '300', '60', '20', array('pagebreak', 'phocadownload', 'readmore') ) );
} else {
	echo PhocaMenuRender::renderFormTextArea('header', 'Header', $this->item->header, 60, 20, '');
	echo PhocaMenuRender::renderFormTextArea('footer', 'Footer', $this->item->footer, 60, 20, '');
}

?>

</table>
</fieldset>
</div>

<div class="clr"></div>

<div class="col50">
<fieldset class="adminform">
<legend><?php echo JText::_('Metadata Configuration'); ?></legend>
<table class="admintable">
<?php
echo PhocaMenuRender::renderFormTextArea('meta_title', 'Title', $this->item->meta_title );
echo PhocaMenuRender::renderFormTextArea('meta_keywords', 'Keywords', $this->item->meta_keywords );
?>	
</table>
</fieldset>
</div>
<div class="clr"></div>

<input type="hidden" name="controller" value="phocamenuconfig" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="cid[]" value="<?php echo (int)$this->item->id; ?>" />
<input type="hidden" name="<?php echo $this->tmpl['typecatid'];?>" value="<?php echo (int)$this->tmpl['catid'];?>" />
<input type="hidden" name="typeback" value="<?php echo $this->tmpl['typeback'];?>" />
<?php echo JHTML::_( 'form.token' ); ?>	
</form>