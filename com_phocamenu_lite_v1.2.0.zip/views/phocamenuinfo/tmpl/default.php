<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php JHTML::_('behavior.tooltip'); ?>

<form action="index.php" method="post" name="adminForm">
<div style="float:right;margin:10px;">
	<?php
	echo JHTML::_('image.site',  'logo-phoca.png', '/components/com_phocamenu/assets/images/', NULL, NULL, 'Phoca.cz' )
	?>
</div>

<?php echo  JHTML::_('image.site', 'logo-product.png', 'components/com_phocamenu/assets/images/', NULL, NULL, 'Phoca.cz');?>

<h3><?php echo JText::_('Help');?></h3>

<div id="phocamenu-info">
<p>
<a href="http://www.phoca.cz/phocamenu/" target="_blank">Phoca Restaurant Menu Main Site</a><br />
<a href="http://www.phoca.cz/documentation/" target="_blank">Phoca Restaurant Menu User Manual</a><br />
<a href="http://www.phoca.cz/forum/" target="_blank">Phoca Restaurant Menu Forum</a><br />
</p>

<h3><?php echo JText::_('Version');?></h3>
<p><?php echo $this->version ;?></p>

<h3><?php echo JText::_('Copyright');?></h3>
<p>© 2007 - <?php echo date("Y"); ?> Jan Pavelka</p>

<h3><?php echo JText::_('License');?></h3>
<p><a href="http://www.gnu.org/licenses/gpl-2.0.html" target="_blank">GPLv2</a></p>


<input type="hidden" name="option" value="com_phocamenu" />
<input type="hidden" name="controller" value="phocamenuinfo" />
<input type="hidden" name="task" value="" />
</form>
<p>&nbsp;</p>
</div>

<div style="border-top:1px solid #c2c2c2"></div>
<div id="pg-update" ><a href="http://www.phoca.cz/version/index.php?phocamenu=<?php echo $this->version ;?>" target="_blank"><?php echo JText::_('Check for update'); ?></a></div>