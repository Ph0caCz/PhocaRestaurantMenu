<?php
defined('_JEXEC') or die('Restricted access');
$user 	=& JFactory::getUser();
//Ordering allowed ?
$ordering = ($this->lists['order'] == 'a.ordering');
?>

<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm">
	<table>
		<tr>
			<td align="left" width="100%"><?php echo JText::_( 'Filter' ); ?>:
				<input type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
				<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
				<button onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>
			</td>
			<td nowrap="nowrap">
				<?php
				echo $this->lists['catid'];
				?>
			</td>
		</tr>
	</table>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					<th width="5"><?php echo JText::_( 'NUM' ); ?></th>
					<th class="image" width="20" align="center"><?php echo JText::_( 'Image' ); ?></th>
					<th class="title" width="40%"><?php echo JHTML::_('grid.sort',  'Title', 'a.title', $this->lists['order_Dir'], $this->lists['order'] ); ?>
					</th>
					<th width="30%" nowrap="nowrap"><?php echo JHTML::_('grid.sort',  'Filename', 'a.filename', $this->lists['order_Dir'], $this->lists['order'] ); ?>
					</th>
					<th width="10%" nowrap="nowrap"><?php echo JText::_('Functions'); ?>
					</th>
					<th width="1%" nowrap="nowrap"><?php echo JHTML::_('grid.sort',  'ID', 'a.id', $this->lists['order_Dir'], $this->lists['order'] ); ?>
					</th>
				</tr>
			</thead>
			
			<tbody>
				<?php
				$k = 0;
				for ($i=0, $n=count( $this->items ); $i < $n; $i++){
					$row = &$this->items[$i];					
				?>
				<tr class="<?php echo "row$k"; ?>">
					<td><?php echo $this->pagination->getRowOffset( $i ); ?></td>
					<td align="center" valign="middle">

					<?php
					if (isset($row->extid) && $row->extid != '') {
					
						$resW	= explode(',', $row->extw);
						$resH	= explode(',', $row->exth);
						$correctImageRes = PhocaGalleryImage::correctSizeWithRate($resW[2], $resH[2], 50, 50);
						?>
						<a href="#" onclick="window.top.document.forms.adminForm.elements.imageid.value = <?php echo  $row->id;?>;window.parent.document.getElementById('sbox-window').close();"><?php echo JHTML::_( 'image', $row->exts.'?imagesid='.md5(uniqid(time())), '', array('width' => $correctImageRes['width'], 'height' => $correctImageRes['height']));?></a>
						<?php
					
					
					} else if (isset ($row->fileoriginalexist) && $row->fileoriginalexist == 1) {
						?>
						
						<a href="#" onclick="window.top.document.forms.adminForm.elements.imageid.value = <?php echo  $row->id;?>;window.parent.document.getElementById('sbox-window').close();"><?php echo JHTML::_( 'image', $row->linkthumbnailpath.'?imagesid='.md5(uniqid(time())), '');?></a>
						<?php
					} else {
						echo JHTML::_( 'image.site', 'phoca_thumb_s_no_image.gif', '../administrator/components/com_phocagallery/assets/images/');
					}
					?>					
					</td>
					<td><?php echo $row->title;?></td>
					<td><?php echo $row->filename;?></td>
					<td align="center"><a href="#" onclick="window.top.document.forms.adminForm.elements.imageid.value = <?php echo  $row->id;?>;window.parent.document.getElementById('sbox-window').close();"><?php echo JHTML::_( 'image.site', 'icon-16-insert.png', '/components/com_phocamenu/assets/images/', NULL, NULL, JText::_('Insert ID')) ;?></a></td>
					<td align="center"><?php echo $row->id; ?></td>
				</tr>
				<?php
				$k = 1 - $k;
				}
			?>
			</tbody>
			
			<tfoot>
				<tr>
					<td colspan="6"><?php echo $this->pagination->getListFooter(); ?></td>
				</tr>
			</tfoot>
		</table>
	</div>

<input type="hidden" name="controller" value="phocamenugallery" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="" />
</form>