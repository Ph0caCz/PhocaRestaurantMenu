<?php
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
switch ($this->tmpl['type']){
	case 2:
		echo PhocaMenuRender::renderSubmitButtonJs(array(
			0 => array('title', 'Group name required', 'true', 1),
			1 => array('catid', 'Day must be selected', 'true', 0))
		);
	break;
	
	case 3:
	case 4:
	case 5:
		echo PhocaMenuRender::renderSubmitButtonJs(array(
			0 => array('title', 'Group name required', 'true', 1),
			1 => array('catid', 'List must be selected', 'true', 0))
		);
	break;
	
	default:
		echo PhocaMenuRender::renderSubmitButtonJs(array(
			0 => array('title', 'Group name required', 'true', 1))
		);
	break;
}
echo PhocaMenuRender::renderFormStyle();
?>

<div id="phocamenu-form"><form action="<?php echo $this->request_url; ?>" method="post" name="adminForm" id="adminForm">
<div class="col50">
<fieldset class="adminform">
	<legend><?php echo JText::_('Group Detail'); ?></legend>
	<table class="admintable">
		<?php
		echo PhocaMenuRender::renderFormInput('title', 'Title', $this->item->title);
			switch ($this->tmpl['type']) {
				case 2:
				case 3:
				case 4:
				case 5:
				
					if ((int)$this->tmpl['type'] == 2) {
						echo PhocaMenuRender::renderFormItemSpecial('catid', 'Day', $this->lists['catid'] );
					} else {
						echo PhocaMenuRender::renderFormItemSpecial('catid', 'List', $this->lists['catid'] );
					}
					
				break;
			}
		echo PhocaMenuRender::renderFormItemSpecial('published', 'Published', $this->lists['published'] );
		echo PhocaMenuRender::renderFormItemSpecial('ordering', 'Ordering', $this->lists['ordering'] );
		?>
	</table>	
</fieldset>

<fieldset class="adminform">
<legend><?php echo JText::_('Group Message'); ?></legend>
<table class="admintable">
	<?php	
	if ($this->tmpl['enableeditor'] == 1) {
		echo PhocaMenuRender::renderFormItemSpecial('message', 'Message', $this->editor->display( 'message',  $this->item->message, '550', '300', '60', '20', array('pagebreak','phocadownload', 'readmore') ) );
	} else {
		echo PhocaMenuRender::renderFormTextArea('message', 'Message', $this->item->message, 60, 20, '');
	}
	
	?>
</table>
</fieldset>
</div>

<div class="clr"></div>

<input type="hidden" name="controller" value="phocamenugroup" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="cid[]" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="<?php echo $this->tmpl['typecatid'];?>" value="<?php echo (int)$this->tmpl['catid'];?>" />
</form>
</div>