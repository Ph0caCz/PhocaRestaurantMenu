<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport('joomla.application.component.model');
class PhocaMenuCpModelPhocaMenuGroup extends JModel
{
	var $_id			= null;
	var $_data			= null;
	var $_type			= null;
	
	function __construct() {
		parent::__construct();
		$array 	= JRequest::getVar('cid',  0, '', 'array');
		$type 	= JRequest::getVar('type', 0, '', 'int');
		$this->setId((int)$array[0]);
		$this->setType($type);
	}

	function setId($id) {
		$this->_id				= $id;
		$this->_data			= null;
	}
	
	
	function setType($type) {
		$this->_type	= $type;
		$this->_data	= null;
	}

	function &getData() {
		if ($this->_loadData()) {
		/*	$user = &JFactory::getUser();
			// Check whether category access level allows access
			if ($this->_data->cat_access > $user->get('aid', 0)) {
				JError::raiseError( 403, JText::_('ALERTNOTAUTH') );
				return;
			}*/
		} else {
			$this->_initData();
		}
		return $this->_data;
	}
	
	function isCheckedOut( $uid=0 ) {
		if ($this->_loadData()) {
			if ($uid) {
				return ($this->_data->checked_out && $this->_data->checked_out != $uid);
			} else {
				return $this->_data->checked_out;
			}
		}
	}

	function checkin() {
		if ($this->_id) {
			$table = & $this->getTable();
			if(! $table->checkin($this->_id)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}
		return false;
	}

	function checkout($uid = null) {
		if ($this->_id) {
			// Make sure we have a user id to checkout the article with
			if (is_null($uid)) {
				$user	=& JFactory::getUser();
				$uid	= $user->get('id');
			}
			// Lets get to it and checkout it
			$table = & $this->getTable();
			if(!$table->checkout($uid, $this->_id)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			return true;
		}
		return false;
	}

	function store($data) {	
		$row =& $this->getTable();

		// Bind the form fields to the Phoca gallery table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Create the timestamp for the date
		//$row->date = gmdate('Y-m-d H:i:s');

		// if new item, order last in appropriate group
		if (!$row->id) {
			$where = 'catid = ' . (int) $row->catid . ' AND type = '.(int)$row->type ;
			$row->ordering = $row->getNextOrder( $where );
		}

		// Make sure the Phoca gallery table is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the Phoca gallery table to the database
		if (!$row->store()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		// We don't use Request because while saving the category could be changed and in this case request will be obsolete
		$return['id'] 		= $row->id;
		$return['catid']	= $row->catid;
		return $return;
	}

	function delete($cid = array(), $catid, $typeCatid) {
		
		global $mainframe;
		$db =& JFactory::getDBO();
		
		$result = false;

		// - - - - - - - - - - - - - - -
		// FIRST - Are there some items in the group?
		if (count( $cid )) {
			
			JArrayHelper::toInteger($cid);
			$cids = implode( ',', $cid );
		

			// Select id's from tables. If the group has some items, don't delete it
			$query = 'SELECT g.id, g.title, COUNT( i.catid ) AS numcat'
			. ' FROM #__phocamenu_group AS g'
			. ' LEFT JOIN #__phocamenu_item AS i ON i.catid = g.id'
			. ' WHERE g.id IN ( '.$cids.' )'
			. ' GROUP BY g.id';
		
			$db->setQuery( $query );

			if (!($rows = $db->loadObjectList())) {
				JError::raiseError( 500, $db->stderr('Load Data Problem') );
				return false;
			}
			
			$errItem = array();
			$cid 	 = array();
			foreach ($rows as $row) {
				if ($row->numcat == 0) {
					$cid[] = (int) $row->id;
				} else {
					$errItem[] = $row->title;
				}
			}
			
			if (count( $cid )) {
				$cids = implode( ',', $cid );
				$query = 'DELETE FROM #__phocamenu_group'
				. ' WHERE id IN ( '.$cids.' )';
				$db->setQuery( $query );
				if (!$db->query()) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
		}
			
		// There are some items in the category - don't delete it
		$msg = '';
		if (count( $errItem )) {
				$cidsItem = implode( ", ", $errItem );
				$msg 	 .= JText::sprintf( 'WARNNOTREMOVEDRECORDS PHOCA MENU GROUP ITEMS', $cidsItem );
				
				$type	= JRequest::getVar('type', null, '', 'STRING', JREQUEST_NOTRIM);
				$link 	= 'index.php?option=com_phocamenu&view=phocamenugroups&type='.$type.'&'.$typeCatid.'='. (int) $catid;
				$mainframe->redirect($link, $msg);
		}
		
		return true;
	}

	function publish($cid = array(), $publish = 1) {
		$user 	=& JFactory::getUser();

		if (count( $cid )) {
			JArrayHelper::toInteger($cid);
			$cids = implode( ',', $cid );

			$query = 'UPDATE #__phocamenu_group'
				. ' SET published = '.(int) $publish
				. ' WHERE id IN ( '.$cids.' )'
				. ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id').' ) )'
			;
			$this->_db->setQuery( $query );
			if (!$this->_db->query()) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}
		return true;
	}

	function move($direction, $type)
	{
		$row =& $this->getTable();
		if (!$row->load($this->_id)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		if (!$row->move( $direction, ' catid = '.(int) $row->catid.' AND type ='.$this->_db->Quote($this->_type).' AND published >= 0 ' )) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		return true;
	}


	function saveorder($cid = array(), $order)
	{
		$row =& $this->getTable();
		$groupings = array();

		// update ordering values
		for( $i=0; $i < count($cid); $i++ )
		{
			$row->load( (int) $cid[$i] );
			// track categories
			$groupings[] = $row->catid;

			if ($row->ordering != $order[$i])
			{
				$row->ordering = $order[$i];
				if (!$row->store()) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
		}

		// execute updateOrder for each parent group
		$groupings = array_unique( $groupings );
		foreach ($groupings as $group){
			$row->reorder('catid = '.(int)$group. ' AND type ='.$this->_db->Quote($this->_type) );
		}

		return true;
	}

	function _loadData() {
		if (empty($this->_data))
		{
			$query = 'SELECT a.*'
					.' FROM #__phocamenu_group AS a'
					.' WHERE a.type = '.$this->_db->Quote($this->_type)
					.' AND a.id = '.(int) $this->_id;
			$this->_db->setQuery($query);
			$this->_data = $this->_db->loadObject();		
			return (boolean) $this->_data;
		}
		
		return true;
	}
	
	function _initData()
	{
		// Lets load the content if it doesn't already exist
		if (empty($this->_data))
		{
			$table = new stdClass();
			$table->id					= null;
			$table->catid				= null;
			$table->sid					= null;
			$table->type				= null;
			$table->quantity			= null;
			$table->title				= null;
			$table->alias				= null;
			$table->price				= null;
			$table->message				= null;
			$table->published			= null;
			$table->checked_out			= null;
			$table->checked_out_time	= null;
			$table->ordering			= null;
			$this->_data				= $table;
			return (boolean) $this->_data;
		}
		return true;
	}
}
?>