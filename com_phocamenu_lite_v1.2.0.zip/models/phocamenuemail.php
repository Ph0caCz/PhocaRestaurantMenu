<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport('joomla.application.component.model');
class PhocaMenuCpModelPhocaMenuEmail extends JModel
{	
	var $_id			= null;
	var $_data			= null;
	var $_type			= null;
	
	function __construct() {
		parent::__construct();
		$type = JRequest::getVar('type', 0, '', 'int');
		$this->setType($type);
		$this->setId();
	}

	function setId() {
		
		$query = ' SELECT a.id '
			    .' FROM #__phocamenu_email AS a'
			    .' WHERE a.type ='.(int)$this->_type
				.' LIMIT 1';
					
		// We need only one row, if we don't have one, we must add one -> $row->load($cid[0]) = $row->load(0)
		//						 if we have one, we must edit this one -> $row->load(1)	
		$this->_db->setQuery($query);//Try to find the first row 
		$itemEmail = $this->_db->loadObject();
		if (isset($itemEmail->id)) {
			$this->_id	= $itemEmail->id;
		} else {
			$this->_loadData();// not init data, because there are other items to load
		}
	}
	
	function setType($type) {
		$this->_type	= $type;
		$this->_data	= null;
	}

	function &getData() {
		if ($this->_loadData()) {
		} else {
			$this->_initData();
		}
		return $this->_data;
	}
	
	function _loadData() {
		if (empty($this->_data['email'])) {
		
			/* Specific data from ADMINISTRATOR
			 * In administration you can display data from menu type or you can display one list(day) from menu type
			 * This is used for: PRINT PDF, PREVIEW, MULTIPLE EDIT, EMAIL (administration tools in lists or days)
			 */
			$adminTool 	= JRequest::getVar('admintool', 0, '', 'int');
			$atid		= JRequest::getVar( 'atid', 0, '', 'int' );
		
			//CONFIG
			global $mainframe;			
			$wheres		= array();
			$wheres[]	= 'a.type = '.(int)$this->_type;		
			$query 		= 'SELECT a.*'
						. ' FROM #__phocamenu_config AS a'
						. ' WHERE ' . implode(' AND ', $wheres);
			$this->_db->setQuery($query);
			$this->_data['config'] = $this->_db->loadObject();
						
			//DAY
			$wheres 	= array();
			$wheres[] 	= 'a.published = 1';
			$wheres[]	= 'a.type = '.(int)$this->_type;
			if ($adminTool == 1 && (int)$atid > 0) {
				$wheres[]	= ' a.id = '.(int)$atid;
			}
			$query 		= ' SELECT a.*'
						. ' FROM #__phocamenu_day AS a'
						. ' WHERE ' . implode(' AND ', $wheres)
						. ' ORDER BY ordering ASC';
			$this->_db->setQuery($query);
			$this->_data['day'] = $this->_db->loadObjectList();
			
			//LIST
			$wheres 	= array();
			$wheres[] 	= 'a.published = 1';
			$wheres[]	= 'a.type = '.(int)$this->_type;
			if ($adminTool == 1 && (int)$atid > 0) {
				$wheres[]	= ' a.id = '.(int)$atid;
			}
			$query 		= ' SELECT a.*'
						. ' FROM #__phocamenu_list AS a'
						. ' WHERE ' . implode(' AND ', $wheres)
						. ' ORDER BY ordering ASC';
			$this->_db->setQuery($query);
			$this->_data['list'] = $this->_db->loadObjectList();
			
			//GROUP
			$wheres 	= array();
			$wheres[] 	= 'a.published = 1';
			$wheres[] 	= 'a.type = '.(int)$this->_type;
			$query 		= 'SELECT a.*'
						. ' FROM #__phocamenu_group AS a'
						. ' WHERE ' . implode(' AND ', $wheres)
						. ' ORDER BY ordering ASC';
			$this->_db->setQuery($query);
			$this->_data['group'] = $this->_db->loadObjectList();
			
			//ITEM
			$wheres 	= array();
			$wheres[] 	= 'a.published = 1';
			$wheres[] 	= 'a.type = '.(int)$this->_type;
			$query 		= 'SELECT a.*'
						. ' FROM #__phocamenu_item AS a'
						. ' WHERE ' . implode(' AND ', $wheres)
						. ' ORDER BY ordering ASC';
			$this->_db->setQuery($query);
			$this->_data['item'] = $this->_db->loadObjectList();

			//EMAIL
			$wheres 	= array();
			$wheres[] 	= 'a.published = 1';
			$wheres[] 	= 'a.type = '.(int)$this->_type;
			$wheres[]	= 'a.id = '.(int) $this->_id;
			$query 		= 'SELECT a.*'
						. ' FROM #__phocamenu_email AS a'
						. ' WHERE ' . implode(' AND ', $wheres)
						. ' ORDER BY ordering ASC';
			$this->_db->setQuery($query);
			$this->_data['email'] = $this->_db->loadObject();
			
		
			$wheres = array();
			return (boolean) $this->_data;
		}
		return true;
		
	}
	
	
	function isCheckedOut( $uid=0 ) {
		
		if ($this->_loadData()) {
			foreach ($this->_data as $value => $key) {
				if (empty($key)) {
				} else {
					if ( ($value == 'config') || $value == 'email') {
						if ($uid) {
							if($key->checked_out && $key->checked_out != $uid) {
								return true;
							}
						}
					} else {
						foreach($key as $value2 => $key2) {
							if ($uid) {
								if($key2->checked_out && $key2->checked_out != $uid) {
									return true;
								}
							}
						}
					}
				}
			}
			return null;
		}
	}

	function checkin() {
		if ($this->_id) {
			$table = & $this->getTable();
			if(! $table->checkin($this->_id)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}
		return false;
	}

	function checkout($uid = null) {
		if ($this->_id) {
			// Make sure we have a user id to checkout the article with
			if (is_null($uid)) {
				$user	=& JFactory::getUser();
				$uid	= $user->get('id');
			}
			// Lets get to it and checkout it
			$table = & $this->getTable();
			if(!$table->checkout($uid, $this->_id)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			return true;
		}
		return false;
	}
	
	function store($data) {
		$row =& $this->getTable();

		// Bind the form fields to the Phoca  table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}	
		
		// if new item, order last in appropriate group
		if (!$row->id) {
			$where = 'catid = ' . (int) $row->catid ;
			$row->ordering = $row->getNextOrder( $where );
		}
		
		// Make sure the Phoca table is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the Phoca table to the database
		if (!$row->store()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		return $row->id;
	}
	
	function _initData() {
		if (empty($this->_data['email'])) {
			$table = new stdClass();
			$table->id					= null;
			$table->catid				= null;
			$table->sid					= null;
			$table->type				= null;
			$table->from				= null;
			$table->fromname			= null;
			$table->to					= null;
			$table->subject				= null;
			$table->alias				= null;
			$table->message				= null;
			$table->mode				= null;
			$table->cc					= null;
			$table->bcc					= null;
			$table->attachment			= null;
			$table->replyto				= null;
			$table->replytoname			= null;
			$table->published			= null;
			$table->checked_out			= null;
			$table->checked_out_time	= null;
			$table->ordering			= null;
			$this->_data['email']			= $table;
			
			$this->_data['config']			= null;
			$this->_data['item']			= null;
			$this->_data['group']			= null;
			$this->_data['list']			= null;
			$this->_data['date']			= null;
			return (boolean) $this->_data;
		}
		return true;
	}
}
?>