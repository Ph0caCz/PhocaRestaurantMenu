<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
jimport('joomla.application.component.model');
class PhocaMenuCpModelPhocaMenuConfig extends JModel
{
	var $_id			= null;
	var $_data			= null;
	var $_type			= null;
	
	function __construct() {
		parent::__construct();
		$type = JRequest::getVar('type', 0, '', 'int');
		$this->setType($type);
		$this->setId();
	}

	function setId() {
		
		$query = ' SELECT a.id '
			    .' FROM #__phocamenu_config AS a'
			    .' WHERE a.type ='.(int)$this->_type
				.' LIMIT 1';
					
		// We need only one row, if we don't have one, we must add one -> $row->load($cid[0]) = $row->load(0)
		//						 if we have one, we must edit this one -> $row->load(1)	
		$this->_db->setQuery($query);//Try to find the first row 
		$itemConfig = $this->_db->loadObject();
		if (isset($itemConfig->id)) {
			$this->_id	= $itemConfig->id;
		} else {
			$this->_initData();
		}
	}
	
	function setType($type) {
		$this->_type	= $type;
		$this->_data	= null;
	}

	function &getData() {
		if ($this->_loadData()) {
		} else {
			$this->_initData();
		}
		return $this->_data;
	}
	
	function isCheckedOut( $uid=0 ) {
		if ($this->_loadData()) {
			if ($uid) {
				return ($this->_data->checked_out && $this->_data->checked_out != $uid);
			} else {
				return $this->_data->checked_out;
			}
		}
	}

	function checkin() {
		if ($this->_id) {
			$table = & $this->getTable();
			if(! $table->checkin($this->_id)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}
		return false;
	}

	function checkout($uid = null) {
		if ($this->_id) {
			// Make sure we have a user id to checkout the article with
			if (is_null($uid)) {
				$user	=& JFactory::getUser();
				$uid	= $user->get('id');
			}
			// Lets get to it and checkout it
			$table = & $this->getTable();
			if(!$table->checkout($uid, $this->_id)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			return true;
		}
		return false;
	}

	function store($data) {	
		$row =& $this->getTable();

		// Bind the form fields to the Phoca table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Create the timestamp for the date
		//$row->date = gmdate('Y-m-d H:i:s');

		// if new item, order last in appropriate group
		if (!$row->id) {
			$where = 'catid = ' . (int) $row->catid ;
			$row->ordering = $row->getNextOrder( $where );
		}

		// Make sure the Phoca gallery table is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the Phoca gallery table to the database
		if (!$row->store()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		return $row->id;
	}

	function _loadData() {
		if (empty($this->_data))
		{
			$query = 'SELECT a.*'
					.' FROM #__phocamenu_config AS a'
					.' WHERE a.type = '.(int)$this->_type
					.' AND a.id = '.(int) $this->_id;
			$this->_db->setQuery($query);
			$this->_data = $this->_db->loadObject();
			return (boolean) $this->_data;
		}
		return true;
	}
	
	function _initData() {
		if (empty($this->_data)) {
			$table = new stdClass();
			$table->id					= null;
			$table->catid				= null;
			$table->sid					= null;
			$table->type				= null;
			$table->header				= null;
			$table->date				= null;
			$table->date_from			= null;
			$table->date_to				= null;
			$table->footer				= null;
			$table->meta_title			= null;
			$table->meta_keywords		= null;
			$table->published			= null;
			$table->checked_out			= null;
			$table->checked_out_time	= null;
			$table->ordering			= null;
			$this->_data				= $table;
			return (boolean) $this->_data;
		}
		return true;
	}
}
?>