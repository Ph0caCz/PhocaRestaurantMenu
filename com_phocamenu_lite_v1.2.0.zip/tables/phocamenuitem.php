<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

class TablePhocaMenuItem extends JTable
{

	/* Item Table */
	var $id					= null;
	var $catid				= null;
	var $sid				= null;
	var $imageid			= null;
	var $type				= null;
	var $quantity			= null;
	var $title				= null;
	var $alias				= null;
	var $price				= null;
	var $description		= null;
	var $published			= null;
	var $checked_out		= null;
	var $checked_out_time	= null;
	var $ordering			= null;

	function __construct( &$db ) {
		parent::__construct( '#__phocamenu_item', 'id', $db );
	}
}
?>