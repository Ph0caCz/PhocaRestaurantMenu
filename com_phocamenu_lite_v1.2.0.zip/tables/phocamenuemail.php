<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
class TablePhocaMenuEmail extends JTable
{
	/* Email Table */
	
	var $id					= null;
	var $catid				= null;
	var $sid				= null;
	var $type				= null;
	var $from				= null;
	var $fromname			= null;
	var $to					= null;
	var $subject			= null;
	var $alias				= null;
	var $message			= null;
	var $mode				= null;
	var $cc					= null;
	var $bcc				= null;
	var $attachment			= null;
	var $replyto			= null;
	var $replytoname		= null;
	var $published			= null;
	var $checked_out		= null;
	var $checked_out_time	= null;
	var $ordering			= null;

	function __construct( &$db ) {
		parent::__construct( '#__phocamenu_email', 'id', $db );
	}
}
?>