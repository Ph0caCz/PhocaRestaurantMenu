<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
class TablePhocaMenuDay extends JTable
{
	var $id					= null;
	var $catid				= null;
	var $sid				= null;
	var $type				= null;
	var $title				= null;
	var $alias				= null;
	var $published			= null;
	var $checked_out		= null;
	var $checked_out_time	= null;
	var $ordering			= null;

	function __construct( &$db ) {
		parent::__construct( '#__phocamenu_day', 'id', $db );
	}
}
?>