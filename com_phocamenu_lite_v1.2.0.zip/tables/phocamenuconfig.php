<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
class TablePhocaMenuConfig extends JTable
{
	
	var $id					= null;
	var $catid				= null;
	var $sid				= null;
	var $type				= null;
	var $title				= null;
	var $header				= null;
	var $date				= null;
	var $date_from			= null;
	var $date_to			= null;
	var $footer				= null;
	var $meta_title			= null;
	var $meta_keywords		= null;
	var $published			= null;
	var $checked_out		= null;
	var $checked_out_time	= null;
	var $ordering			= null;

	function __construct( &$db ) {
		parent::__construct( '#__phocamenu_config', 'id', $db );
	}
}
?>