<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
jimport('joomla.application.component.view');
class PhocaMenuFrontViewHtml extends JView
{
	public $button;
	protected $params;
	protected $paramsg;
	protected $tmpl;
	protected $data;
	
	function display($tpl = null) {
		
		$app						= JFactory::getApplication();		
		$this->params				= $app->getParams();
		$this->tmpl['printview'] 	= JRequest::getVar('print', 0, 'get', 'int');
		$model 						= $this->getModel('Menu');
		
		$type						= PhocaMenuHelper::getTypeByView($this->_name);		
		$this->data					= $model->getData($type);
		$css						= 'components/com_phocamenu/assets/phocamenu.css';
		$cssP						= 'components/com_phocamenu/assets/phocamenu-print.css';
		
		
		// Params
		$this->tmpl['dateclass']		= $this->params->get( 'date_class', 0 );
		$this->tmpl['customclockcode']	= $this->params->get( 'custom_clock_code', '' );
		$this->tmpl['daydateformat']	= $this->params->get( 'day_date_format', 'l, d. F Y' );
		$this->tmpl['daydateformat']	= $this->params->get( 'day_date_format', 'l, d. F Y' );
		$this->tmpl['weekdateformat']	= $this->params->get( 'week_date_format', 'l, d. F Y' );
		$this->tmpl['priceprefix']		= $this->params->get( 'price_prefix', '...' );
		$this->tmpl['displayrss']		= $this->params->get( 'display_rss', 0 );
		
		// Phoca Gallery Test
		// Check if Phoca Gallery is installed and enabled
		// If it is installed and enabled, check if it is allready used on the site (some of row contains imageid value)
		$phocaGallery = PhocaMenuExtensionHelper::getExtensionInfo('com_phocagallery', 'component');
		if ($phocaGallery != 1) {
			$this->tmpl['phocagallery']	= 0;
		} else if (isset($this->data['imagesum']->sum) && (int)$this->data['imagesum']->sum > 0) {
			$this->tmpl['phocagallery']	= 1;
		} else {
			$this->tmpl['phocagallery']	= 0;
		}
		
		if ((int)$this->tmpl['printview'] == 1 ) {
			
			$this->tmpl['phocagallery']		= 0;
			JHTML::stylesheet( $css );
			JHTML::stylesheet( $cssP );

			$this->tmpl['customclockcode'] 	= '';
			$this->paramsg					= array();
			$this->button					= '';
		
		} else if ($this->tmpl['phocagallery'] == 0) {
			
			JHTML::stylesheet( $css );
			if ($type != 1) {
				$this->tmpl['customclockcode'] 	= '';
			}
			$this->paramsg						= array();
			$this->button						= '';
		
		} else {
			
			$this->tmpl['phocagallery']			= 1;
			JHTML::stylesheet( $css );
			PhocaMenuHelper::includePhocaGallery();
			
			$this->paramsg['imagedetailwindow']				= $this->params->get( 'image_detail_window', 2 );
			$this->paramsg['detailwindowbackgroundcolor']	= $this->params->get( 'detail_window_background_color', '#ffffff' );
			$this->paramsg['modalboxoverlaycolor']			= $this->params->get( 'modal_box_overlay_color', '#000000' );
			$this->paramsg['modalboxoverlayopacity']		= $this->params->get( 'modal_box_overlay_opacity', 0.3 );
			$this->paramsg['modalboxbordercolor']			= $this->params->get( 'modal_box_border_color', '#6b6b6b' );
			$this->paramsg['modalboxborderwidth']			= $this->params->get( 'modal_box_border_width', 2 );
			$this->paramsg['frontmodalboxwidth']			= $this->params->get( 'front_modal_box_width', 680 );
			$this->paramsg['frontmodalboxheight']			= $this->params->get( 'front_modal_box_height', 560 );
			
			$this->tmpl['imagesize']						= $this->params->get( 'image_size', 'small' );
			
			$this->button = PhocaMenuGallery::getPhocaGalleryBehaviour($this->paramsg);
		}
	
		$this->assign('params', $this->params);
		$this->assign('tmpl', $this->tmpl);
		
		$this->_prepareDocument();
		parent::display($tpl);
		
	}
	
	protected function _prepareDocument() {
		
		$app		= JFactory::getApplication();
		$menus		= $app->getMenu();
		$pathway 	= $app->getPathway();
		//$this->params		= &$app->getParams();
		$title 		= null;
		
		
		

		$menu = $menus->getActive();
		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', JText::_('COM_PHOCAMENU_PHOCAMENU'));
		}

		$title = $this->params->get('page_title', '');
		if (empty($title)) {
			$title = htmlspecialchars_decode($app->getCfg('sitename'));
		} else if ($app->getCfg('sitename_pagetitles', 0)) {
			$title = JText::sprintf('JPAGETITLE', htmlspecialchars_decode($app->getCfg('sitename')), $title);
		}
		$this->document->setTitle($title);

		if (empty($title)) {
			$title = $this->item->title;
		}
		$this->document->setTitle($title);
		
		if ($this->params->get('menu-meta_description', '')) {
			$this->document->setDescription($this->params->get('menu-meta_description', ''));
		} 

		if ($this->params->get('menu-meta_keywords', '')) {
			$this->document->setMetadata('keywords', $this->params->get('menu-meta_keywords', ''));
		}

		if ($app->getCfg('MetaTitle') == '1' && $this->params->get('menupage_title', '')) {
			$this->document->setMetaData('title', $this->params->get('page_title', ''));
		}

	}
}
?>