<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */ 
defined('_JEXEC') or die();
class PhocaMenuRenderViews
{
	
	/*
	 *
	 *
	 * Daily Menu
	 *
	 *
	 */
	function renderDailyMenu($data, $tmpl, $params, $paramsG, $method = 0) {
	
		$tag = PhocaMenuRenderViews::getStyle($method, $tmpl['phocagallery']);
		$paramsC['displaygroupmsg']	=	$params->get( 'display_group_message', 2 );

		$output = '<div id="phocamenu">';

		// HEADER (Config)
		if (isset($data['config'])) {

			$output .= $tag['header-o'];
			
			if ($tmpl['customclockcode'] != '') {
					
				$output .=  '<table><tr>'
					 .'<td class="pmclock" colspan="2">'.$tmpl['customclockcode'].'</td>'
					 .'<td class="pmtext">' . $data['config']->header . '</td>'
					 .'</tr></table>';
			} else {
				
				$output .=  $data['config']->header;
			}
			
			$output .= $tag['header-c'];
			
			if ($method == 3) {
				$output .= $tag['oddbox-o'];
			}
			
			$date = PhocaMenuHelper::getDate($data['config']->date, $tmpl['daydateformat'], $tmpl['dateclass']);
			
			if ($method == 3) {
					
				$output .= $tag['date-o'] . $date . '<br/>'
				. JHTML::_('calendar', $data['config']->date, 'date['.$data['config']->id.']', 'date'.$data['config']->id, "%Y-%m-%d", array('class'=>'inputbox', 'size'=>'45',  'maxlength'=>'45')) . $tag['date-c'];
				
			} else {
				$output .= $tag['date-o'] . $date . $tag['date-c'];
			}
			
			
		}

		// BODY
		if (isset($data['group'])) {

			for ($g = 0, $gr = count($data['group']); $g < $gr; $g++) {					
				
				if ($method == 3) {		
					$output .= $tag['group-o'] . '<input size="30" type="text" name="group['.$data['group'][$g]->id.']" id="group'.$data['group'][$g]->id.'" value="'.$data['group'][$g]->title.'" />' . $tag['group-c'];
				
				} else {
					$output .= $tag['group-o'] . $data['group'][$g]->title . $tag['group-c'];
					if ($paramsC['displaygroupmsg'] == 1) {
						$output .= $tag['message-o'] .  $data['group'][$g]->message . $tag['message-c'];
					}
				}
				
				if (isset($data['item'])) {
				
					$displayTaskIcons 	= 0;// we don't know if there is some row, if there will be then display icons
					$displayAddRow		= 0;// we don't know if there is some row, if not, don't display add row
					$output .= $tag['item-o'] . $tag['tableitem-o'];
					
					// Second Price, Header Group
					if ($method == 3 ) {
						$output .= PhocaMenuRenderViews::renderGroupHeaderME($data['group'][$g], $tag );
					} else {
						$output .= PhocaMenuRenderViews::renderGroupHeader($data['group'][$g]->display_second_price, $data['group'][$g]->header_price, $data['group'][$g]->header_price2, $tag );
					}
					// END SP
					
					for ($i = 0, $it = count($data['item']); $i < $it; $i++) {
						// item must belong to own group
						if ($data['group'][$g]->id == $data['item'][$i]->catid) {
						
							// Possible tasks in multipleedit - display them only before first row
							if ($method == 3 && $displayTaskIcons == 0) {						
								$output .= PhocaMenuRenderViews::renderTaskIconsME($data['group'][$g]->display_second_price);
								// there is some first row
								$displayTaskIcons 	= 1;
								$displayAddRow		= 1;
							}

							$image	= $tag['spaceimg'];
							// PHOCAGALLERY Image  - - - - - -
							if ((int)$tmpl['phocagallery'] == 1) {
								$image = PhocaMenuGallery::getPhocaGalleryLink($tmpl['imagesize'], $data['item'][$i]->imageid, $data['item'][$i]->imagefilename, $data['item'][$i]->imagecatid, $data['item'][$i]->imageslug, $data['item'][$i]->imagecatslug, $paramsG['imagedetailwindow'], $this->button, $data['item'][$i]->imageextid,$data['item'][$i]->imageexts,$data['item'][$i]->imageextm,$data['item'][$i]->imageextl,$data['item'][$i]->imageextw,$data['item'][$i]->imageexth );	
							}
							// - - - - - - - - - - - - - - - - 
							
							if (isset($data['item'][$i]->price) && $data['item'][$i]->price > 0) {
								$price 		= PhocaMenuHelper::getPriceFormat($data['item'][$i]->price, $params);
								$pricePref	= $tmpl['priceprefix'];
							} else {
								$price 		= '';
								$pricePref	= '';
							}
							
							// Second Price
							if ($data['group'][$g]->display_second_price == 1 && isset($data['item'][$i]->price2) && $data['item'][$i]->price2 > 0) {
								$price2 		= PhocaMenuHelper::getPriceFormat($data['item'][$i]->price2, $params);
								$pricePref2		= $tmpl['priceprefix'];
							} else {
								$price2 		= '';
								$pricePref2		= '';
							}
							// End SP
								
							if ($method == 3) {
								$output .= PhocaMenuRenderViews::renderFormItemME(1, $tag, $data['group'][$g], $data['item'][$i], $pricePref, $method, $price2, $pricePref2, $data['group'][$g]->display_second_price);
							} else {
								$output .=PhocaMenuRenderViews::renderFormItem(1, $tag, $image, $data['item'][$i], $price, $pricePref, $method, $price2, $pricePref2, $data['group'][$g]->display_second_price);
							}	
						}
					}
					
					$output .= $tag['tableitem-c'] . $tag['item-c'];
					if ($method == 3) {
						if ($displayAddRow == 1) {
							$output .= '<div class="pm-addrow"><small><a href="#" onclick="addRow('.$data['group'][$g]->id.', 1); return false;">'.JText::_('COM_PHOCAMENU_ADD_ROW').'</a></small></div>';
						}
					}
				}// end items
				
				if ($method == 3) {
					$output .= $tag['message-o'] . '<textarea rows="2" cols="60" name="message[' . $data['group'][$g]->id .']" id="message' . $data['group'][$g]->id .'">'. $data['group'][$g]->message . '</textarea>'. $tag['message-c'];		
				} else {
					if ($paramsC['displaygroupmsg'] == 2) {
						$output .= $tag['message-o'] .  $data['group'][$g]->message . $tag['message-c'];
					}
				}
			}
		} // end group
		
		if ($method == 3) {
			//$output .= $tag['bothbox-c'];
		}

		// FOOTER (Config)
		if (isset($data['config'])) {
			$output .=  $tag['footer-o'] . $data['config']->footer .  $tag['footer-c'];
		}

		$output .= '</div>';// end phocamenu

		if ($method == 3) {
			return $output;
		}
		$enableBBCode = $params->get( 'enable_bb_code', 0 );
		if ((int)$enableBBCode == 1) {
			$output = PhocaMenuHelper::bbCodeReplace($output);
			$output = str_replace ( '[br]', '<br />', $output );
		} else if ((int)$enableBBCode  == 2) {
			$output = str_replace ( '[br]', '<br />', $output );
		}
		$output = PhocaMenuHelper::replaceTag($output, $method);
		
		// Remove empty table - because of TCPDF
		$output = str_replace($tag['tableitem-o'].$tag['tableitem-c'], '', $output);
		$output .= PhocaMenuHelper::renderCode($params->get( 'render_code', 1 ), $method);
		return $output;
	}
	
	
	
	
	
	function getStyle($method, $phocaGallery, $suffix = '') {
	
		// 2 means, there are two prices, all the table tds must be recalculated, e.g. $tag['desc2-c']
		switch ($method) {
			
			// Email
			case 1:
				$tag['header-o']		= '<div style="font-size:140%;font-weight:bold;margin:10px">';
				$tag['header-c']		= '</div>';
				$tag['date-o']			= '<div style="font-size:120%;font-weight:bold;margin:10px;text-align:right;">';
				$tag['date-c']			= '</div>';
				$tag['datesub-o']		= '<div style="font-size:110%;font-weight:bold;margin:10px;margin-top:20px;text-decoration:underline">';
				$tag['datesub-c']		= '</div>';
				$tag['list-o']			= '<div style="font-weight:bold;margin:10px;">';
				$tag['list-c']			= '</div>';
				$tag['group-o']			= '<div style="font-weight:bold;margin:10px;">';
				$tag['group-c']			= '</div>';
				$tag['groupleft-o']		= '<div style="overflow:visible;position:relative;float:left;width:43%;margin:1% 2% 1% 1%;">';
				$tag['groupleft-c']		= '</div>';
				$tag['groupright-o']	= '<div style="overflow:visible;position:relative;float:right;width:43%;margin:1% 1% 1% 2%;">';
				$tag['groupright-c']	= '</div>';
				$tag['item-o']			= '<div style="margin:10px;width:100%">';
				$tag['item-c']			= '</div>';
				$tag['tableitem-o']		= '<table width="90%" cellspacing="3" cellpadding="3" style="border:0px;border-collapse:collapse;">';
				$tag['tableitem-c']		= '</table>';
				
				if ($suffix == '-clm') {
					$tag['message-o']		= '<div style="text-align:left">';
				} else {
					$tag['message-o']		= '<div style="text-align:center">';
				}
				$tag['message-c']		= '</div>';
				
				$tag['image-o']			= '<td class="pmimage">';
				$tag['image-rs-o']		= '<td class="pmimage" ';//Not closed - waiting for rowspan
				$tag['image-c']			= '</td>';
				
				if ((int)$phocaGallery == 1) {
					$tag['quantity-o']		= '<td style="vertical-align:middle;width:8%;white-space:nowrap;">';
					if ($suffix == '-clm') {
						$tag['title-o']		= $tag['title2-o']	= '<td style="vertical-align:middle;width:auto;font-weight:bold">';
					} else {
						$tag['title-o']		= $tag['title2-o']	= '<td style="vertical-align:middle;width:auto;">';
					}
					$tag['priceprefix-o']	= '<td style="vertical-align:middle;width:2%">';
					$tag['price-o']			= '<td style="vertical-align:middle;width:5%;white-space:nowrap;padding-left: 10px;">';
					$tag['price2-o']		= '<td style="vertical-align:middle;width:5%;white-space:nowrap;padding-left: 10px;">';
				} else {
					$tag['quantity-o']		= '<td style="width:8%;white-space:nowrap;">';
					if ($suffix == '-clm') {
						$tag['title-o']		= $tag['title2-o']	= '<td style="vertical-align:middle;width:auto;font-weight:bold">';
					} else {
						$tag['title-o']		= $tag['title2-o']	= '<td style="vertical-align:middle;width:auto;">';
					}
					
					$tag['priceprefix-o']	= '<td style="width:2%">';
					$tag['price-o']			= '<td style="width:5%;white-space:nowrap;padding-left: 10px;">';
					$tag['price2-o']		= '<td style="width:5%;white-space:nowrap;padding-left: 10px;">';
				}
				$tag['quantity-c']		= '</td>';
				$tag['title-c']			= '</td>';
				$tag['title2-c']		= '</td>';
				$tag['priceprefix-c']	= '</td>';
				$tag['price-c']			= '</td>';
				$tag['price2-c']		= '</td>';
				
				
				$tag['desc-o']			= $tag['desc2-o'] = '<td style="font-style:italic;margin:5px">';
				$tag['desc-c']			= $tag['desc2-c'] = '</td>';
				
				$tag['groupheader1-o']			= '<td align="right">';
				$tag['groupheader1-c']			= '</td>'. "\n";
				$tag['groupheader2-o']			= '<td align="right" >';
				$tag['groupheader2-c']			= '</td>'. "\n";
				
				
				
				$tag['footer-o']		= '<div class="pm-footer">';
				$tag['footer-c']		= '</div>';
				
				$tag['space']			= '&nbsp;';
				$tag['spaceimg']		= '&nbsp;';
			
				
			break;
			
			//PDF
			case 2:
			
				$tag['header-o']		= '<div>';
				$tag['header-c']		= '</div>';
				$tag['date-o']			= '<p style="font-weight: bold;font-size: x-large;text-align: right;">';
				$tag['date-c']			= '</p>';
				$tag['datesub-o']		= '<p style="font-weight: bold;font-size: large;text-decoration: underline">';
				$tag['datesub-c']		= '</p>';
				$tag['list-o']			= '<p style="font-weight: bold;font-size: large;text-decoration: underline">';
				$tag['list-c']			= '</p>';
				$tag['group-o']			= '<p style="font-weight:bold;font-size:x-large;">';
				$tag['group-c']			= '</p>';
				
				$tag['item-o']			= '<div>';
				$tag['item-c']			= '</div>';
				$tag['tableitem-c']		= '</table>';
				$tag['message-o']		= '<table border="0"><tr><td>';
				$tag['message-c']		= '<br /></td></tr></table>';
				
				$tag['image-o']			= '<td width="2pt">';
				$tag['image-rs-o']		= '<td width="2pt" ';//Not closed - waiting for rowspan
				$tag['image-c']			= '</td>';
				
				if ($suffix == '-bl') {
					
					$tag['tableitem-o']		= '<table border="0" cellpadding="1" >';
					
					$tag['groupleft-o']		= '<table border="0"><tr><td width="245pt">';
					$tag['groupleft-c']		= '</td>';
					$tag['groupright-o']	= '<td width="20pt">&nbsp;</td><td width="245pt">';
					$tag['groupright-c']	= '</td></tr></table>';
					
					$tag['quantity-o']		= '<td width="40pt" style="text-align:right">';
					$tag['title-o']			= '<td width="138pt" >';
					$tag['title2-o']		= '<td width="88pt" >';//Second Price
					$tag['priceprefix-o']	= '<td width="17pt" style="text-align:right;">';
					$tag['price-o']			= $tag['price2-o'] =  '<td width="50pt" style="text-align:right;">';
					
				} else if($suffix == '-clm') {
					
					$tag['tableitem-o']		= '<table border="0" cellpadding="1" >';
					
					$tag['quantity-o']		= '<td width="50pt" style="text-align:right">';
					$tag['title-o']			= '<td width="386pt" style="font-weight:bold;font-size:large;">';
					$tag['title2-o']		= '<td width="336pt" style="font-weight:bold;font-size:large;">';//Second Price
					$tag['priceprefix-o']	= '<td width="22pt" style="text-align:right;">';
					$tag['price-o']			= $tag['price2-o'] =  '<td width="50pt" style="text-align:right;">';
				
				} else {
					
					$tag['tableitem-o']		= '<table border="0" cellpadding="1" >';
					
					$tag['quantity-o']		= '<td width="50pt" style="text-align:right">';
					$tag['title-o']			= '<td width="386pt">';
					$tag['title2-o']		= '<td width="336pt">';//Second Price
					$tag['priceprefix-o']	= '<td width="22pt" style="text-align:right;">';
					$tag['price-o']			= $tag['price2-o'] = '<td width="50pt" style="text-align:right;">';
				}
				
				$tag['quantity-c']		= '</td>';
				$tag['title-c']			= '</td>';
				$tag['title2-c']		= '</td>';
				$tag['priceprefix-c']	= '</td>';
				$tag['price-c']			= '</td>';
				$tag['price2-c']		= '</td>'. "\n";
				
				$tag['groupheader1-o']			= '<td width="50pt" style="text-align:right;">';
				$tag['groupheader1-c']			= '</td>'. "\n";
				$tag['groupheader2-o']			= '<td width="50pt" style="text-align:right;">';
				$tag['groupheader2-c']			= '</td>'. "\n";
				
				if ($suffix == '-bl') {
					$tag['desc-o']			= '<td width="192pt" style="font-style:italic;">';
					$tag['desc2-o']			= '<td width="142pt" style="font-style:italic;">';// Second Price
				} else {
					$tag['desc-o']			= '<td width="386pt" style="font-style:italic;">';
					$tag['desc2-o']			= '<td width="336pt" style="font-style:italic;">';// Second Price
				}
				$tag['desc-c']			= '</td>';
				$tag['desc2-c']			= '</td>';
				
				$tag['footer-o']		= '<table border="0"><tr><td>';
				$tag['footer-c']		= '</td></tr></table>';
			
				$tag['space']			= '&nbsp;';
				$tag['spaceimg']		= '';
				
			break;
			
			

			
			// Multiple Edit
			case 3:
			// Front
			default:
			
				$tag['header-o']		= '<div class="pm-header">';
				$tag['header-c']		= '</div>'. "\n";
				$tag['date-o']			= '<div class="pm-date">';
				$tag['date-c']			= '</div><div class="clr"></div>'. "\n";
				$tag['datesub-o']		= '<div class="pm-date-sub">';
				$tag['datesub-c']		= '</div><div class="clr"></div>'. "\n";
				$tag['list-o']			= '<div class="pm-list">';
				$tag['list-c']			= '</div>'. "\n";
				$tag['group-o']			= '<div class="pm-group">';
				$tag['group-c']			= '</div><div class="clr"></div>'. "\n";
				$tag['groupleft-o']		= '<div class="pm-group-left">';
				$tag['groupleft-c']		= '</div><div class="cr"></div>'. "\n";
				$tag['groupright-o']	= '<div class="pm-group-right">';
				$tag['groupright-c']	= '</div><div class="cl"></div>'. "\n";
				$tag['item-o']			= '<div class="pm-item' .$suffix. '">';
				$tag['item-c']			= '</div>'. "\n";
				$tag['tableitem-o']		= '<table border="0">';
				$tag['tableitem-c']		= '</table><div class="clr"></div>'. "\n";
				$tag['message-o']		= '<div class="pm-message">';
				$tag['message-c']		= '</div><div class="clr"></div>'. "\n";
				
				$tag['image-o']			= '<td class="pmimage">';
				$tag['image-rs-o']		= '<td class="pmimage" ';//Not closed - waiting for rowspan
				$tag['image-c']			= '</td>'. "\n";
				
				if ((int)$phocaGallery == 1) {
					$tag['quantity-o']		= '<td class="pmquantity" style="vertical-align:middle">';
					$tag['title-o']			= '<td class="pmtitle" style="vertical-align:middle">';
					$tag['title2-o']		= '<td class="pmtitle2" style="vertical-align:middle">';
					$tag['priceprefix-o']	= '<td class="pmpriceprefix" style="vertical-align:middle">';
					$tag['price-o']			= '<td class="pmprice" style="vertical-align:middle">';
					$tag['price2-o']		= '<td class="pmprice2" style="vertical-align:middle">';
				} else {
					$tag['quantity-o']		= '<td class="pmquantity">';
					$tag['title-o']			= '<td class="pmtitle">';
					$tag['title2-o']		= '<td class="pmtitle2">';
					$tag['priceprefix-o']	= '<td class="pmpriceprefix">';
					$tag['price-o']			= '<td class="pmprice">';
					$tag['price2-o']		= '<td class="pmprice2">';
				}
				$tag['quantity-c']		= '</td>'. "\n";
				$tag['title-c']			= '</td>'. "\n";
				$tag['title2-c']		= '</td>'. "\n";
				$tag['priceprefix-c']	= '</td>'. "\n";
				$tag['price-c']			= '</td>'. "\n";
				$tag['price2-c']		= '</td>'. "\n";
				
				$tag['desc-o']			= $tag['desc2-o'] = '<td class="pmdesc">';
				$tag['desc-c']			= $tag['desc2-c'] = '</td>'. "\n";
				
				$tag['groupheader1-o']			= '<td class="pmgroupheader1">';
				$tag['groupheader1-c']			= '</td>'. "\n";
				$tag['groupheader2-o']			= '<td class="pmgroupheader2">';
				$tag['groupheader2-c']			= '</td>'. "\n";
				
				
				$tag['footer-o']		= '<div class="pm-footer">';
				$tag['footer-c']		= '</div><div class="clr"></div>'. "\n";
				
				$tag['space']			= '&nbsp;';
				$tag['spaceimg']		= '&nbsp;';
				
				if ($method == 3) {
					$tag['evenbox-o']		= '<div style="background: #E9E3DD;padding:20px;margin:5px">';
					$tag['oddbox-o']		= '<div style="background: #ffece5;padding:20px;margin:5px">';
					$tag['bothbox-c']		= '</div>';
					$tag['date-c']			= '</div><div style="clear:both"></div>';
					$tag['groupleft-o']		= '<div class="pm-group">';// no float
					$tag['groupright-o']	= '<div class="pm-group">';// no float
				}
			break;
		}
		return $tag;
	}
	
	

	function renderFormItem($type, $tag, $image, $itemObject, $price, $pricePref, $method, $price2, $pricePref2, $displaySecondPrice) {
		
		
		// Description
		$rowSpan = '';
		$descRow = '';
		if ($itemObject->description != '') {
			$rowSpan = 'rowspan="2"';
			$descRow = '<tr>'
				. $tag['quantity-o']  . $tag['space'] . $tag['quantity-c'];
			if ($displaySecondPrice == 1) {	
				$descRow.= $tag['desc2-o'] . $itemObject->description . $tag['desc2-c'];
			} else {
				$descRow.= $tag['desc-o'] . $itemObject->description . $tag['desc-c'];
			}
			$descRow .= $tag['priceprefix-o'] . $tag['space'] . $tag['priceprefix-c']
				. $tag['price-o'] . $tag['space'] . $tag['price-c'];
				if ($displaySecondPrice == 1) {
					$descRow .= $tag['price2-o'] . $tag['space'] . $tag['price2-c'];
				}
				$descRow .= '</tr>';
		}

		$output = '<tr>';
		
		// Description
		
		if ($method == 2) {
			$output .= $tag['image-o'] . '' . $tag['image-c'];
		} else if ($itemObject->description != '') {
			$output .= $tag['image-rs-o'] . $rowSpan .'>' . $image . $tag['image-c'];
		} else {
			$output .= $tag['image-o'] . $image . $tag['image-c'];
		}
		
		
		$output .= $tag['quantity-o'] . $itemObject->quantity . $tag['space'] . $tag['quantity-c'];
		if ($displaySecondPrice == 1) {
			$output .= $tag['title2-o'] . $itemObject->title . $tag['title2-c'];
		} else {
			$output .= $tag['title-o'] . $itemObject->title . $tag['title-c'];
		}
		
		// If there is second price, add the prefix before both prices
		if ($price == '') {
			// Seems, there is no price but maybe there is second price
			if ($displaySecondPrice == 1 && $price2 != '') {
				$pricePref = $pricePref2;
			}
		}
				
		$output .= $tag['priceprefix-o'] . $pricePref. $tag['space'] . $tag['priceprefix-c']
				. $tag['price-o'] . $price . $tag['price-c'];
		if ($displaySecondPrice == 1) {
			$output .= $tag['price2-o'] .$price2 . $tag['price2-c'];
		}
		$output .= '</tr>';

			
		// Description
		if ($itemObject->description != '') {
			$output .= $descRow;
		}
		return $output;
	}
	
	function renderFormItemME($type, $tag, $groupObject, $itemObject, $pricePref, $method, $price2, $pricePref2, $displaySecondPrice) {
	
		$output = '<tr class="pm-tr-row-'.$groupObject->id.'">'
		. $tag['quantity-o'] .'<input size="8" type="text" name="itemquantity['.$itemObject->id.']" id="itemquantity'.$itemObject->id.'" value="'.$itemObject->quantity.'" />'. $tag['quantity-c']
		. $tag['title-o'] .'<input size="60" type="text" name="itemtitle['.$itemObject->id.']" id="itemtitle'.$itemObject->id.'" value="'.$itemObject->title.'" />' . $tag['title-c']
		. $tag['priceprefix-o'] . $pricePref. $tag['space'] . $tag['priceprefix-c']
		. $tag['price-o'].'<input size="8" type="text" name="itemprice['.$itemObject->id.']" id="itemprice'.$itemObject->id.'" value="'.$itemObject->price.'" />'. $tag['price-c'];
		if ($displaySecondPrice == 1) {
			$output .= $tag['price2-o'].'<input size="8" type="text" name="itemprice2['.$itemObject->id.']" id="itemprice2'.$itemObject->id.'" value="'.$itemObject->price2.'" />'. $tag['price2-c'];
		}
		$output .= '<td align="center"><input type="radio" name="itempublish['.$itemObject->id.']" id="itempublish'.$itemObject->id.'" value="1" '. (((int)$itemObject->published == 1) ? 'checked="checked"' : '' ).' /></td>'
		. '<td align="center"><input type="radio" name="itempublish['.$itemObject->id.']" id="itempublish'.$itemObject->id.'" value="0" '. (((int)$itemObject->published != 1) ? 'checked="checked"' : '' ).' /></td>'
		
		.'<td align="center"><input id="cb'.$itemObject->id.'" name="itemdelete['.$itemObject->id.']" value="0" onclick="isChecked(this.checked);" type="checkbox" /></td>'

		.'</tr>';						
		
		// Display Description in ME in every case, if it is emtpy, display it too
		$tmpl['enablemeeditor'] = 0;
		if ($tmpl['enablemeeditor'] == 1) {
			$editor = &JFactory::getEditor();
			$description = $editor->display( 'itemdesc[' . $itemObject->id .']',  $itemObject->description, '550', '300', '60', '2', array('pagebreak', 'phocadownload', 'readmore') );
		} else {
			$description = '<textarea rows="2" cols="60" name="itemdesc[' . $itemObject->id .']" id="itemdesc' . $itemObject->id .'">'. $itemObject->description . '</textarea>';
		}
		
		if ($displaySecondPrice == 1) {
			$colspan = 4;
		} else {
			$colspan = 3;
		}
		
		
		if (isset($itemObject->description)) {
			$output .= '<tr class="pmdesctr pm-tr-row-desc-'.$groupObject->id.'">'
			. $tag['quantity-o']  . $tag['space'] . $tag['quantity-c']
			. $tag['desc-o'] . $description . $tag['desc-c']
			. $tag['priceprefix-o'] . $tag['space'] . $tag['priceprefix-c']
			. $tag['price-o'] . $tag['space'] . $tag['price-c']
			. '<td colspan="'.$colspan.'"></td>'
			.'</tr>';
		}
		return $output;		
	}
	
	function renderTaskIconsME($displaySecondPrice) {
	
		if ($displaySecondPrice == 1) {
			$colspan = 5;
		} else {
			$colspan = 4;
		}
	
		$output = '<tr>'
		. '<td colspan="'.$colspan.'">'
		. '<td align="center" title="'.JText::_('COM_PHOCAMENU_PUBLISH').'">'.JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-publish.png', JText::_('COM_PHOCAMENU_PUBLISH')).'</td>'
		. '<td align="center" title="'.JText::_('COM_PHOCAMENU_UNPUBLISH').'">'.JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-unpublish.png', JText::_('COM_PHOCAMENU_UNPUBLISH')).'</td>'
		. '<td align="center" title="'.JText::_('COM_PHOCAMENU_DELETE').'">'.JHTML::_('image', 'components/com_phocamenu/assets/images/icon-16-trash.png', JText::_('COM_PHOCAMENU_DELETE')).'</td>'
		. '</tr>';
		
		return $output;
	}
	
	function renderGroupHeader($displaySecondPrice, $headerPrice, $headerPrice2, $tag ) {
		$output = '';
		$headerGroup = '';
		if ($headerPrice != '') {
			$headerGroup .= $tag['groupheader1-o']	. str_replace(' ', '&nbsp;', $headerPrice) . $tag['groupheader1-c']	;
		}
		if ($displaySecondPrice == 1 && $headerPrice2 != '') {
			$headerGroup .= $tag['groupheader2-o']	. str_replace(' ', '&nbsp;', $headerPrice2) .$tag['groupheader1-c']	;
		}
		
		if ($headerGroup != '') {
			$output .= '<tr>'
			. $tag['image-o'] . '' . $tag['image-c'] // Images disabled or PDF
			. $tag['quantity-o']  .  $tag['space'] . $tag['quantity-c'];
			if ($displaySecondPrice == 1 ) {
				$output .= $tag['title2-o'] . '' . $tag['title2-c'];
			} else {
				$output .= $tag['title-o'] . '' . $tag['title-c'];
			}
			$output .= $tag['priceprefix-o'] . '' . $tag['priceprefix-c']. $headerGroup.'</tr>';
		}
		
		return $output;
	}
	
	function renderGroupHeaderME($groupObject, $tag ) {
	
		$output = '';
		$headerGroup = '';
		if ($groupObject->header_price != '') {
			$headerGroup .= $tag['groupheader1-o']	. '<input size="8" type="text" name="groupheaderprice['.$groupObject->id.']" id="groupheaderprice'.$groupObject->id.'" value="'.$groupObject->header_price.'" />' . $tag['groupheader1-c']	;
		} else {
			$headerGroup .= '<td></td>';
		}
		if ($groupObject->display_second_price == 1 && $groupObject->header_price2 != '') {
			$headerGroup .= $tag['groupheader2-o']	. '<input size="8" type="text" name="groupheaderprice2['.$groupObject->id.']" id="groupheaderprice'.$groupObject->id.'" value="'.$groupObject->header_price2.'" />' .$tag['groupheader1-c']	;
		} else {
			$headerGroup .= '<td></td>';
		}
		
		if ($headerGroup != '') {
			$output .= '<tr>'
			//. $tag['image-o'] . $tag['space'] . $tag['image-c'] // Images disabled or PDF
			. $tag['quantity-o']  .  $tag['space'] . $tag['quantity-c'];
			if ($groupObject->display_second_price == 1 ) {
				$output .= $tag['title2-o'] . $tag['space'] . $tag['title2-c'];
			} else {
				$output .= $tag['title-o'] . $tag['space'] . $tag['title-c'];
			}
			$output .= $tag['priceprefix-o'] . $tag['space'] . $tag['priceprefix-c']. $headerGroup;
		}
		
		if ($groupObject->display_second_price == 1) {
			$colspan = 4;
		} else {
			$colspan = 2;
		}
		
		$output .= '<td colspan="'.$colspan.'"></td>';
		$output .= '</tr>';
		return $output;
	}
}
?>