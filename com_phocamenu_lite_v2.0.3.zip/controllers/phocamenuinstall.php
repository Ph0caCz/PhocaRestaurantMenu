<?php
/*
 * @package Joomla 1.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */
defined('_JEXEC') or die();
class PhocaMenuCpControllerPhocaMenuInstall extends PhocaMenuCpController
{
	function __construct() {
		parent::__construct();
		$this->registerTask( 'install'  , 'install' );
		$this->registerTask( 'upgrade'  , 'upgrade' );		
	}

	function install() {		
		$db			= &JFactory::getDBO();
		//$dbPref 	= $db->getPrefix();
		$msgSQL 	= '';
		$msgFile	= '';
		$msgError	= '';
		
		// ------------------------------------------
		// Phoca Restaurant Menu Config
		// ------------------------------------------
		
		$query =' DROP TABLE IF EXISTS '.$db->nameQuote('#__phocamenu_config').';';
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		$query ='CREATE TABLE IF NOT EXISTS '.$db->nameQuote('#__phocamenu_config').' ('."\n";
		$query.='  '.$db->nameQuote('id').' int(11) unsigned NOT NULL auto_increment,'."\n";
		$query.='  '.$db->nameQuote('catid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('sid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('type').' int(3) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('title').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('alias').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('header').' text,'."\n";
		$query.='  '.$db->nameQuote('date').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('date_from').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('date_to').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('footer').' text,'."\n";
		//$query.='  '.$db->nameQuote('meta_title').' text,'."\n";
		//$query.='  '.$db->nameQuote('meta_keywords').' text,'."\n";
		$query.='  '.$db->nameQuote('metakey').' text,'."\n";
		$query.='  '.$db->nameQuote('metadesc').' text,'."\n";
		$query.='  '.$db->nameQuote('metadata').' text,'."\n";
		$query.='  '.$db->nameQuote('params').' text,'."\n";
		$query.='  '.$db->nameQuote('language').' char(7) NOT NULL default \'\','."\n";
		$query.='  '.$db->nameQuote('published').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out_time').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('ordering').' int(11) NOT NULL default \'0\','."\n";
		$query.='  PRIMARY KEY  ('.$db->nameQuote('id').'),'."\n";
		$query.='  KEY '.$db->nameQuote('catid').' ('.$db->nameQuote('published').')'."\n";
		$query.=')  CHARACTER SET '.$db->nameQuote('utf8').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		
		// ------------------------------------------
		// Phoca Restaurant Menu Day
		// ------------------------------------------
		
		$query=' DROP TABLE IF EXISTS '.$db->nameQuote('#__phocamenu_day').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		$query ='CREATE TABLE IF NOT EXISTS '.$db->nameQuote('#__phocamenu_day').' ('."\n";
		$query.='  '.$db->nameQuote('id').' int(11) unsigned NOT NULL auto_increment,'."\n";
		$query.='  '.$db->nameQuote('catid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('sid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('type').' int(3) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('title').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('alias').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('published').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out_time').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('ordering').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('language').' char(7) NOT NULL default \'\','."\n";
		$query.='  PRIMARY KEY  ('.$db->nameQuote('id').'),'."\n";
		$query.='  KEY '.$db->nameQuote('catid').' ('.$db->nameQuote('catid').','.$db->nameQuote('published').')'."\n";
		$query.=')  CHARACTER SET '.$db->nameQuote('utf8').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		// ------------------------------------------
		// Phoca Restaurant Menu List
		// ------------------------------------------
		
		$query ='DROP TABLE IF EXISTS '.$db->nameQuote('#__phocamenu_list').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		$query ='CREATE TABLE IF NOT EXISTS '.$db->nameQuote('#__phocamenu_list').' ('."\n";
		$query.='  '.$db->nameQuote('id').' int(11) unsigned NOT NULL auto_increment,'."\n";
		$query.='  '.$db->nameQuote('catid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('sid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('type').' int(3) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('title').' text,'."\n";
		$query.='  '.$db->nameQuote('alias').' text,'."\n";
		$query.='  '.$db->nameQuote('published').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out_time').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('ordering').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('language').' char(7) NOT NULL default \'\','."\n";
		$query.='  PRIMARY KEY  ('.$db->nameQuote('id').'),'."\n";
		$query.='  KEY '.$db->nameQuote('catid').' ('.$db->nameQuote('catid').','.$db->nameQuote('published').')'."\n";
		$query.=')  CHARACTER SET '.$db->nameQuote('utf8').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		

		// ------------------------------------------
		// Phoca Restaurant Menu Email
		// ------------------------------------------
		
		$query ='DROP TABLE IF EXISTS '.$db->nameQuote('#__phocamenu_email').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		$query ='CREATE TABLE IF NOT EXISTS '.$db->nameQuote('#__phocamenu_email').' ('."\n";
		$query.='  '.$db->nameQuote('id').' int(11) unsigned NOT NULL auto_increment,'."\n";
		$query.='  '.$db->nameQuote('catid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('sid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('type').' int(3) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('from').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('fromname').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('to').' text,'."\n";
		$query.='  '.$db->nameQuote('subject').' varchar(255) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('title').' varchar(255) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('alias').' varchar(255) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('message').' text,'."\n";
		$query.='  '.$db->nameQuote('mode').' int(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('cc').' text,'."\n";
		$query.='  '.$db->nameQuote('bcc').' text,'."\n";
		$query.='  '.$db->nameQuote('attachment').' text,'."\n";
		$query.='  '.$db->nameQuote('replyto').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('replytoname').' varchar(100) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('published').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out_time').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('ordering').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('language').' char(7) NOT NULL default \'\','."\n";
		$query.='  PRIMARY KEY  ('.$db->nameQuote('id').'),'."\n";
		$query.='  KEY '.$db->nameQuote('catid').' ('.$db->nameQuote('published').')'."\n";
		$query.=')  CHARACTER SET '.$db->nameQuote('utf8').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		
		// ------------------------------------------
		// Phoca Restaurant Menu Group
		// ------------------------------------------
		
		$query ='DROP TABLE IF EXISTS '.$db->nameQuote('#__phocamenu_group').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		$query ='CREATE TABLE IF NOT EXISTS '.$db->nameQuote('#__phocamenu_group').' ('."\n";
		$query.='  '.$db->nameQuote('id').' int(11) unsigned NOT NULL auto_increment,'."\n";
		$query.='  '.$db->nameQuote('catid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('sid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('type').' int(3) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('title').' text,'."\n";
		$query.='  '.$db->nameQuote('alias').' text,'."\n";
		$query.='  '.$db->nameQuote('message').' text,'."\n";
		$query.='  '.$db->nameQuote('display_second_price').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('header_price').' varchar(255) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('header_price2').' varchar(255) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('published').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out_time').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('ordering').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('language').' char(7) NOT NULL default \'\','."\n";
		$query.='  PRIMARY KEY  ('.$db->nameQuote('id').'),'."\n";
		$query.='  KEY '.$db->nameQuote('catid').' ('.$db->nameQuote('catid').','.$db->nameQuote('published').')'."\n";
		$query.=')  CHARACTER SET '.$db->nameQuote('utf8').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		
		// ------------------------------------------
		// Phoca Restaurant Menu Item
		// ------------------------------------------
		
		$query ='DROP TABLE IF EXISTS '.$db->nameQuote('#__phocamenu_item').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}

		$query ='CREATE TABLE IF NOT EXISTS '.$db->nameQuote('#__phocamenu_item').' ('."\n";
		$query.='  '.$db->nameQuote('id').' int(11) unsigned NOT NULL auto_increment,'."\n";
		$query.='  '.$db->nameQuote('catid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('sid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('imageid').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('type').' int(3) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('quantity').' varchar(20) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('title').' text,'."\n";
		$query.='  '.$db->nameQuote('alias').' text,'."\n";
		$query.='  '.$db->nameQuote('price').' varchar(20) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('price2').' varchar(20) NOT NULL,'."\n";
		$query.='  '.$db->nameQuote('description').' text,'."\n";
		$query.='  '.$db->nameQuote('published').' tinyint(1) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('checked_out_time').' datetime NOT NULL default \'0000-00-00 00:00:00\','."\n";
		$query.='  '.$db->nameQuote('ordering').' int(11) NOT NULL default \'0\','."\n";
		$query.='  '.$db->nameQuote('language').' char(7) NOT NULL default \'\','."\n";
		$query.='  PRIMARY KEY  ('.$db->nameQuote('id').'),'."\n";
		$query.='  KEY '.$db->nameQuote('catid').' ('.$db->nameQuote('catid').','.$db->nameQuote('published').')'."\n";
		$query.=')  CHARACTER SET '.$db->nameQuote('utf8').';'."\n";
		
		$db->setQuery( $query );
		if (!$result = $db->query()){$msgSQL .= $db->stderr() . '<br />';}
		

		// Error
		if ($msgSQL !='') {
			$msgError .= '<br />' . $msgSQL;
		}
		/*
		if ($msgFile !='') {
			$msgError .= '<br />' . $msgFile;
		}
		*/	
		// End Message
		if ($msgError !='') {
			$msg = JText::_( 'Phoca Restaurant Menu not successfully installed' ) . ': ' . $msgError;
		} else {
			$msg = JText::_( 'Phoca Restaurant Menu successfully installed' );
		}
		
		$link = 'index.php?option=com_phocamenu';
		$this->setRedirect($link, $msg);
	}
	
	
	function upgrade() {
		
		$db			=& JFactory::getDBO();
		//$dbPref 	= $db->getPrefix();
		$msgSQL 	= '';
		$msgFile	= '';
		$msgError	= '';
		
		// CHECK TABLES
		
		$query =' SELECT * FROM '.$db->nameQuote('#__phocamenu_config').' LIMIT 1;';
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($db->getErrorNum()) {
			$msgSQL .= $db->getErrorMsg(). '<br />';
		}
		
		
		$query=' SELECT * FROM '.$db->nameQuote('#__phocamenu_day').' LIMIT 1;'."\n";
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($db->getErrorNum()) {
			$msgSQL .= $db->getErrorMsg(). '<br />';
		}
		
		$query=' SELECT * FROM '.$db->nameQuote('#__phocamenu_list').' LIMIT 1;'."\n";
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($db->getErrorNum()) {
			$msgSQL .= $db->getErrorMsg(). '<br />';
		}
		
		$query=' SELECT * FROM '.$db->nameQuote('#__phocamenu_email').' LIMIT 1;'."\n";
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($db->getErrorNum()) {
			$msgSQL .= $db->getErrorMsg(). '<br />';
		}
		
		$query=' SELECT * FROM '.$db->nameQuote('#__phocamenu_group').' LIMIT 1;'."\n";
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($db->getErrorNum()) {
			$msgSQL .= $db->getErrorMsg(). '<br />';
		}
		
		$query=' SELECT * FROM '.$db->nameQuote('#__phocamenu_item').' LIMIT 1;'."\n";
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($db->getErrorNum()) {
			$msgSQL .= $db->getErrorMsg(). '<br />';
		}
		

		// Error
		if ($msgSQL !='') {
			$msgError .= '<br />' . $msgSQL;
		}
		/*
		if ($msgFile !='') {
			$msgError .= '<br />' . $msgFile;
		}
		*/	
		// End Message
		if ($msgError !='') {
			$msg = JText::_( 'Phoca Restaurant Menu not successfully upgraded' ) . ': ' . $msgError;
		} else {
			$msg = JText::_( 'Phoca Restaurant Menu successfully upgraded' );
		}
		
		$link = 'index.php?option=com_phocamenu';
		$this->setRedirect($link, $msg);
	}
	
	
	function AddColumnIfNotExists(&$errorMsg, $table, $column, $attributes = "INT( 11 ) NOT NULL DEFAULT '0'", $after = '' ) {
		
		global $mainframe;
		$db				=& JFactory::getDBO();
		$columnExists 	= false;

		$query = 'SHOW COLUMNS FROM '.$table;
		$db->setQuery( $query );
		if (!$result = $db->query()){return false;}
		$columnData = $db->loadObjectList();
		
		foreach ($columnData as $valueColumn) {
			if ($valueColumn->Field == $column) {
				$columnExists = true;
				break;
			}
		}
		
		if (!$columnExists) {
			if ($after != '') {
				$query = 'ALTER TABLE '.$db->nameQuote($table).' ADD '.$db->nameQuote($column).' '.$attributes.' AFTER '.$db->nameQuote($after).';';
			} else {
				$query = 'ALTER TABLE '.$db->nameQuote($table).' ADD '.$db->nameQuote($column).' '.$attributes.';';
			}
			$db->setQuery( $query );
			if (!$result = $db->query()){return false;}
			$errorMsg = 'notexistcreated';
		}
		
		return true;
	}
}
// utf-8 test: ä,ö,ü,ř,ž
?>