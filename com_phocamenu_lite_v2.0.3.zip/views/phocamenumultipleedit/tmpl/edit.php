<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die;
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<script type="text/javascript">
<!--
	function submitbutton(task)
	{
		if (task == 'phocamenumultipleedit.cancel' || document.formvalidator.isValid(document.id('phocamenumultipleedit-form'))) {
			submitform(task);
		}
	

		// @todo Deal with the editor methods
		submitform(task);
	}
// -->
</script>

<form action="<?php JRoute::_('index.php?option=com_phocamenu'); ?>" method="post" name="adminForm" id="phocamenumultipleedit-form" class="form-validate">

<div class="filter-select fltrt">
			
			<div style="position:relative;float:right;width:auto;margin-righ:10px;padding:5px;">
			<?php
			if (isset($this->formdata['itemlanguage']) && $this->formdata['itemlanguage'] != '') {
				jimport('joomla.language.helper');
				$code = JLanguageHelper::getLanguages('lang_code');
				if (isset($code[$this->formdata['itemlanguage']]->title)) {
					echo JText::_('COM_PHOCAMENU_LANGUAGE') . ': '. $code[$this->formdata['itemlanguage']]->title;
				}
			} else { 
				
				echo JText::_('COM_PHOCAMENU_SELECT_LANGUAGE'); ?>: 
				<select name="filter_language" class="inputbox" onchange="this.form.submit()">
					<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->state->get('filter.language'));?>
				</select><?php
				
				echo '<span class="hasTip" title="'.JText::_('COM_PHOCAMENU_WARNING_SELECT_LANG').'">'.JHtml::_('image', 'administrator/components/com_phocamenu/assets/images/icon-16-warning.png', '' )
				.'</span>';
			} ?>
			</div>
			<div style="clear:both"></div>
			
</div>

<div class="width-70 fltlft" >
	<fieldset class="adminform-multiple">
		<legend><?php echo JText::_('COM_PHOCAMENU_EDIT'); ?></legend>
		
		<?php
			$method = $this->typeinfo['render'];
			$output = PhocaMenuRenderViews::$method($this->formdata, $this->tmpl, $this->params, null, 3);
			
			if (isset($output) && $output != '') {
				echo $output;
			}
		?>
			
	</fieldset>
</div>

<div class="clr"></div>

<?php
if (isset($this->formdata['itemlanguage']) && $this->formdata['itemlanguage'] != '') {
	$filterLang = $this->formdata['itemlanguage'];
} else {
	$filterLang = $this->state->get('filter.language');
	if ($filterLang == '') {
		$filterLang = '*';
	}
} ?>
<input type="hidden" name="language" value="<?php echo $filterLang ?>" />

<input type="hidden" name="task" value="" />
<input type="hidden" name="admintool" value="<?php echo (int)$this->tmpl['admintool'];?>" />
<input type="hidden" name="atid" value="<?php echo (int)$this->tmpl['atid'];?>" />
<input type="hidden" name="boxchecked" value="0" />
<?php echo JHtml::_('form.token'); ?>
</form>

