<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );
require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenurenderviews.php' );

class PhocaMenuCpViewPhocaMenuMultipleEdit extends JView

{
	protected $state;
	//protected $item;
	//protected $form;
	protected $tmpl;
	protected $type;
	protected $typeinfo;
	protected $formdata;
	protected $params;

	public function display($tpl = null) {
	
		$this->state	= $this->get('State');
		
		$this->type		= PhocaMenuHelper::getUrlType('multipleedit');
		$this->formdata	= $this->get('FormData');
		$this->typeinfo	= PhocaMenuHelper::getTypeInfo('multipleedit',$this->type['value'] );
	
		
		$document		= &JFactory::getDocument();
		$document->addScript(JURI::base(true).'/components/com_phocamenu/assets/js/addrow.js');
		JHTML::stylesheet('components/com_phocamenu/assets/phocamenu.css' );
		JHTML::stylesheet('administrator/components/com_phocamenu/assets/phocamenu.css' );

		$this->params 						= JComponentHelper::getParams( 'com_phocamenu' );
		$this->tmpl['enableeditoremail']	= $this->params->get( 'enable_editor_email', 1 );
		$this->tmpl['enabledescmultiple']	= $this->params->get( 'enable_desc_multiple', 1 );
		$this->tmpl['enabledescmultiplegroup']	= $this->params->get( 'enable_desc_multiple_group', 1 );
		$this->tmpl['dateclass']			= $this->params->get( 'date_class', 0 );
		$this->tmpl['daydateformat']		= $this->params->get( 'day_date_format', 'l, d. F Y' );
		$this->tmpl['weekdateformat']		= $this->params->get( 'week_date_format', 'l, d. F Y' );
		$this->tmpl['priceprefix']			= $this->params->get( 'price_prefix', '...' );
		$this->tmpl['admintool'] 			= JRequest::getVar('admintool', 0, '', 'int');
		$this->tmpl['atid']					= JRequest::getVar( 'atid', 0, '', 'int' );
		
		if ($this->tmpl['enabledescmultiple'] == 0) {
			$document->addCustomTag( "<style type=\"text/css\"> \n" 
			." .pmdesc, .pmdesctr {display: none;}"
			." </style> \n");
		}
		
		if ($this->tmpl['enabledescmultiplegroup'] == 0) {
			$document->addCustomTag( "<style type=\"text/css\"> \n" 
			." .pm-message {display: none;}"
			." </style> \n");
		}
		
		$this->paramsg 					= NULL;
		$this->tmpl['phocagallery'] 	= 0;
		$this->tmpl['customclockcode'] 	= '';

		
		$this->addToolbar();
		parent::display($tpl);
	}
	
	protected function addToolbar() {
		
		require_once JPATH_COMPONENT.DS.'helpers'.DS.'phocamenumultipleedit.php';
		JRequest::setVar('hidemainmenu', true);
		$bar 		= JToolBar::getInstance('toolbar');
		$user		= JFactory::getUser();
		//$isNew		= ($this->item->id == 0);
		//$checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
		$canDo		= PhocaMenuMultipleEditHelper::getActions();
		//$paramsC 	= JComponentHelper::getParams('com_phocamenu');

		//$text = $isNew ? JText::_( 'COM_PHOCAMENU_NEW' ) : JText::_('COM_PHOCAMENU_EDIT');
		JToolBarHelper::title(   $this->type['info']['text']  , $this->type['info']['pref']);

		if ($canDo->get('core.edit')){
			//JToolBarHelper::apply('phocamenumultipleedit.apply', 'JTOOLBAR_APPLY');
			//JToolBarHelper::save('phocamenumultipleedit.save', 'JTOOLBAR_SAVE');
			// Some items can be marked for removing
			$bar->appendButton( 'Custom', '<a href="#" onclick="javascript:if(document.adminForm.boxchecked.value==0) {submitbutton(\'phocamenumultipleedit.apply\');} else {if(confirm(\''.JText::_('COM_PHOCAMENU_WARNING_DELETE_ITEM').'\')) {submitbutton(\'phocamenumultipleedit.apply\');}}" class="toolbar"><span class="icon-32-apply" title="'.JText::_('COM_PHOCAMENU_SAVE').'"></span>'.JText::_('COM_PHOCAMENU_SAVE').'</a>');
			
			$bar->appendButton( 'Custom', '<a href="#" onclick="javascript:if(document.adminForm.boxchecked.value==0) {submitbutton(\'phocamenumultipleedit.save\');} else {if(confirm(\''.JText::_('COM_PHOCAMENU_WARNING_DELETE_ITEM').'\')) {submitbutton(\'phocamenumultipleedit.save\');}}" class="toolbar"><span class="icon-32-save" title="'.JText::_('COM_PHOCAMENU_SAVE_AND_CLOSE').'"></span>'.JText::_('COM_PHOCAMENU_SAVE_AND_CLOSE').'</a>');
		
			
		}

		JToolBarHelper::cancel('phocamenumultipleedit.cancel', 'JTOOLBAR_CLOSE');

		JToolBarHelper::divider();
		JToolBarHelper::help( 'screen.phocamenu', true );
	}
}
?>
