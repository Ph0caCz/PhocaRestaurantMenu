<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuConfig extends JView
{
	protected $state;
	protected $item;
	protected $form;
	protected $tmpl;
	protected $type;
	
	
	public function display($tpl = null) {
		
		$this->state	= $this->get('State');
		$this->form		= $this->get('Form');
		$this->item		= $this->get('Item');
		$this->type		= PhocaMenuHelper::getUrlType('config');
		
		// Set type for JForm
		$this->item->type = $this->type['value'];

		JHTML::stylesheet('administrator/components/com_phocamenu/assets/phocamenu.css' );


		$this->addToolbar();
		parent::display($tpl);
	}
	
	protected function addToolbar() {
		
		require_once JPATH_COMPONENT.DS.'helpers'.DS.'phocamenuconfig.php';
		JRequest::setVar('hidemainmenu', true);
		$bar 		= JToolBar::getInstance('toolbar');
		$user		= JFactory::getUser();
		$isNew		= ($this->item->id == 0);
		$checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
		$canDo		= PhocaMenuConfigHelper::getActions($this->state->get('filter.config_id'), $this->item->id);
		$paramsC 	= JComponentHelper::getParams('com_phocamenu');

		$text = $isNew ? JText::_( 'COM_PHOCAMENU_NEW' ) : JText::_('COM_PHOCAMENU_EDIT');
		JToolBarHelper::title(   $this->type['info']['text'].': <small><small>[ ' . $text.' ]</small></small>' , $this->type['info']['pref']);

		// If not checked out, can save the item.
		if (!$checkedOut && $canDo->get('core.edit')){
			JToolBarHelper::apply('phocamenuconfig.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save('phocamenuconfig.save', 'JTOOLBAR_SAVE');
			//JToolBarHelper::addNew('phocamenuconfig.save2new', 'JTOOLBAR_SAVE_AND_NEW');
		
		}
		// If an existing item, can save to a copy.
		if (!$isNew && $canDo->get('core.create')) {
			//JToolBarHelper::custom('phocamenuconfig.save2copy', 'copy.png', 'copy_f2.png', 'JTOOLBAR_SAVE_AS_COPY', false);
		}
		if (empty($this->item->id))  {
			JToolBarHelper::cancel('phocamenuconfig.cancel', 'JTOOLBAR_CANCEL');
		}
		else {
			JToolBarHelper::cancel('phocamenuconfig.cancel', 'JTOOLBAR_CLOSE');
		}

		JToolBarHelper::divider();
		JToolBarHelper::help( 'screen.phocamenu', true );
	}
}

/*
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuConfig extends JView
{
	function display($tpl = null) {
		global $mainframe;
		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}
		parent::display($tpl);
	}

	function _displayForm($tpl) {
		global $mainframe, $option;
		$db		= &JFactory::getDBO();
		$uri 	= &JFactory::getURI();
		$user 	= &JFactory::getUser();
		$model	= &$this->getModel();
		$editor = &JFactory::getEditor();
		$params = &JComponentHelper::getParams( 'com_phocamenu' );
		$tmpl	= array();
		
		// Date
		$tmpl['dateclass']		= $params->get( 'date_class', 0 );
		$tmpl['daydateformat']	= $params->get( 'day_date_format', '%A, %d. %B %Y' );
		$tmpl['weekdateformat']	= $params->get( 'week_date_format', '%A, %d. %B %Y' );
		
		$tmpl['enableeditor']	= $params->get( 'enable_editor', 1 );
		
		$tmpl['type']			= JRequest::getVar('type', 0, '', 'int');
		$tmpl['typeback']		= JRequest::getVar('typeback', null, '', 'STRING', JREQUEST_NOTRIM);
		$typeInfo				= PhocaMenuHelper::getTypeInfo('config', $tmpl['type']);
		$typeInfoBack			= PhocaMenuHelper::getTypeInfo($tmpl['typeback'],$tmpl['type']);
		$tmpl['typecatid']		= $typeInfoBack['catid'];
		$tmpl['catid']			= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );
		
		// Data from model
		$item	=& $this->get('Data');

		$isNew	= ($item->id < 1);		

		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'DESCBEINGEDITTED', JText::_( 'Phoca Restaurant Menu' ), $item->title );
			$mainframe->redirect( 'index.php?option=com_phocamenu', $msg );
		}

		// Toolbar
		JToolBarHelper::title( $typeInfo['text'] , $typeInfo['pref']);
		JToolBarHelper::save();
		JToolBarHelper::apply();
		JToolBarHelper::cancel( 'cancel', 'Close' );
		JToolBarHelper::help( 'screen.phocamenu', true );

		// Edit or Create?
		if (!$isNew) {
			$model->checkout( $user->get('id') );
		}
		
		jimport('joomla.filter.output');
		JFilterOutput::objectHTMLSafe( $item, ENT_QUOTES, 'message' );

		$this->assignRef('tmpl', $tmpl);
		$this->assignRef('editor', $editor);
		$this->assignRef('item', $item);
		$this->assignRef('request_url',	$uri->toString());

		parent::display($tpl);
	}
}*/
?>