<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die;
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

?>
<script type="text/javascript">
<!--
	function submitbutton(task)
	{
		if (task == 'phocamenuconfig.cancel' || document.formvalidator.isValid(document.id('phocamenuconfig-form'))) {
			submitform(task);
		}
	
		if (task == 'phocamenuconfig.loadextimg') {
			document.getElementById('loading-ext-img').style.display='block';
		}
		// @todo Deal with the editor methods
		submitform(task);
	}
// -->
</script>

<form action="<?php JRoute::_('index.php?option=com_phocamenuconfig'); ?>" method="post" name="adminForm" id="phocamenuconfig-form" class="form-validate">

	<div class="filter-select fltrt">
			
			<div style="position:relative;float:right;width:auto;margin-righ:10px;padding:5px;">
			<?php echo JText::_('COM_PHOCAMENU_SELECT_LANGUAGE'); ?>: 
			<select name="filter_language" class="inputbox" onchange="this.form.submit()">
				<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->state->get('filter.language'.(int)$this->item->type));?>
			</select>

			<?php 
			echo '<span class="hasTip" title="'.JText::_('COM_PHOCAMENU_WARNING_SELECT_LANG').'">'.JHtml::_('image', 'administrator/components/com_phocamenu/assets/images/icon-16-warning.png', '' )
			.'</span>'
			.'</div>';
			echo '<div style="clear:both"></div>';
			?>

		</div>

	<div class="width-60 fltlft">
		<fieldset class="adminform">
			<legend><?php
			echo empty($this->item->id) ? JText::_('COM_PHOCAMENU_SETTINGS') : JText::sprintf('COM_PHOCAMENU_SETTINGS', $this->item->id); ?></legend>
		
		<ul class="adminformlist">
			<?php
			switch($this->type['value']) {
				case 1:
					$formArray 		= array ('date');
					$hiddenArray	= '<input type="hidden" name="jform[date_from]" id="jform_date_from" value="0" />'."\n"
									 .'<input type="hidden" name="jform[date_to]" id="jform_date_to" value="0" />';
				break;
				case 2:
					$formArray 		= array ('date_from', 'date_to');
					$hiddenArray	= '<input type="hidden" name="jform[date]" id="jform_date" value="0" />';
					
				break;
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				default:
					$formArray 		= array ();
					$hiddenArray	= '<input type="hidden" name="jform[date]" id="jform_date" value="0" />'."\n"
									 .'<input type="hidden" name="jform[date_from]" id="jform_date_from" value="0" />'."\n"
									 .'<input type="hidden" name="jform[date_to]" id="jform_date_to" value="0" />';
				break;
			}

			foreach ($formArray as $value) {
				echo '<li>'.$this->form->getLabel($value) . $this->form->getInput($value).'</li>' . "\n";
			} 
			echo $hiddenArray;
			echo '<input type="hidden" name="jform[type]" id="jform_type" value="'.$this->type['value'].'" />';
			?>
		</ul>
			<?php echo $this->form->getLabel('header'); ?>
			<div class="clr"></div>
			<?php echo $this->form->getInput('header'); ?>
			<div class="clr"></div>
			<?php echo $this->form->getLabel('footer'); ?>
			<div class="clr"></div>
			<?php echo $this->form->getInput('footer'); ?>
			<div class="clr"></div>
	</fieldset>
</div>

<?php /*

<div class="width-40 fltrt">
	<div style="text-align:right;margin:5px;"></div>
	<?php echo JHtml::_('sliders.start','phocamenux-sliders-'.$this->item->id, array('useCookie'=>1)); ?>

	<?php echo JHtml::_('sliders.panel',JText::_('COM_PHOCAMENU_GROUP_LABEL_PUBLISHING_DETAILS'), 'publishing-details'); ?>
		<fieldset class="adminform">
		<ul class="adminformlist">
			<?php foreach($this->form->getFieldset('publish') as $field) {
				echo '<li>';
				if (!$field->hidden) {
					echo $field->label;
				}
				echo $field->input;
				echo '</li>';
			} ?>
			</ul>
		</fieldset>
	
	<?php echo JHtml::_('sliders.end'); ?>
</div> */ ?>

<div class="clr"></div>



<?php // phocamenuconfig.edit - because of filtering language 
$filterLang = $this->state->get('filter.language'.(int)$this->item->type);
if ($filterLang == '') {
	$filterLang = '*';
}

?>
<input type="hidden" name="jform[language]" value="<?php echo $filterLang ?>" />
<input type="hidden" name="task" value="phocamenuconfig.edit" />
<?php echo JHtml::_('form.token'); ?>
</form>


	
