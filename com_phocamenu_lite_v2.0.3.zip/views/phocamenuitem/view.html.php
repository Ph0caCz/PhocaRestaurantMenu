<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuItem extends JView
{
	protected $state;
	protected $item;
	protected $form;
	protected $tmpl;
	protected $type;
	
	
	public function display($tpl = null) {
		
		$this->state	= $this->get('State');
		$this->form		= $this->get('Form');
		$this->item		= $this->get('Item');
		$this->type		= PhocaMenuHelper::getUrlType('item');
		
		JHTML::stylesheet('administrator/components/com_phocamenu/assets/phocamenu.css' );

		// Set type for JForm
		$this->item->type = $this->type['value'];

		$this->addToolbar();
		parent::display($tpl);
	}
	
	protected function addToolbar() {
		
		require_once JPATH_COMPONENT.DS.'helpers'.DS.'phocamenuitems.php';
		JRequest::setVar('hidemainmenu', true);
		$bar 		= JToolBar::getInstance('toolbar');
		$user		= JFactory::getUser();
		$isNew		= ($this->item->id == 0);
		$checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
		$canDo		= PhocaMenuItemsHelper::getActions($this->state->get('filter.item_id'), $this->item->id);
		$paramsC 	= JComponentHelper::getParams('com_phocamenu');

		$text = $isNew ? JText::_( 'COM_PHOCAMENU_NEW' ) : JText::_('COM_PHOCAMENU_EDIT');
		JToolBarHelper::title(   JText::_( 'COM_PHOCAMENU_ITEM' ).': <small><small>[ ' . $text.' ]</small></small>' , $this->type['info']['pref']);

		// If not checked out, can save the item.
		if (!$checkedOut && $canDo->get('core.edit')){
			JToolBarHelper::apply('phocamenuitem.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save('phocamenuitem.save', 'JTOOLBAR_SAVE');
			JToolBarHelper::addNew('phocamenuitem.save2new', 'JTOOLBAR_SAVE_AND_NEW');
		
		}
		// If an existing item, can save to a copy.
		if (!$isNew && $canDo->get('core.create')) {
			//JToolBarHelper::custom('phocamenuitem.save2copy', 'copy.png', 'copy_f2.png', 'JTOOLBAR_SAVE_AS_COPY', false);
		}
		if (empty($this->item->id))  {
			JToolBarHelper::cancel('phocamenuitem.cancel', 'JTOOLBAR_CANCEL');
		}
		else {
			JToolBarHelper::cancel('phocamenuitem.cancel', 'JTOOLBAR_CLOSE');
		}

		JToolBarHelper::divider();
		JToolBarHelper::help( 'screen.phocamenu', true );
	}
}

/*
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuItem extends JView
{
	function display($tpl = null) {
		global $mainframe;
		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}
		parent::display($tpl);
	}

	function _displayForm($tpl) {
		global $mainframe, $option;
		$db		= &JFactory::getDBO();
		$uri 	= &JFactory::getURI();
		$user 	= &JFactory::getUser();
		$model	= &$this->getModel();
		$editor = &JFactory::getEditor();
		$params = &JComponentHelper::getParams( 'com_phocamenu' );
		$tmpl	= array();
		
		$tmpl['type']		= JRequest::getVar('type', 0, '', 'int');
		$typeInfo			= PhocaMenuHelper::getTypeInfo('item', $tmpl['type']);
		$tmpl['catid'] 		= JRequest::getVar( 'gid', 0, 'post', 'int' );// Only for New (New can be added only by POST)
		$tmpl['typepref']	= $typeInfo['pref'];
		$tmpl['typecatid']	= $typeInfo['catid'];
		
		
		$tmpl['enableeditor']	= $params->get( 'enable_editor', 1 );
		
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );
		
		// Data from model
		$item	=& $this->get('Data');
		
		$lists 	= array();		
		$isNew	= ($item->id < 1);

		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'DESCBEINGEDITTED', JText::_( 'Phoca Restaurant Menu' ), $item->title );
			$mainframe->redirect( 'index.php?option=com_phocamenu', $msg );
		}

		// Toolbar
		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title( $typeInfo['text'] .': <small><small>[ ' . $text.' ]</small></small>', 'dm' );
		JToolBarHelper::save();
		JToolBarHelper::apply();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}
		JToolBarHelper::help( 'screen.phocamenu', true );

		// Edit or Create?
		if (!$isNew) {
			$model->checkout( $user->get('id') );
		} else {
			// Initialise new record
			$item->published 	= 1;
			$item->order 		= 0;
		}

		// Edit or Create
		if ($item->catid > 0) {
			$tmpl['catid'] = (int)$item->catid;// Edit
		} 
		
		// Lists - - - - - - - - - - - - - - -
		// Build the html select list for ordering
		$query = 'SELECT ordering AS value, title AS text'
			    .' FROM #__phocamenu_item'
			    .' WHERE type = '.(int)$tmpl['type']
				.' AND catid = '.(int)$tmpl['catid'] // we use the catid from database, so it will be changed on site
			    .' ORDER BY ordering';
		$lists['ordering'] 	= JHTML::_('list.specificordering',  $item, $item->id, $query, false );
		
		// Build the html select list
		$lists['published'] = JHTML::_('select.booleanlist',  'published', 'class="inputbox"', $item->published );
		
		if (isset($item->catid) && $item->catid > 0) {
			// EDIT
			$groupCatid = $item->catid;
		} else {
			// NEW
			$groupCatid = $tmpl['catid'];
		}
		// Build the list of categories
		switch($tmpl['type']) {
			case 2:				
				$leftJoin 	= ' LEFT JOIN #__phocamenu_day AS d ON d.id = a.catid';
				$and		= ' AND d.id = (SELECT catid FROM #__phocamenu_group WHERE id = '.(int)$groupCatid.' LIMIT 1)';
			break;
			case 3:
			case 4:
			case 5:			
				$leftJoin 	= ' LEFT JOIN #__phocamenu_list AS l ON l.id = a.catid';
				$and		= ' AND l.id = (SELECT catid FROM #__phocamenu_group WHERE id = '.(int)$groupCatid.' LIMIT 1)';
			break;
			default;
				$leftJoin 	= '';
				$and		= '';
			break;
			
		}
		
		$query = 'SELECT a.title AS text, a.id AS value, a.catid AS parentid'
		. ' FROM #__phocamenu_group AS a'
		. $leftJoin
		. ' WHERE a.type = '.(int)$tmpl['type']
		. $and
		. ' ORDER BY a.ordering';
		
		$db->setQuery( $query );
		$itemlist = $db->loadObjectList();
		
		array_unshift($itemlist, JHTML::_('select.option', '0', '- '.JText::_('Select Category').' -', 'value', 'text'));
		//list categories
		$lists['catid'] = JHTML::_( 'select.genericlist', $itemlist, 'catid',  '', 'value', 'text', $tmpl['catid']);
		// - - - - - - - - - - - - - - -

		jimport('joomla.filter.output');
		JFilterOutput::objectHTMLSafe( $item, ENT_QUOTES, 'message' );

		//Image button
		$link = 'index.php?option=com_phocamenu&amp;view=phocamenugallery&amp;tmpl=component';
		JHTML::_('behavior.modal', 'a.modal-button');
		$button = new JObject();
		$button->set('modal', true);
		$button->set('link', $link);
		$button->set('text', JText::_( 'Image' ));
		$button->set('name', 'image');
		$button->set('modalname', 'modal-button');
		$button->set('options', "{handler: 'iframe', size: {x: 760, y: 520}}");
		
		$this->assignRef('button', $button);
		$this->assignRef('tmpl', $tmpl);
		$this->assignRef('editor', $editor);
		$this->assignRef('lists', $lists);
		$this->assignRef('item', $item);
		$this->assignRef('request_url',	$uri->toString());

		parent::display($tpl);
	}
}*/
?>