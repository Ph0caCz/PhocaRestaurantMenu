<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die;
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

?>
<script type="text/javascript">
<!--
	function submitbutton(task)
	{
		if (task == 'phocamenuitem.cancel' || document.formvalidator.isValid(document.id('phocamenuitem-form'))) {
			submitform(task);
		}
	
		// @todo Deal with the editor methods
		submitform(task);
	}
// -->
</script>

<form action="<?php JRoute::_('index.php?option=com_phocamenuitem'); ?>" method="post" name="adminForm" id="phocamenuitem-form" class="form-validate">
	<div class="width-60 fltlft">
		
		<fieldset class="adminform">
			<legend><?php echo empty($this->item->id) ? JText::_('COM_PHOCAMENU_NEW_ITEM') : JText::sprintf('COM_PHOCAMENU_EDIT_ITEM', $this->item->id); ?></legend>
			
						
		<ul class="adminformlist">
			<?php
			$formArray 		= array ('title', 'quantity', 'price', 'price2', 'catid', 'imageid', 'ordering');

			foreach ($formArray as $value) {
				echo '<li>'.$this->form->getLabel($value) . $this->form->getInput($value).'</li>' . "\n";
			} ?>
		</ul>
		<?php

			echo '<input type="hidden" name="jform[type]" id="jform_type" value="'.(int)$this->item->type.'" />';
		
			echo $this->form->getLabel('description');
			echo '<div class="clr"></div>';
			echo $this->form->getInput('description'); ?>
		
		<div class="clr"></div>
		</fieldset>
	</div>

<div class="width-40 fltrt">
	<div style="text-align:right;margin:5px;"></div>
	<?php echo JHtml::_('sliders.start','phocamenux-sliders-'.$this->item->id, array('useCookie'=>1)); ?>

	<?php echo JHtml::_('sliders.panel',JText::_('COM_PHOCAMENU_GROUP_LABEL_PUBLISHING_DETAILS'), 'publishing-details'); ?>
		<fieldset class="adminform">
		<ul class="adminformlist">
			<?php foreach($this->form->getFieldset('publish') as $field) {
				echo '<li>';
				if (!$field->hidden) {
					echo $field->label;
				}
				echo $field->input;
				echo '</li>';
			} ?>
			</ul>
		</fieldset>
	
	<?php echo JHtml::_('sliders.end'); ?>
</div>

<div class="clr"></div>

<input type="hidden" name="type" value="<?php echo (int)$this->type['value'];?>" />
<input type="hidden" name="<?php echo $this->type['info']['catid'];?>" value="<?php echo (int)$this->type['valuecatid'];?>" />
<input type="hidden" name="task" value="" />
<?php echo JHtml::_('form.token'); ?>
</form>

<?php /*
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip'); 

echo PhocaMenuRender::renderSubmitButtonJs(array(
		0 => array('title', 'Item name required', 'true', 1),
		1 => array('catid', 'Group must be selected', 'true', 0)
		)
	);
echo PhocaMenuRender::renderFormStyle();
?>

<form action="<?php echo $this->request_url; ?>" method="post" name="adminForm" id="adminForm">
<div class="col50">
<fieldset class="adminform">
	<legend><?php echo JText::_('Item Detail'); ?></legend>
	<table class="admintable">		
		<?php
		echo PhocaMenuRender::renderFormInput('title', 'Title', $this->item->title);
		echo PhocaMenuRender::renderFormInput('quantity', 'Quantity', $this->item->quantity);
		echo PhocaMenuRender::renderFormInput('price', 'Price', $this->item->price);		
		if ($this->tmpl['enableeditor'] == 1) {
			echo PhocaMenuRender::renderFormItemSpecial('description', 'Description', $this->editor->display( 'description',  $this->item->description, '550', '300', '60', '20', array('pagebreak', 'phocadownload', 'readmore') ) );
		} else {
			echo PhocaMenuRender::renderFormTextArea('description', 'Description', $this->item->description, 60, 20, '');
		}
		echo PhocaMenuRender::renderFormItemSpecial('catid', 'Group', $this->lists['catid'] );
		echo PhocaMenuRender::renderFormItemImageButton('imageid', 'Image ID', $this->item->imageid, 11, 11, $this->button );
		echo PhocaMenuRender::renderFormItemSpecial('published', 'Published', $this->lists['published'] );
		echo PhocaMenuRender::renderFormItemSpecial('ordering', 'Ordering', $this->lists['ordering'] );
		?>
	</table>	
</fieldset>
</div>

<div class="clr"></div>

<input type="hidden" name="controller" value="phocamenuitem" />
<input type="hidden" name="type" value="<?php echo (int)$this->tmpl['type'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="cid[]" value="<?php echo (int)$this->item->id; ?>" />
<input type="hidden" name="gid" value="<?php echo (int)$this->tmpl['catid']; ?>" />
</form>*/?>