<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die;
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'phocamenuemail.cancel' || document.formvalidator.isValid(document.id('phocamenuemail-form'))) {
			Joomla.submitform(task, document.getElementById('phocamenuemail-form'));
			if (task == 'phocamenuemail.send' || task == 'phocamenuemail.sendandsave') {
				document.getElementById('sending-email').style.display='block';
			}
		}
		else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>


<form action="<?php JRoute::_('index.php?option=com_phocamenu'); ?>" method="post" name="adminForm" id="phocamenuemail-form" class="form-validate">

<div class="filter-select fltrt">
			
			<div style="position:relative;float:right;width:auto;margin-righ:10px;padding:5px;">
			<?php
			if (isset($this->bodytext['itemlanguage']) && $this->bodytext['itemlanguage'] != '') {
				jimport('joomla.language.helper');
				$code = JLanguageHelper::getLanguages('lang_code');
				if (isset($code[$this->bodytext['itemlanguage']]->title)) {
					echo JText::_('COM_PHOCAMENU_LANGUAGE') . ': '. $code[$this->bodytext['itemlanguage']]->title;
				}
			} else { 
				
				echo JText::_('COM_PHOCAMENU_SELECT_LANGUAGE'); ?>: 
				<select name="filter_language" class="inputbox" onchange="this.form.submit()">
					<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->state->get('filter.language'));?>
				</select><?php
				
				// MUST BE SET AT THE BOTTOM
				//<input type="hidden" name="task" value="phocamenuemail.edit" />
				
				echo '<span class="hasTip" title="'.JText::_('COM_PHOCAMENU_WARNING_SELECT_LANG').'">'.JHtml::_('image', 'administrator/components/com_phocamenu/assets/images/icon-16-warning.png', '' )
				.'</span>';
			} ?>
			</div>
			<div style="clear:both"></div>

		</div>

	<div class="width-60 fltlft">
		<fieldset class="adminform">
			<legend><?php echo JText::_('COM_PHOCAMENU_EMAIL_DETAILS_CAN_BE_SAVED'); ?></legend>
		
		<ul class="adminformlist">
			<?php

			$formArray 		= array ('fromname', 'from', 'to', 'cc', 'bcc', 'subject');
			
			foreach ($formArray as $value) {
				echo '<li>'.$this->form->getLabel($value) . $this->form->getInput($value).'</li>' . "\n";
			} 
			
			echo '<input type="hidden" name="jform[type]" id="jform_type" value="'.$this->type['value'].'" />';
			echo '<input type="hidden" name="jform[id]" id="jform_id" value="'.$this->form->getValue('id').'" />';
			?>
		</ul>
			
	</fieldset>
</div>

<div class="clr"></div>
<div class="width-60 fltlft">
	<fieldset class="adminform">
		<legend><?php echo JText::_('COM_PHOCAMENU_EMAIL_DETAILS_CANNOT_BE_SAVED'); ?></legend>
		
		<?php
		
			$method = $this->typeinfo['render'];
			$messageOutput = PhocaMenuRenderViews::$method($this->bodytext, $this->tmpl, $this->params, null, 1);

			
			echo '<label title="'.JText::_('COM_PHOCAMENU_BODY_DESC').'" class="hasTip">'.JText::_('COM_PHOCAMENU_BODY_LABEL').'</label>';
			echo '<div class="clr"></div>';
			if ($this->tmpl['enableeditoremail'] == 1) {
				echo $this->editor->display( 'message',htmlspecialchars($messageOutput, ENT_COMPAT, 'UTF-8'), '100%', '450', '0', '0', array('pagebreak', 'phocadownload', 'readmore', 'image') );
			
			} else {
				echo '<textarea class="text_area" id="message" name="message" style="width:100%;height:450px">'.htmlspecialchars($messageOutput, ENT_COMPAT, 'UTF-8').'</textarea>';
			}
			echo '<div class="clr"></div>';
		
		?>
		
	</fieldset>
</div>

<?php
if (isset($this->bodytext['itemlanguage']) && $this->bodytext['itemlanguage'] != '') {
	$filterLang = $this->bodytext['itemlanguage'];
} else {
	$filterLang = $this->state->get('filter.language');
	if ($filterLang == '') {
		$filterLang = '*';
	}
} ?>
<input type="hidden" name="language" value="<?php echo $filterLang ?>" />
<input type="hidden" name="jform[language]" value="<?php echo $filterLang ?>" />

<input type="hidden" name="task" value="phocamenuemail.edit" />
<input type="hidden" name="admintool" value="<?php echo (int)$this->tmpl['admintool'];?>" />
<input type="hidden" name="atid" value="<?php echo (int)$this->tmpl['atid'];?>" />
<?php echo JHtml::_('form.token'); ?>
</form>
<div id="sending-email"><div class="loading"><center><?php echo JHTML::_('image', 'administrator/components/com_phocamenu/assets/images/icon-sending.gif', '' ) . ' &nbsp; &nbsp; '. JText::_('COM_PHOCAMENU_SENDING_MESSAGE'); ?></center></div></div>


	
