<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );
require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenurenderviews.php' );

class PhocaMenuCpViewPhocaMenuEmail extends JView
{
	protected $state;
	protected $item;
	protected $form;
	protected $tmpl;
	protected $type;
	protected $typeinfo;
	protected $bodytext;
	protected $params;
	protected $editor;
	
	
	public function display($tpl = null) {
		
		$this->state	= $this->get('State');
		$this->form		= $this->get('Form');
		$this->item		= $this->get('Item');
		$this->editor 	= JFactory::getEditor();
		$this->type		= PhocaMenuHelper::getUrlType('email');
		$this->bodytext	= $this->get('BodyText');
		$this->typeinfo	= PhocaMenuHelper::getTypeInfo('email',$this->type['value'] );
		
		// Set type for JForm
		$this->item->type = $this->type['value'];

		JHTML::stylesheet('administrator/components/com_phocamenu/assets/phocamenu.css' );

		$this->params 				= JComponentHelper::getParams( 'com_phocamenu' );
		$this->tmpl['enableeditoremail']	= $this->params->get( 'enable_editor_email', 1 );
		$this->tmpl['phocagallery'] 		= 0;
		$this->tmpl['customclockcode'] 	= '';
		$this->tmpl['dateclass']			= $this->params->get( 'date_class', 0 );
		$this->tmpl['daydateformat']		= $this->params->get( 'day_date_format', 'l, d. F Y' );
		$this->tmpl['weekdateformat']		= $this->params->get( 'week_date_format', 'l, d. F Y' );
		$this->tmpl['priceprefix']		= $this->params->get( 'price_prefix', '...' );
		$this->tmpl['admintool'] 			= JRequest::getVar('admintool', 0, '', 'int');
		$this->tmpl['atid']				= JRequest::getVar( 'atid', 0, '', 'int' );
		

		
		
		$this->addToolbar();
		parent::display($tpl);
	}
	
	protected function addToolbar() {
		
		require_once JPATH_COMPONENT.DS.'helpers'.DS.'phocamenuemail.php';
		JRequest::setVar('hidemainmenu', true);
		$bar 		= JToolBar::getInstance('toolbar');
		$user		= JFactory::getUser();
		$isNew		= ($this->item->id == 0);
		$checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
		$canDo		= PhocaMenuEmailHelper::getActions($this->state->get('filter.email_id'), $this->item->id);
		//$paramsC 	= JComponentHelper::getParams('com_phocamenu');

		$text = $isNew ? JText::_( 'COM_PHOCAMENU_NEW' ) : JText::_('COM_PHOCAMENU_EDIT');
		JToolBarHelper::title(   $this->type['info']['text']  , $this->type['info']['pref']);

		// If not checked out, can save the item.
		if (!$checkedOut && $canDo->get('core.manage')){
			JToolBarHelper::custom('phocamenuemail.send', 'email', '', 'COM_PHOCAMENU_SEND', false);
		}
		
		if (!$checkedOut && $canDo->get('core.edit')){
			JToolBarHelper::custom('phocamenuemail.sendandsave', 'emailsave', '', 'COM_PHOCAMENU_SEND_AND_SAVE', false);
			JToolBarHelper::apply('phocamenuemail.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save('phocamenuemail.save', 'JTOOLBAR_SAVE');
			//JToolBarHelper::addNew('phocamenuemail.save2new', 'JTOOLBAR_SAVE_AND_NEW');
		
		}
		// If an existing item, can save to a copy.
		if (!$isNew && $canDo->get('core.create')) {
			//JToolBarHelper::custom('phocamenuemail.save2copy', 'copy.png', 'copy_f2.png', 'JTOOLBAR_SAVE_AS_COPY', false);
		}
		if (empty($this->item->id))  {
			JToolBarHelper::cancel('phocamenuemail.cancel', 'JTOOLBAR_CANCEL');
		}
		else {
			JToolBarHelper::cancel('phocamenuemail.cancel', 'JTOOLBAR_CLOSE');
		}

		JToolBarHelper::divider();
		JToolBarHelper::help( 'screen.phocamenu', true );
	}
}

/*
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );
require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocamenu'.DS.'helpers'.DS.'phocamenurenderviews.php' );
class PhocaMenuCpViewPhocaMenuEmail extends JView
{
	function display($tpl = null) {
		
		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}
		parent::display($tpl);
	}

	function _displayForm($tpl) {
		global $mainframe;
		$uri 			= &JFactory::getURI();
		$user 			= &JFactory::getUser();
		$model			= &$this->getModel();
		$component 		= 'phocamenu';
		$lists 			= array();
		$editor 		= &JFactory::getEditor();
		$params 		= &JComponentHelper::getParams( 'com_phocamenu' );

		$tmpl['type']			= JRequest::getVar('type', 0, '', 'int');
		$tmpl['typeback']		= JRequest::getVar('typeback', null, '', 'STRING', JREQUEST_NOTRIM);
		$typeInfo				= PhocaMenuHelper::getTypeInfo('config', $tmpl['type']);
		$typeInfoBack			= PhocaMenuHelper::getTypeInfo($tmpl['typeback'],$tmpl['type']);
		$tmpl['typecatid']		= $typeInfoBack['catid'];
		$tmpl['catid']			= JRequest::getVar( $typeInfoBack['catid'], 0, '', 'int' );
		$tmpl['render']			= $typeInfo['render'];
		
		//Admin Tools
		$tmpl['admintool'] 	= JRequest::getVar('admintool', 0, '', 'int');
		$tmpl['atid']		= JRequest::getVar( 'atid', 0, '', 'int' );
	
		// Date
		$tmpl['dateclass']		= $params->get( 'date_class', 0 );
		$tmpl['daydateformat']	= $params->get( 'day_date_format', '%A, %d. %B %Y' );
		$tmpl['weekdateformat']	= $params->get( 'week_date_format', '%A, %d. %B %Y' );
		$tmpl['priceprefix']	= $params->get( 'price_prefix', '...' );
		$tmpl['enableeditoremail']	= $params->get( 'enable_editor_email', 1 );

		//Data from model
		$data	= &$this->get('Data');
		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'DESCBEINGEDITTED', JText::_( 'Phoca Restaurant Menu' ), $item->title );
			$mainframe->redirect( 'index.php?option=com_phocamenu', $msg );
		}
		
		JHTML::stylesheet( 'phocamenu.css', 'administrator/components/com_phocamenu/assets/' );
		JToolBarHelper::title(JText::_('Send Email') .' - ' . $typeInfo['title'], $typeInfoBack['pref'] );
		
		JToolBarHelper::customX('sendandsave', 'emailsave', '', 'Send and Save', false);
		JToolBarHelper::customX('send', 'email', '', 'Send', false);
		JToolBarHelper::save();
		JToolBarHelper::apply();
		
		JToolBarHelper::cancel('cancel', 'Close');
		JToolBarHelper::help( 'screen.'.$component, true );
		
		jimport('joomla.filter.output');
		JHTML::_('behavior.calendar');
		
		$paramsG = NULL;
		$tmpl['phocagallery'] 		= 0;
		$tmpl['customclockcode'] 	= '';
		
		$this->assignRef('editor', $editor);
		$this->assignRef('data', $data);
		$this->assignRef('tmpl', $tmpl);
		$this->assignRef('params', $params);
		$this->assignRef('paramsg', $paramsG);//No Phoca Gallery Images in mail
		$this->assignRef('request_url',	$uri->toString());
		
		parent::display($tpl);
	}
}*/
?>
