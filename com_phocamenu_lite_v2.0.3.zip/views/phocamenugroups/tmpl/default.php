<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
 
defined('_JEXEC') or die;
JHtml::_('behavior.tooltip');
$user		= JFactory::getUser();
$userId		= $user->get('id');
$listOrder	= $this->state->get('list.ordering');
$listDirn	= $this->state->get('list.direction');
$canOrder	= $user->authorise('core.edit.state', 'com_phocamenu');
$saveOrder	= 'a.ordering';
echo $this->tmpl['breadcrumb'];
?>


<form action="<?php echo JRoute::_('index.php?option=com_phocamenu&view=phocamenugroups&type='.(int)$this->type['value']); ?>" method="post" name="adminForm" id="adminForm">
	<fieldset id="filter-bar">
		<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search"><?php echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->state->get('filter.search'); ?>" title="<?php echo JText::_('COM_PHOCAMENU_SEARCH_IN_TITLE'); ?>" />
			<button type="submit"><?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();"><?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>
		</div>
		<div class="filter-select fltrt">
			
			<?php echo PhocaMenuHelper::getCategoryList('group', $this->type['value'], $this->state->get('filter.category_id')); ?> 
			
			<select name="filter_published" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_PUBLISHED');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('jgrid.publishedOptions', array('archived' => 0, 'trash' => 0)), 'value', 'text', $this->state->get('filter.state'), true);?>
			</select>
			
			<select name="filter_language" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_LANGUAGE');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->state->get('filter.language'));?>
			</select>

		</div>
	</fieldset>
	<div class="clr"> </div>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					
					<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" /></th>
					
					<th class="title" width="70%"><?php echo JHTML::_('grid.sort',  'COM_PHOCAMENU_TITLE', 'a.title', $listDirn, $listOrder); ?>
					</th>
					<th width="5%" nowrap="nowrap"><?php echo JText::_('COM_PHOCAMENU_ITEMS' ) ?></th>
					<th width="5%" nowrap="nowrap"><?php echo JText::_('COM_PHOCAMENU_DELETE' ) ?></th>
					
					<th width="5%" nowrap="nowrap"><?php echo JHTML::_('grid.sort', 'COM_PHOCAMENU_PUBLISHED', 'a.published',$listDirn, $listOrder ); ?>
					</th>

					
					<th width="10%">
					<?php echo JHtml::_('grid.sort',  'JGRID_HEADING_ORDERING', 'a.ordering', $listDirn, $listOrder);
					if ($canOrder && $saveOrder) {
						echo JHtml::_('grid.order',  $this->items, 'filesave.png', 'phocamenugroups.saveorder');
					} ?>
					</th>
					
					
					<th width="5%">
					<?php echo JHtml::_('grid.sort', 'JGRID_HEADING_LANGUAGE', 'a.language', $listDirn, $listOrder); ?>
					</th> 
					
					<th width="1%" nowrap="nowrap"><?php echo JHTML::_('grid.sort',  'COM_PHOCAMENU_ID', 'a.id',$listDirn, $listOrder ); ?>
					</th>
				</tr>
			</thead>
			
			<tbody>
				<?php
				

if (is_array($this->items)) {
	foreach ($this->items as $i => $item) {
					
$ordering	= ($listOrder == 'a.ordering');			
$canCreate	= $user->authorise('core.create', 'com_phocamenu');
$canEdit	= $user->authorise('core.edit', 'com_phocamenu');
$canDelete	= $user->authorise('core.delete', 'com_phocamenu');
$canCheckin	= $user->authorise('core.manage', 'com_checkin') || $item->checked_out==$user->get('id') || $item->checked_out==0;
$canChange	= $user->authorise('core.edit.state', 'com_phocamenu') && $canCheckin;
$linkEdit	= JRoute::_( $this->tmpl['linkedit'].'&id='.(int) $item->id );
//$linkRemove	= JRoute::_( 'index.php?option=com_phocamenu&task=phocamenugroups.delete&type='.(int)$this->tmpl['type'].'&cid[]='.(int) $item->id .'&'.$this->tmpl['typeinfo']['catid'].'='.$item->catid);
$linkView	= JRoute::_( 'index.php?option=com_phocamenu&view=phocamenuitems&type='.(int)$this->type['value'].'&gid='.$item->id );

$linkRemove 	= 'javascript:void(0);';
$onClickRemove 	= 'javascript:if (confirm(\''.JText::_('COM_PHOCAMENU_WARNING_DELETE_ITEMS').'\')){'
				 .' return listItemTask(\'cb'. $i .'\',\'phocamenugroups.delete\');'
				 .'}';
				
echo '<tr class="row'. $i % 2 .'">';
echo '<td class="center">'. JHtml::_('grid.id', $i, $item->id) . '</td>';

echo '<td>'; 
if ($item->checked_out) {
	echo JHtml::_('jgrid.checkedout', $i, $item->editor, $item->checked_out_time, 'phocamenugroups.', $canCheckin);
}

if ($canCreate || $canEdit) {
	echo '<a href="'. JRoute::_($linkEdit).'">'. $this->escape($item->title).'</a>';
} else {
	echo $this->escape($item->title);
}
//echo '<p class="smallsub">(<span>'.JText::_('COM_PHOCAMENU_FIELD_ALIAS_LABEL').':</span>'. $this->escape($item->alias).')</p>';
echo '</td>';

echo '<td align="center">'
	.'<a href="'. $linkView.'" title="'. JText::_('COM_PHOCAMENU_VIEW_GROUP_ITEMS').'">'
	. JHTML::_('image', 'administrator/components/com_phocamenu/assets/images/icon-16-item.png', JText::_('COM_PHOCAMENU_VIEW_GROUP_ITEMS') )
	.'</a>'
	.'</td>';
	
echo '<td align="center">';
if ($canDelete) {	
echo '<a href="'. $linkRemove.'" onclick="'.$onClickRemove.'" title="'. JText::_('COM_PHOCAMENU_DELETE').'"' 
	.' onclick="return confirm(\''.JText::_('COM_PHOCAMENU_WARNING_DELETE_GROUP').'\');">'
	. JHTML::_('image', 'administrator/components/com_phocamenu/assets/images/icon-16-trash.png', JText::_('COM_PHOCAMENU_DELETE') )
	.'</a>';
}
echo '</td>';	


echo '<td class="center">'. JHtml::_('jgrid.published', $item->published, $i, 'phocamenugroups.', $canChange) . '</td>';


$cntx = 'phocamenugroups';
echo '<td class="order">';
if ($canChange) {
	if ($saveOrder) {
		if ($listDirn == 'asc') {
			echo '<span>'. $this->pagination->orderUpIcon($i, ($item->category_id == @$this->items[$i-1]->category_id), $cntx.'.orderup', 'JLIB_HTML_MOVE_UP', $ordering).'</span>';
			echo '<span>'.$this->pagination->orderDownIcon($i, $this->pagination->total, ($item->category_id == @$this->items[$i+1]->category_id), $cntx.'.orderdown', 'JLIB_HTML_MOVE_DOWN', $ordering).'</span>';
		} else if ($listDirn == 'desc') {
			echo '<span>'. $this->pagination->orderUpIcon($i, ($item->category_id == @$this->items[$i-1]->category_id), $cntx.'.orderdown', 'JLIB_HTML_MOVE_UP', $ordering).'</span>';
			echo '<span>'.$this->pagination->orderDownIcon($i, $this->pagination->total, ($item->category_id == @$this->items[$i+1]->category_id), $cntx.'.orderup', 'JLIB_HTML_MOVE_DOWN', $ordering).'</span>';
		}
	}
	$disabled = $saveOrder ?  '' : 'disabled="disabled"';
	echo '<input type="text" name="order[]" size="5" value="'.$item->ordering.'" '.$disabled.' class="text-area-order" />';
} else {
	echo $item->ordering;
}
echo '</td>';

echo '<td class="center">';
if ($item->language=='*') {
	echo JText::_('JALL');
} else {
	echo $item->language_title ? $this->escape($item->language_title) : JText::_('JUNDEFINED');
}
echo '</td>';

echo '<td align="center">'. $item->id .'</td>';

echo '</tr>';

		}
	}
echo '</tbody>'."\n";		
echo '<tfoot><tr><td colspan="8">'. $this->pagination->getListFooter().'</td></tr></tfoot>'."\n";
echo '</table>' . "\n";

echo $this->loadTemplate('batch');
echo '</div>'."\n";
	
//<input type="hidden" name="controller" value="phocamenugroup" /> ?>
<input type="hidden" name="type" value="<?php echo (int)$this->type['value'];?>" />
<input type="hidden" name="<?php echo $this->type['info']['catid'];?>" value="<?php echo (int)$this->type['actualcatid'];?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
<input type="hidden" name="filter_order_Dir" value="" />
<?php echo JHtml::_('form.token'); ?>
</form>