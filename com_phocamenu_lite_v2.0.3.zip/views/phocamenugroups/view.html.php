<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class PhocaMenuCpViewPhocaMenuGroups extends JView
{
	protected $items;
	protected $pagination;
	protected $state;
	protected $tmpl;
	protected $type;
	
	function display($tpl = null) {	
		
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->state		= $this->get('State');
		$this->type			= PhocaMenuHelper::getUrlType('group');

		JHTML::stylesheet('administrator/components/com_phocamenu/assets/phocamenu.css' );
	
		$this->tmpl['breadcrumb']	= PhocaMenuHelper::getBreadcrumbs($this->type['info']['text'], $this->type['info']['backlink'], JText::_($this->type['info']['backlinktxt']));
	
		$this->addToolbar();
		parent::display($tpl);
	}
	
	protected function addToolbar() {
	
		$params 			= JComponentHelper::getParams( 'com_phocamenu' );
		$bar 				= JToolBar::getInstance('toolbar');
		$this->state		= $this->get('State');
		
		$this->tmpl['displaytoolbartools']	= $params->get( 'display_toolbar_tools', 1 );
		$displayToolbars 	= PhocaMenuHelper::displayToolbarTools($this->tmpl['displaytoolbartools'], $this->type['value']);
		
		// Actual Category
		$categoryId 				= $this->state->get('filter.category_id');
		$this->type['actualcatid']	= PhocaMenuHelper::getActualCategory('group', $this->type['value'], $categoryId);
		
		require_once JPATH_COMPONENT.DS.'helpers'.DS.'phocamenugroups.php';

		switch ($this->type['value']){
			case 2:
			case 3:
			case 4:
			case 5:
				$canDo	= PhocaMenuGroupsHelper::getActions($this->state->get('filter.category_id'));
			break;
			default:
				$canDo	= PhocaMenuGroupsHelper::getActions();
			break;
		}
		
		JToolBarHelper::title( $this->type['info']['text'] , $this->type['info']['pref'] );
		$bar->appendButton( 'Link', 'back', $this->type['info']['backlinktxt'], 'index.php?option=com_phocamenu'.$this->type['info']['backlink'] );
		JToolBarHelper::divider();
		
		$backCatidSpec = '';
		if (isset($this->type['actualcatid']) && (int)$this->type['actualcatid'] > 0) {
			$backCatidSpec 	=  '&'.$this->type['info']['catid'].'='.(int)$this->type['actualcatid'];
		}
		$langSuffix = PhocaMenuHelper::getLangSuffix($this->state->get('filter.language'));
		$this->tmpl['linkpreview'] 	= JURI::root().'index.php?option=com_phocamenu&view='.$this->type['info']['frontview'].'&tmpl=component'.$langSuffix;
		$this->tmpl['linkemail'] 	= 'index.php?option=com_phocamenu&task=phocamenuemail.edit&type='.$this->type['value'].'&typeback=group'. $backCatidSpec;
		$this->tmpl['linkmultiple']	= 'index.php?option=com_phocamenu&task=phocamenumultipleedit.edit&type='.$this->type['value'].'&typeback=group'.$backCatidSpec;
		//$this->tmpl['linkpdf']		= PhocaMenuRender::getIconPDFAdministrator($this->type['info']['frontview'], 1);
		$this->tmpl['linkconfig']	= 'index.php?option=com_phocamenu&task=phocamenuconfig.edit&type='.$this->type['value'].'&typeback=group'. $backCatidSpec;
		//ID must be added
		$this->tmpl['linkedit']		= 'index.php?option=com_phocamenu&task=phocamenugroup.edit&type='.$this->type['value']. $backCatidSpec;
		
		
		if ($canDo->get('core.create')) {
			JToolBarHelper::addNew( 'phocamenugroup.add','JTOOLBAR_NEW');
		}
		if ($canDo->get('core.edit')) {
			JToolBarHelper::editList('phocamenugroup.edit','JTOOLBAR_EDIT');
			if ($displayToolbars) {
				$bar->appendButton( 'Custom', '<a href="'.$this->tmpl['linkmultiple'].'"><span class="icon-32-multiple" title="'.JText::_('COM_PHOCAMENU_MULTIPLE_EDIT').'" type="Custom"></span>'.JText::_('COM_PHOCAMENU_MULTIPLE_EDIT').'</a>');
			}
		}
		
		if ($canDo->get('core.manage')) {
			
			if ($displayToolbars) {
				$bar->appendButton( 'Custom', '<a href="'.$this->tmpl['linkemail'].'"><span class="icon-32-email" title="'.JText::_('COM_PHOCAMENU_EMAIL').'" type="Custom"></span>'.JText::_('COM_PHOCAMENU_EMAIL').'</a>');
				//JToolBarHelper::preview( JURI::root().$this->tmpl['linkpreview'] );
				$bar->appendButton( 'Popup', 'prmpreview', 'COM_PHOCAMENU_PREVIEW', $this->tmpl['linkpreview']);
				$langSuffix = PhocaMenuHelper::getLangSuffix($this->state->get('filter.language'));
				$bar->appendButton( 'Custom', PhocaMenuRender::getIconPDFAdministrator($this->type['info']['frontview'], 0, $langSuffix));
			
			}
		}
		
		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::divider();
			JToolBarHelper::custom('phocamenugroups.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
			JToolBarHelper::custom('phocamenugroups.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
		}

		if ($canDo->get('core.delete')) {
			JToolBarHelper::deleteList( JText::_( 'COM_PHOCAMENU_WARNING_DELETE_ITEMS' ), 'phocamenugroups.delete', 'COM_PHOCAMENU_DELETE');
		}
		
		JToolBarHelper::divider();
		
		if ($canDo->get('core.manage')) {
			$bar->appendButton( 'Custom', '<a href="'.$this->tmpl['linkconfig'].'"><span class="icon-32-settings" title="'.JText::_('COM_PHOCAMENU_SETTINGS').'" type="Custom"></span>'.JText::_('COM_PHOCAMENU_SETTINGS').'</a>');
		}
		
		
		JToolBarHelper::help( 'screen.phocamenu', true );
	}
	
}
?>