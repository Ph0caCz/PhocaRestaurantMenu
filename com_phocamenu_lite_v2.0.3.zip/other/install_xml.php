<?php
/*********** XML PARAMETERS AND VALUES ************/
$xml_item = "component";// component | template
$xml_file = "phocamenu.xml";		
$xml_name = "com_phocamenu";
$xml_creation_date = "26/03/2013";
$xml_author = "Jan Pavelka (www.phoca.cz)";
$xml_author_email = "";
$xml_author_url = "www.phoca.cz";
$xml_copyright = "Jan Pavelka";
$xml_license = "GNU/GPL";
$xml_version = "2.0.3 Lite";
$xml_description = "Phoca Restaurant Menu";
$xml_copy_file = 1;//Copy other files in to administration area (only for development), ./front, ./language, ./other

$xml_menu = array (0 => "COM_PHOCAMENU", 1 => "option=com_phocamenu", 2 => "components/com_phocamenu/assets/images/icon-16-prm-menu.png", 4 => 'phocamenucp');

$xml_submenu[0] = array (0 => "COM_PHOCAMENU_CONTROLPANEL", 1 => "option=com_phocamenu", 2 => "components/com_phocamenu/assets/images/icon-16-prm-menu-cp.png", 4 => 'phocamenucp');
$xml_submenu[1] = array (0 => "COM_PHOCAMENU_DAILY_MENU", 1 => "option=com_phocamenu&view=phocamenugroups&type=1", 2 => "components/com_phocamenu/assets/images/icon-16-prm-menu-dm.png", 4 => 'phocamenugroups');

$xml_submenu[2] = array (0 => "COM_PHOCAMENU_INFO", 1 => "option=com_phocamenu&view=phocamenuinfo", 2 => "components/com_phocamenu/assets/images/icon-16-prm-menu-info.png", 4 => 'phocamenuinfo');

$xml_install_file = 'install.phocamenu.php'; 
$xml_uninstall_file = 'uninstall.phocamenu.php';
/*********** XML PARAMETERS AND VALUES ************/
?>