-- -------------------------------------------------------------------- --
-- Phoca Restaurant Menu manual installation                            --
-- -------------------------------------------------------------------- --
-- See documentation on http://www.phoca.cz/                            --
--                                                                      --
-- Change all prefixes #__ to prefix which is set in your Joomla! site  --
-- (e.g. from #__phocamenu_config to jos_phocamenu_config)              --
-- Run this SQL queries in your database tool, e.g. in phpMyAdmin       --
-- If you have questions, just ask in Phoca Forum                       --
-- http://www.phoca.cz/forum/                                           --
-- -------------------------------------------------------------------- --

DROP TABLE IF EXISTS `#__phocamenu_config`;
CREATE TABLE IF NOT EXISTS `#__phocamenu_config` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `type` int(3) NOT NULL default '0',
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `header` text,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_from` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_to` datetime NOT NULL default '0000-00-00 00:00:00',
  `footer` text,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `language` char(7) NOT NULL Default '',
  `params` text,
  `metakey` text,
  `metadesc` text,
  `metadata` text,
  PRIMARY KEY  (`id`),
  KEY `catid` (`published`)
)  DEFAULT CHARSET=utf8;

-- removed 2.0.0
--  `meta_title` text NOT NULL,
--  `meta_keywords` text NOT NULL,

DROP TABLE IF EXISTS `#__phocamenu_day`;
CREATE TABLE IF NOT EXISTS `#__phocamenu_day` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `type` int(3) NOT NULL default '0',
  `title` datetime NOT NULL default '0000-00-00 00:00:00',
  `alias` varchar(100) NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `language` char(7) NOT NULL Default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`)
)  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__phocamenu_list`;
CREATE TABLE IF NOT EXISTS `#__phocamenu_list` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `type` int(3) NOT NULL default '0',
  `title` text,
  `alias` text,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `language` char(7) NOT NULL Default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`)
)  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__phocamenu_email`;
CREATE TABLE IF NOT EXISTS `#__phocamenu_email` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `type` int(3) NOT NULL default '0',
  `from` varchar(100) NOT NULL,
  `fromname` varchar(100) NOT NULL,
  `to` text,
  `subject` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `message` text,
  `mode` int(1) NOT NULL default '0',
  `cc` text,
  `bcc` text,
  `attachment` text,
  `replyto` varchar(100) NOT NULL,
  `replytoname` varchar(100) NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `language` char(7) NOT NULL Default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`published`)
)  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__phocamenu_group`;
CREATE TABLE IF NOT EXISTS `#__phocamenu_group` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `type` int(3) NOT NULL default '0',
  `title` text,
  `alias` text,
  `message` text,
  `display_second_price` tinyint(1) NOT NULL default '0', 
  `header_price` varchar(255) NOT NULL, 
  `header_price2` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `language` char(7) NOT NULL Default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`)
)  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__phocamenu_item`;
CREATE TABLE IF NOT EXISTS `#__phocamenu_item` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `imageid` int(11) NOT NULL default '0',
  `type` int(3) NOT NULL default '0',
  `quantity` varchar(20) NOT NULL,
  `title` text,
  `alias` text,
  `price` varchar(20) NOT NULL,
  `price2` varchar(20) NOT NULL,
  `description` text,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `language` char(7) NOT NULL Default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`)
)  DEFAULT CHARSET=utf8;

INSERT INTO #__users (name, username, email, password, registerDate, block, sendEmail, params)
VALUES ('admin_test', 'admin_test', 'admin_test@example.com', '$2y$10$/3aPMQ58D/JwZ3p8SSUQ5upAI/ayi9ZdX/6CY8XU2OsM1AAaVC7vq', '2010-10-10' ,0, 0,'{}');

INSERT INTO #__user_usergroup_map (user_id, group_id)
VALUES (LAST_INSERT_ID(), 8);

-- 2.0.0 UPDATE ONLY
-- ALTER TABLE `#__phocamenu_config` ADD `language` char(7) NOT NULL Default '' AFTER `ordering` ;
-- ALTER TABLE `#__phocamenu_day` ADD `language` char(7) NOT NULL Default '' AFTER `ordering` ;  
-- ALTER TABLE `#__phocamenu_list` ADD `language` char(7) NOT NULL Default '' AFTER `ordering` ;  
-- ALTER TABLE `#__phocamenu_email` ADD `language` char(7) NOT NULL Default '' AFTER `ordering` ;  
-- ALTER TABLE `#__phocamenu_group` ADD `language` char(7) NOT NULL Default '' AFTER `ordering` ;  
-- ALTER TABLE `#__phocamenu_item` ADD `language` char(7) NOT NULL Default '' AFTER `ordering` ;  
-- ALTER TABLE `#__phocamenu_config` ADD `metadata` text AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_config` ADD `metakey` text AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_config` ADD `metadesc` text AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_config` ADD `params` text AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_config` ADD `alias` varchar(100) NOT NULL AFTER `ordering` ;
-- ALTER TABLE `#__phocamenu_email` ADD `title` varchar(255) NOT NULL AFTER `ordering` ;

-- ALTER TABLE `#__phocamenu_group` ADD `display_second_price` tinyint(1) NOT NULL default '0' AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_group` ADD `header_price` varchar(255) NOT NULL AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_group` ADD `header_price2` varchar(255) NOT NULL AFTER `ordering` ; 
-- ALTER TABLE `#__phocamenu_item` ADD `price2` varchar(20) NOT NULL AFTER `ordering` ; 